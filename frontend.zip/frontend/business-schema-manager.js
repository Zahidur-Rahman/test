// Business Schema Manager JavaScript - Improved Version
let columnCount = 0;
let relationshipCount = 0;
let availableColumns = [];

// Initialize the form when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadBusinesses();
    // Reset column count to ensure proper numbering
    columnCount = 0;
    
    // Add event listeners
    const businessSelect = document.getElementById('businessId');
    const tableSelect = document.getElementById('tableName');
    
    if (businessSelect) {
        businessSelect.addEventListener('change', onBusinessChange);
    }

// (moved) setupTableSearchIntegration defined at top-level scope below
    
    if (tableSelect) {
        tableSelect.addEventListener('change', onTableChange);
    }
    
    // Initialize merged table search UX
    setupTableSearchIntegration();
    
    // Check for edit mode URL parameters
    setTimeout(() => checkEditMode(), 100);
    
});

// Disable table search overlay; revert to native select only
function setupTableSearchIntegration() {
    const select = document.getElementById('tableName');
    const filter = document.getElementById('tableNameFilter');
    const trigger = document.getElementById('tableSearchBtn');

    // Ensure no options are hidden (from any previous state)
    if (select && select.options) {
        Array.from(select.options).forEach((opt, idx) => { if (idx > 0) opt.hidden = false; });
    }

    // Hide and disable the filter input and trigger button
    if (filter) {
        filter.style.display = 'none';
        filter.disabled = true;
    }
    if (trigger) {
        trigger.style.display = 'none';
        trigger.disabled = true;
    }

    // Remove any global handlers
    window.showTableFilter = undefined;
    window.hideTableFilter = undefined;
}

// Load businesses for dropdown
async function loadBusinesses() {
    const select = document.getElementById('businessId');
    
    try {
        // Show loading state
        select.innerHTML = '<option value="">Loading businesses...</option>';
        select.disabled = true;
        
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        
        const headers = {};
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        const response = await fetch('/admin/businesses', { headers });
        
        if (response.ok) {
            const data = await response.json();
            select.innerHTML = '<option value="">Select Business</option>';
            
            // Handle different response formats
            const businesses = data.businesses || data.data || data || [];
            
            if (businesses.length === 0) {
                select.innerHTML = '<option value="">No businesses found</option>';
                showAlert('No businesses available. Please add a business first.', 'warning');
                return;
            }
            
            businesses.forEach(business => {
                const option = document.createElement('option');
                option.value = business.business_id || business.id;
                // Show only business ID as requested
                option.textContent = business.business_id || business.id;
                select.appendChild(option);
            });
            
            showAlert(`Loaded ${businesses.length} businesses`, 'success');
        } else {
            const errorText = await response.text();
            // Try without authentication if 401/403
            if (response.status === 401 || response.status === 403) {
                const noAuthResponse = await fetch('/admin/businesses');
                
                if (noAuthResponse.ok) {
                    const data = await noAuthResponse.json();
                    
                    select.innerHTML = '<option value="">Select Business</option>';
                    const businesses = data.businesses || data.data || data || [];
                    
                    if (businesses.length === 0) {
                        select.innerHTML = '<option value="">No businesses found</option>';
                        showAlert('No businesses available. Please add a business first.', 'warning');
                        return;
                    }
                    
                    businesses.forEach(business => {
                        const option = document.createElement('option');
                        option.value = business.business_id || business.id;
                        option.textContent = business.business_id || business.id;
                        select.appendChild(option);
                    });
                    
                    showAlert(`Loaded ${businesses.length} businesses`, 'success');
                    return;
                }
            }
            
            throw new Error(`Failed to load businesses: ${response.status} ${response.statusText}`);
        }
    } catch (error) {
        select.innerHTML = '<option value="">Error loading businesses</option>';
        showAlert(`Error loading businesses: ${error.message}`, 'error');
    } finally {
        select.disabled = false;
    }
}

// Handle business selection change
async function onBusinessChange() {
    const businessId = document.getElementById('businessId').value;
    
    const tableSelect = document.getElementById('tableName');
    const tableFilter = document.getElementById('tableNameFilter');
    
    if (!businessId) {
        tableSelect.innerHTML = '<option value="">Select a business first</option>';
        if (tableFilter) {
            if (typeof window.hideTableFilter === 'function') {
                window.hideTableFilter();
            } else {
                tableFilter.style.display = 'none';
            }
        }
        clearColumns();
        return;
    }
    
    // Show loading state
    tableSelect.innerHTML = '<option value="">Loading tables...</option>';
    tableSelect.disabled = true;
    if (tableFilter) tableFilter.style.display = 'none';
    
    try {
        await loadTables(businessId);
        
        // Ensure merged search is ready
        setupTableSearchIntegration();
    } catch (error) {
        showAlert('Error loading tables for selected business', 'error');
        tableSelect.innerHTML = '<option value="">Error loading tables</option>';
    } finally {
        tableSelect.disabled = false;
    }
}

// Load tables for selected business
async function loadTables(businessId) {
    const tableSelect = document.getElementById('tableName');
    
    if (!tableSelect) {
        showAlert('Table dropdown element not found', 'error');
        return;
    }
    
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        const headers = {};
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        // Load tables using business ID configuration
        let response = await fetch(`/admin/businesses/${businessId}/tables`, { headers });
        
        if (!response.ok) {
            const errorText = await response.text();
            
            if (response.status === 401 || response.status === 403) {
                response = await fetch(`/admin/businesses/${businessId}/tables`);
            } else if (response.status === 404) {
                response = await fetch(`/api/businesses/${businessId}/tables`, { headers });
                
            }
        }
        
        if (!response.ok) {
            // Try to get error text, but handle cases where response body is already consumed
            let errorText = 'Unknown error';
            try {
                errorText = await response.text();
            } catch (e) {
                // Silently handle error reading response
            }
            
            // Show specific error message to user
            if (response.status === 404) {
                showAlert(`Business ID '${businessId}' not found. ${errorText}`, 'error');
            } else if (response.status === 500) {
                showAlert(`Database connection failed for business '${businessId}'. Check database configuration.`, 'error');
            } else {
                showAlert(`Error loading tables: ${errorText}`, 'error');
            }
            
            throw new Error(`Failed to fetch tables: ${response.status} - ${errorText}`);
        }
        
        if (response.ok) {
            const data = await response.json();
            
            tableSelect.innerHTML = '<option value="">Select Table</option>';
            
            // Handle different response formats
            const tables = data.tables || data.data || data || [];
            
            if (tables && tables.length > 0) {
                tables.forEach(table => {
                    const option = document.createElement('option');
                    const tableName = typeof table === 'string' ? table : (table.name || table.table_name || String(table));
                    option.value = tableName;
                    option.textContent = tableName;
                    tableSelect.appendChild(option);
                });
                
                // Add event listener for table selection (remove existing first)
                tableSelect.removeEventListener('change', onTableChange);
                tableSelect.addEventListener('change', onTableChange);
                
                showAlert(`Loaded ${tables.length} tables successfully`, 'success');
                // Re-init merged search after options update
                setupTableSearchIntegration();
            } else {
                tableSelect.innerHTML = '<option value="">No tables found</option>';
                showAlert('No tables found for this business', 'warning');
            }
        } else {
            throw new Error(`Failed to fetch tables: ${response.status} ${response.statusText}`);
        }
    } catch (error) {
        tableSelect.innerHTML = '<option value="">Error loading tables</option>';
        showAlert(`Error loading tables: ${error.message}`, 'error');
    }
}

// Handle table selection change
async function onTableChange() {
    const businessId = document.getElementById('businessId').value;
    const tableName = document.getElementById('tableName').value;
    
    if (!businessId || !tableName) {
        clearColumns();
        return;
    }
    
    // Clear existing columns and show empty state
    clearColumns();
    // Auto-add a column so the user immediately sees the correct dropdown for this table
    try {
        await addColumn();
        showAlert('Column list loaded for the selected table.', 'success');
    } catch (e) {
        showAlert('Unable to load columns for the selected table.', 'error');
    }
}

// Load and auto-populate columns from database
async function loadTableColumns(businessId, tableName) {
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        const headers = {};
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        let response = await fetch(`/admin/businesses/${businessId}/tables/${tableName}/columns`, { headers });
        
        if (!response.ok && response.status === 401) {
            // Try without authentication
            response = await fetch(`/admin/businesses/${businessId}/tables/${tableName}/columns`);
        }
        
        if (response.ok) {
            const data = await response.json();
            
            if (data.columns && data.columns.length > 0) {
                // Ask user if they want to auto-populate
                const shouldAutoPopulate = confirm(
                    `Found ${data.columns.length} columns in table "${tableName}". ` +
                    'Would you like to auto-populate the column details from the database?'
                );
                
                if (shouldAutoPopulate) {
                    clearColumns();
                    populateColumnsFromDatabase(data.columns);
                    showAlert(`Auto-populated ${data.columns.length} columns from database`, 'success');
                }
            }
        } else {
            const errorText = await response.text();
        }
    } catch (error) {
        throw error;
    }
}

// Populate columns from database introspection
function populateColumnsFromDatabase(dbColumns) {
    dbColumns.forEach((dbCol, index) => {
        addColumn();
        const columnDiv = document.querySelector(`[data-column-id="${columnCount}"]`);
        
        if (columnDiv) {
            // Set basic column info
            const nameInput = columnDiv.querySelector('[data-field="name"]');
            const typeSelect = columnDiv.querySelector('[data-field="type"]');
            const lengthInput = columnDiv.querySelector('[data-field="max_length"]');
            const defaultInput = columnDiv.querySelector('[data-field="default"]');
            const nullableCheckbox = columnDiv.querySelector('[data-field="nullable"]');
            const constraintSelect = columnDiv.querySelector('[data-field="constraints"]');
            const descriptionInput = columnDiv.querySelector('[data-field="description"]');
            
            if (nameInput) nameInput.value = dbCol.name || '';
            if (typeSelect) typeSelect.value = mapDatabaseType(dbCol.type);
            if (lengthInput && dbCol.max_length) lengthInput.value = dbCol.max_length;
            if (defaultInput && dbCol.default) defaultInput.value = dbCol.default;
            if (nullableCheckbox) nullableCheckbox.checked = dbCol.nullable !== false;
            if (descriptionInput) descriptionInput.value = dbCol.description || '';
            
            // Set constraint from database info
            let primaryConstraint = 'NONE';
            if (dbCol.is_primary_key) {
                primaryConstraint = 'PRIMARY KEY';
            } else if (dbCol.is_foreign_key) {
                primaryConstraint = 'FOREIGN KEY';
            } else if (dbCol.is_unique) {
                primaryConstraint = 'UNIQUE';
            } else if (dbCol.is_nullable === false) {
                primaryConstraint = 'NOT NULL';
            } else if (dbCol.constraints && Array.isArray(dbCol.constraints) && dbCol.constraints.length > 0) {
                primaryConstraint = dbCol.constraints[0];
            }
            
            if (constraintSelect) {
                constraintSelect.value = primaryConstraint;
            }
        }
    });
    
    updateAvailableColumns();
}

// Map database types to our dropdown options
function mapDatabaseType(dbType) {
    if (!dbType) return '';
    
    const typeMap = {
        'int': 'INTEGER',
        'integer': 'INTEGER',
        'bigint': 'BIGINT',
        'varchar': 'VARCHAR',
        'text': 'TEXT',
        'boolean': 'BOOLEAN',
        'bool': 'BOOLEAN',
        'date': 'DATE',
        'timestamp': 'TIMESTAMP',
        'datetime': 'TIMESTAMP',
        'decimal': 'DECIMAL',
        'numeric': 'DECIMAL',
        'json': 'JSON',
        'uuid': 'UUID'
    };
    
    const lowerType = dbType.toLowerCase();
    return typeMap[lowerType] || dbType.toUpperCase();
}

// Clear all columns except the first one
function clearColumns() {
    const container = document.getElementById('columnsContainer');
    // Remove all existing column items
    const columns = container.querySelectorAll('.column-item');
    columns.forEach(col => col.remove());
    
    // Reset counter so the next add starts at 1
    columnCount = 0;
    updateAvailableColumns();
}

// Load available columns from database using business config
async function loadAvailableColumns(businessId, tableName) {
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        
        const headers = {
            'Content-Type': 'application/json'
        };
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        const encodedTable = encodeURIComponent(tableName);
        const url = `/admin/businesses/${businessId}/tables/${encodedTable}/columns?_=${Date.now()}`;
        const response = await fetch(url, { 
            method: 'GET',
            headers,
            cache: 'no-store',
            credentials: 'same-origin'
        });
        
        if (response.ok) {
            const data = await response.json();
            
            if (data.columns && data.columns.length > 0) {
                return data.columns;
            } else {
                return [];
            }
        } else {
            const errorText = await response.text();
            return [];
        }
    } catch (error) {
        return [];
    }
}

// Populate column details when selected from dropdown
function populateColumnDetails(selectElement, columnId) {
    const selectedOption = selectElement.options[selectElement.selectedIndex];
    const columnDiv = document.querySelector(`[data-column-id="${columnId}"]`);
    
    if (selectedOption && columnDiv) {
        const nameInput = columnDiv.querySelector('[data-field="name"]');
        const typeInput = columnDiv.querySelector('[data-field="type"]');
        const constraintSelect = columnDiv.querySelector('[data-field="constraints"]');
        const lengthInput = columnDiv.querySelector('[data-field="max_length"]');
        
        if (nameInput) nameInput.value = selectedOption.value;
        if (typeInput) typeInput.value = selectedOption.dataset.type || '';
        if (constraintSelect) {
            const constraint = selectedOption.dataset.constraint || 'NONE';
            constraintSelect.value = constraint;
        }
        if (lengthInput) {
            const len = selectedOption.dataset.maxLength || '';
            lengthInput.value = len;
        }
    }
}

// Add a new column with dropdown selection
async function addColumn() {
    const businessIdElement = document.getElementById('businessId');
    const tableNameElement = document.getElementById('tableName');
    
    const businessId = businessIdElement?.value;
    const tableName = tableNameElement?.value;
    
    if (!businessId || !tableName) {
        showAlert('Please select a business and table first', 'error');
        return;
    }
    
    try {
        const availableColumns = await loadAvailableColumns(businessId, tableName);
        
        columnCount++;
        const container = document.getElementById('columnsContainer');
        
        const columnDiv = document.createElement('div');
        columnDiv.className = 'column-item';
        columnDiv.setAttribute('data-column-id', columnCount);
        
        // Create column dropdown options - show only column names
        let dropdownOptions = '<option value="">Select Column</option>';
        
        if (availableColumns && availableColumns.length > 0) {
            availableColumns.forEach(column => {
                const columnName = column.name || column.column_name || 'Unknown';
                const rawType = column.type || '';
                const mappedType = mapDatabaseType(rawType);
                const firstConstraint = (column.constraints && Array.isArray(column.constraints) && column.constraints.length > 0) ? column.constraints[0] : 'NONE';
                const isNullable = column.nullable !== false;
                const maxLen = (column.max_length !== undefined && column.max_length !== null) ? column.max_length : '';
                dropdownOptions += `<option value="${columnName}" data-type="${mappedType}" data-constraint="${firstConstraint}" data-nullable="${isNullable}" data-max-length="${maxLen}">${columnName}</option>`;
            });
        } else {
            dropdownOptions += '<option value="" disabled>No columns found</option>';
        }
        
        columnDiv.innerHTML = `
            <div class="column-header">
                <div class="column-number">${columnCount}</div>
                <!-- Column Name is now a select so user picks directly here -->
                <select class="column-input" data-field="name" onchange="populateColumnFields(this)" required>
                    ${dropdownOptions}
                </select>
                <select class="column-input" data-field="type" required>
                    <option value="">Select Type</option>
                    <option value="VARCHAR">VARCHAR</option>
                    <option value="TEXT">TEXT</option>
                    <option value="INTEGER">INTEGER</option>
                    <option value="BIGINT">BIGINT</option>
                    <option value="DECIMAL">DECIMAL</option>
                    <option value="BOOLEAN">BOOLEAN</option>
                    <option value="DATE">DATE</option>
                    <option value="TIMESTAMP">TIMESTAMP</option>
                    <option value="JSON">JSON</option>
                </select>
                <input type="number" class="column-input" placeholder="Max Length" data-field="max_length">
                <input type="text" class="column-input" placeholder="Default Value" data-field="default">
                <select class="column-input constraint-select" data-field="constraints">
                    <option value="NONE">None</option>
                    <option value="PRIMARY KEY">PRIMARY KEY</option>
                    <option value="FOREIGN KEY">FOREIGN KEY</option>
                    <option value="UNIQUE">UNIQUE</option>
                    <option value="NOT NULL">NOT NULL</option>
                    <option value="INDEX">INDEX</option>
                    <option value="AUTO_INCREMENT">AUTO INCREMENT</option>
                </select>
                <div class="nullable-section">
                    <input type="checkbox" id="nullable-${columnCount}" data-field="nullable" checked>
                    <label for="nullable-${columnCount}">Nullable</label>
                </div>
                <input type="text" class="column-input" placeholder="Business Meaning" data-field="business_meaning">
                <input type="text" class="column-input" placeholder="Description" data-field="description">
                <button class="remove-btn" onclick="removeColumn(this)" title="Remove Column">×</button>
            </div>
        `;
        
        container.appendChild(columnDiv);
        
        
    } catch (error) {
        showAlert('Error loading column options', 'error');
    }
}

// Auto-populate column fields when selecting from dropdown
function populateColumnFields(selectElement) {
    const selectedOption = selectElement.options[selectElement.selectedIndex];
    if (!selectedOption || !selectedOption.value) return;
    
    const columnDiv = selectElement.closest('.column-item');
    if (!columnDiv) return;
    
    // Get data from the selected option
    const columnName = selectedOption.value;
    const columnType = selectedOption.dataset.type || '';
    const columnConstraint = selectedOption.dataset.constraint || 'NONE';
    const columnMaxLen = selectedOption.dataset.maxLength || '';
    const columnNullable = selectedOption.dataset.nullable !== 'false';
    
    // Populate the fields
    const nameInput = columnDiv.querySelector('[data-field="name"]');
    const typeSelect = columnDiv.querySelector('[data-field="type"]');
    const constraintSelect = columnDiv.querySelector('[data-field="constraints"]');
    const nullableCheckbox = columnDiv.querySelector('[data-field="nullable"]');
    
    if (nameInput) nameInput.value = columnName;
    if (typeSelect) typeSelect.value = mapDatabaseType(columnType);
    if (constraintSelect) constraintSelect.value = columnConstraint;
    if (nullableCheckbox) nullableCheckbox.checked = columnNullable;
    if (lengthInput) lengthInput.value = columnMaxLen;
}

// Remove a column
function removeColumn(button) {
    if (document.querySelectorAll('.column-item').length <= 1) {
        showAlert('At least one column is required', 'error');
        return;
    }
    
    const confirmation = confirm('Are you sure you want to remove this column?');
    if (!confirmation) return;
    
    const columnItem = button.closest('.column-item');
    columnItem.remove();
    updateColumnNumbers();
    updateAvailableColumns();
}

// Update column numbers after removal
function updateColumnNumbers() {
    const columns = document.querySelectorAll('.column-item');
    columns.forEach((column, index) => {
        const numberDiv = column.querySelector('.column-number');
        numberDiv.textContent = index + 1;
        column.setAttribute('data-column-id', index + 1);
        
        // Update nullable checkbox ID and label
        const checkbox = column.querySelector('[data-field="nullable"]');
        const label = column.querySelector('.nullable-section label');
        const newId = `nullable-${index + 1}`;
        checkbox.id = newId;
        label.setAttribute('for', newId);
    });
    columnCount = columns.length;
}

// Toggle constraint
function toggleConstraint(element, constraint) {
    element.classList.toggle('active');
    
    // Handle NOT NULL constraint
    if (constraint === 'NOT NULL') {
        const columnItem = element.closest('.column-item');
        const nullableCheckbox = columnItem.querySelector('[data-field="nullable"]');
        nullableCheckbox.checked = !element.classList.contains('active');
    }
    
    // Handle mutually exclusive constraints
    if (constraint === 'PRIMARY KEY' && element.classList.contains('active')) {
        const columnItem = element.closest('.column-item');
        const constraints = columnItem.querySelectorAll('.constraint-tag');
        constraints.forEach(tag => {
            if (tag.textContent.trim() === 'FOREIGN KEY') {
                tag.classList.remove('active');
            }
        });
    }
    
    if (constraint === 'FOREIGN KEY' && element.classList.contains('active')) {
        const columnItem = element.closest('.column-item');
        const constraints = columnItem.querySelectorAll('.constraint-tag');
        constraints.forEach(tag => {
            if (tag.textContent.trim() === 'PRIMARY KEY') {
                tag.classList.remove('active');
            }
        });
    }
}

// Update available columns for relationships
function updateAvailableColumns() {
    availableColumns = [];
    const columns = document.querySelectorAll('.column-item');
    
    columns.forEach(column => {
        const nameInput = column.querySelector('[data-field="name"]');
        if (nameInput.value.trim()) {
            availableColumns.push(nameInput.value.trim());
        }
    });
    
    updateRelationshipDropdowns();
}

// Add a new relationship
function addRelationship() {
    relationshipCount++;
    const container = document.getElementById('relationshipsContainer');
    
    const relationshipDiv = document.createElement('div');
    relationshipDiv.className = 'relationship-item';
    relationshipDiv.setAttribute('data-relationship-id', relationshipCount);
    
    relationshipDiv.innerHTML = `
        <div class="relationship-header">
            <div class="relationship-number">${relationshipCount}</div>
            <select class="column-input" data-field="relationship_type">
                <option value="">Relationship Type</option>
                <option value="PRIMARY KEY">PRIMARY KEY</option>
                <option value="FOREIGN KEY">FOREIGN KEY</option>
            </select>
            <input type="text" class="column-input" placeholder="Referenced Table" data-field="referenced_table">
            <div style="position: relative;">
                <input type="text" class="column-input referenced-column-input" placeholder="Referenced Column" data-field="referenced_column" onclick="showColumnDropdown(this)" readonly>
                <div class="column-dropdown"></div>
            </div>
            <button class="remove-btn" onclick="removeRelationship(this)" title="Remove Relationship">×</button>
        </div>
        
        <div class="relationship-description">
            <label>Description</label>
            <textarea class="column-input" rows="2" placeholder="Describe this relationship..." data-field="description"></textarea>
        </div>
    `;
    
    container.appendChild(relationshipDiv);
}

// Remove a relationship
function removeRelationship(button) {
    const confirmation = confirm('Are you sure you want to remove this relationship?');
    if (!confirmation) return;
    
    const relationshipItem = button.closest('.relationship-item');
    relationshipItem.remove();
    updateRelationshipNumbers();
}

// Update relationship numbers after removal
function updateRelationshipNumbers() {
    const relationships = document.querySelectorAll('.relationship-item');
    relationships.forEach((relationship, index) => {
        const numberDiv = relationship.querySelector('.relationship-number');
        numberDiv.textContent = index + 1;
        relationship.setAttribute('data-relationship-id', index + 1);
    });
    relationshipCount = relationships.length;
}

// Show column dropdown for relationships
function showColumnDropdown(input) {
    const dropdown = input.nextElementSibling;
    dropdown.innerHTML = '';
    
    if (availableColumns.length === 0) {
        dropdown.innerHTML = '<div class="column-dropdown-item">No columns available</div>';
    } else {
        availableColumns.forEach(column => {
            const item = document.createElement('div');
            item.className = 'column-dropdown-item';
            item.textContent = column;
            item.onclick = () => {
                input.value = column;
                dropdown.style.display = 'none';
            };
            dropdown.appendChild(item);
        });
    }
    
    dropdown.style.display = 'block';
    
    // Hide dropdown when clicking outside
    setTimeout(() => {
        document.addEventListener('click', function hideDropdown(e) {
            if (!input.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.style.display = 'none';
                document.removeEventListener('click', hideDropdown);
            }
        });
    }, 100);
}

// Update relationship dropdowns
function updateRelationshipDropdowns() {
    const dropdowns = document.querySelectorAll('.referenced-column-input');
    dropdowns.forEach(input => {
        if (input.value && !availableColumns.includes(input.value)) {
            input.value = '';
        }
    });
}

// Validate form data
function validateFormData() {
    const businessId = document.getElementById('businessId').value;
    const tableName = document.getElementById('tableName').value;
    const schemaDescription = document.getElementById('schemaDescription').value.trim();
    
    if (!businessId) {
        throw new Error('Please select a business');
    }
    
    if (!tableName || tableName.trim() === '') {
        throw new Error('Please select a table name');
    }
    
    if (!schemaDescription.trim()) {
        throw new Error('Please enter a schema description');
    }
    
    // Validate columns
    const columnItems = document.querySelectorAll('.column-item');
    if (columnItems.length === 0) {
        throw new Error('At least one column is required');
    }
    
    let hasPrimaryKey = false;
    const columnNames = new Set();
    
    columnItems.forEach((item, index) => {
        const name = item.querySelector('[data-field="name"]').value.trim();
        const type = item.querySelector('[data-field="type"]').value;
        
        if (!name) {
            throw new Error(`Column ${index + 1}: Name is required`);
        }
        
        if (!type) {
            throw new Error(`Column ${index + 1}: Type is required`);
        }
        
        // Check for duplicate column names
        const lowerName = name.toLowerCase();
        if (columnNames.has(lowerName)) {
            throw new Error(`Column name "${name}" is duplicated`);
        }
        columnNames.add(lowerName);
        
        // Validate column name format
        const columnNameRegex = /^[a-zA-Z][a-zA-Z0-9_]*$/;
        if (!columnNameRegex.test(name)) {
            throw new Error(`Column "${name}": Name must start with a letter and contain only letters, numbers, and underscores`);
        }
        
        // Check for primary key
        const constraintTags = item.querySelectorAll('.constraint-tag.active');
        constraintTags.forEach(tag => {
            if (tag.textContent.trim() === 'PRIMARY KEY') {
                hasPrimaryKey = true;
            }
        });
        
        // Validate VARCHAR length
        if (type === 'VARCHAR') {
            const maxLength = item.querySelector('[data-field="max_length"]').value;
            if (!maxLength || parseInt(maxLength) <= 0) {
                throw new Error(`Column "${name}": VARCHAR type requires a valid max length`);
            }
        }
    });
    
    if (!hasPrimaryKey) {
        const confirmation = confirm('No primary key defined. This is not recommended for database design. Continue anyway?');
        if (!confirmation) {
            throw new Error('Primary key is recommended for proper database design');
        }
    }
}

// Collect form data
function collectFormData() {
    validateFormData();
    
    const businessId = document.getElementById('businessId').value;
    const tableName = document.getElementById('tableName').value;
    const schemaDescription = document.getElementById('schemaDescription').value.trim();
    
    // Collect columns
    const columns = [];
    const columnItems = document.querySelectorAll('.column-item');
    
    columnItems.forEach((item, index) => {
        const name = item.querySelector('[data-field="name"]').value.trim();
        const type = item.querySelector('[data-field="type"]').value;
        const maxLength = item.querySelector('[data-field="max_length"]').value;
        const defaultValue = item.querySelector('[data-field="default"]').value;
        const description = item.querySelector('[data-field="description"]').value.trim();
        const nullable = item.querySelector('[data-field="nullable"]').checked;
        const constraintValue = item.querySelector('[data-field="constraints"]').value;
        
        // Handle constraints
        const constraints = [];
        if (constraintValue && constraintValue !== 'NONE') {
            constraints.push(constraintValue);
        }
        
        const column = {
            name: name,
            type: type,
            max_length: maxLength ? parseInt(maxLength) : null,
            nullable: nullable,
            default: defaultValue || null,
            position: index + 1,
            description: description || null,
            constraints: constraints
        };
        
        columns.push(column);
    });
    
    // Collect relationships
    const relationships = [];
    const relationshipItems = document.querySelectorAll('.relationship-item');
    
    relationshipItems.forEach((item, index) => {
        const relationshipType = item.querySelector('[data-field="relationship_type"]').value;
        const referencedTable = item.querySelector('[data-field="referenced_table"]').value.trim();
        const referencedColumn = item.querySelector('[data-field="referenced_column"]').value.trim();
        const description = item.querySelector('[data-field="description"]').value.trim();
        
        if (relationshipType && referencedTable && referencedColumn) {
            const relationship = {
                relationship_type: relationshipType,
                referenced_table: referencedTable,
                referenced_column: referencedColumn,
                description: description || null
            };
            
            relationships.push(relationship);
        } else if (relationshipType || referencedTable || referencedColumn || description) {
            // If any field is filled, validate all required fields
            if (!relationshipType) {
                throw new Error(`Relationship ${index + 1}: Type is required`);
            }
            if (!referencedTable) {
                throw new Error(`Relationship ${index + 1}: Referenced table is required`);
            }
            if (!referencedColumn) {
                throw new Error(`Relationship ${index + 1}: Referenced column is required`);
            }
        }
    });
    
    return {
        business_id: businessId,
        table_name: tableName,
        schema_description: schemaDescription,
        columns: columns,
        relationships: relationships
    };
}

// Save schema
async function saveSchema() {
    const saveBtn = document.getElementById('saveBtn');
    const originalText = saveBtn.innerHTML;
    
    try {
        saveBtn.innerHTML = '<div class="loading"></div> Saving...';
        saveBtn.disabled = true;
        
        const formData = collectFormData();
        
        const response = await fetch(`/admin/businesses/${formData.business_id}/schemas`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify(formData)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            showAlert(`Schema "${formData.table_name}" created successfully!`, 'success');
            // Clear draft after successful save
            sessionStorage.removeItem('schema-manager-draft');
            setTimeout(() => {
                resetForm();
            }, 2000);
        } else {
            throw new Error(result.detail || 'Failed to save schema');
        }
        
    } catch (error) {
        
        showAlert(error.message, 'error');
    } finally {
        saveBtn.innerHTML = originalText;
        saveBtn.disabled = false;
    }
}

// Reset form
function resetForm() {
    const hasChanges = document.getElementById('tableName').value || 
                     document.getElementById('schemaDescription').value.trim() ||
                     document.querySelectorAll('.column-item').length > 1 ||
                     document.querySelectorAll('.relationship-item').length > 0;
    
    if (hasChanges) {
        const confirmReset = confirm('Are you sure you want to reset the form? All unsaved changes will be lost.');
        if (!confirmReset) {
            return;
        }
    }
    
    document.getElementById('businessId').value = '';
    document.getElementById('tableName').innerHTML = '<option value="">Select a business first</option>';
    document.getElementById('schemaDescription').value = '';
    
    // Clear columns
    document.getElementById('columnsContainer').innerHTML = '';
    columnCount = 0;
    
    // Clear relationships
    document.getElementById('relationshipsContainer').innerHTML = '';
    relationshipCount = 0;
    
    availableColumns = [];
    
    // Clear alerts
    document.getElementById('alertContainer').innerHTML = '';
    
    // Clear draft
    sessionStorage.removeItem('schema-manager-draft');
    
    showAlert('Form has been reset', 'success');
}

// Go back to admin
function goBack() {
    const hasChanges = document.getElementById('tableName').value || 
                     document.getElementById('schemaDescription').value.trim() ||
                     document.querySelectorAll('.column-item').length > 1 ||
                     document.querySelectorAll('.relationship-item').length > 0;
    
    if (hasChanges) {
        const confirmLeave = confirm('You have unsaved changes. Are you sure you want to leave?');
        if (!confirmLeave) {
            return;
        }
    }
    
    window.location.href = './admin.html';
}

// Show alert messages
function showAlert(message, type = 'info') {
    
    const alertContainer = document.getElementById('alertContainer');
    if (!alertContainer) {
        // Create alert container if it doesn't exist
        const container = document.createElement('div');
        container.id = 'alertContainer';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
            max-width: 400px;
        `;
        document.body.appendChild(container);
    }
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.style.cssText = `
        padding: 12px 16px;
        margin-bottom: 10px;
        border-radius: 4px;
        color: white;
        font-weight: 500;
        position: relative;
        box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        background-color: ${type === 'error' ? '#dc3545' : type === 'success' ? '#28a745' : type === 'warning' ? '#ffc107' : type === 'info' ? '#17a2b8' : '#17a2b8'};
    `;
    
    alertDiv.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()" style="
            position: absolute;
            top: 8px;
            right: 12px;
            background: none;
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
            padding: 0;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        ">×</button>
    `;
    
    const container = document.getElementById('alertContainer');
    container.appendChild(alertDiv);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentElement) {
            alertDiv.remove();
        }
    }, 5000);
}

// Utility function to format table names (not needed for dropdown, but kept for compatibility)
function formatTableName(input) {
    // This function is no longer used since table names come from dropdown
    // but kept for backward compatibility
    return;
}

// Utility function to format column names
function formatColumnName(input) {
    let value = input.value;
    // Convert to lowercase and replace spaces with underscores
    value = value.toLowerCase().replace(/\s+/g, '_');
    // Remove invalid characters
    value = value.replace(/[^a-z0-9_]/g, '');
    // Ensure it starts with a letter
    if (value && !/^[a-z]/.test(value)) {
        value = 'col_' + value;
    }
    input.value = value;
    updateAvailableColumns();
}

// Auto-save draft to sessionStorage
function saveDraft() {
    try {
        const formData = {
            businessId: document.getElementById('businessId').value,
            tableName: document.getElementById('tableName').value,
            schemaDescription: document.getElementById('schemaDescription').value,
            columns: [],
            relationships: []
        };
        
        // Save column data
        const columnItems = document.querySelectorAll('.column-item');
        columnItems.forEach((item) => {
            const columnData = {};
            const inputs = item.querySelectorAll('[data-field]');
            inputs.forEach(input => {
                const field = input.getAttribute('data-field');
                if (input.type === 'checkbox') {
                    columnData[field] = input.checked;
                } else {
                    columnData[field] = input.value;
                }
            });
            
            // Save constraint states
            columnData.constraints = [];
            const activeConstraints = item.querySelectorAll('.constraint-tag.active');
            activeConstraints.forEach(tag => {
                columnData.constraints.push(tag.textContent.trim());
            });
            
            formData.columns.push(columnData);
        });
        
        // Save relationship data
        const relationshipItems = document.querySelectorAll('.relationship-item');
        relationshipItems.forEach((item) => {
            const relationshipData = {};
            const inputs = item.querySelectorAll('[data-field]');
            inputs.forEach(input => {
                const field = input.getAttribute('data-field');
                relationshipData[field] = input.value;
            });
            formData.relationships.push(relationshipData);
        });
        
        sessionStorage.setItem('schema-manager-draft', JSON.stringify(formData));
    } catch (error) {
        
    }
}

// Load draft from sessionStorage
function loadDraft() {
    try {
        const draftData = sessionStorage.getItem('schema-manager-draft');
        if (draftData) {
            const formData = JSON.parse(draftData);
            
            // Check if there's meaningful data to restore
            const hasMeaningfulData = formData.businessId || 
                                    formData.tableName || 
                                    formData.schemaDescription ||
                                    (formData.columns && formData.columns.some(col => col.name)) ||
                                    (formData.relationships && formData.relationships.some(rel => rel.relationship_type));
            
            if (hasMeaningfulData) {
                const restore = confirm('Found unsaved changes from your previous session. Would you like to restore them?');
                if (restore) {
                    // Load basic data
                    document.getElementById('businessId').value = formData.businessId || '';
                    // Set table name if business is selected and table exists
                    if (formData.businessId && formData.tableName) {
                        // Load tables first, then set the selected table
                        loadTables(formData.businessId).then(() => {
                            document.getElementById('tableName').value = formData.tableName || '';
                        }).catch(() => {});
                    }
                    document.getElementById('schemaDescription').value = formData.schemaDescription || '';
                    
                    // Load columns
                    if (formData.columns && formData.columns.length > 0) {
                        document.getElementById('columnsContainer').innerHTML = '';
                        columnCount = 0;
                        
                        formData.columns.forEach(columnData => {
                            addColumn();
                            const columnItem = document.querySelector('.column-item:last-child');
                            
                            // Set field values
                            Object.keys(columnData).forEach(field => {
                                if (field === 'constraints') return;
                                const input = columnItem.querySelector(`[data-field="${field}"]`);
                                if (input) {
                                    if (input.type === 'checkbox') {
                                        input.checked = columnData[field];
                                    } else {
                                        input.value = columnData[field] || '';
                                    }
                                }
                            });
                            
                            // Set constraints
                            if (columnData.constraints) {
                                columnData.constraints.forEach(constraintText => {
                                    const constraintTag = Array.from(columnItem.querySelectorAll('.constraint-tag')).find(tag => 
                                        tag.textContent.trim() === constraintText
                                    );
                                    if (constraintTag) {
                                        constraintTag.classList.add('active');
                                    }
                                });
                            }
                        });
                    }
                    
                    // Load relationships
                    if (formData.relationships && formData.relationships.length > 0) {
                        formData.relationships.forEach(relationshipData => {
                            addRelationship();
                            const relationshipItem = document.querySelector('.relationship-item:last-child');
                            
                            Object.keys(relationshipData).forEach(field => {
                                const input = relationshipItem.querySelector(`[data-field="${field}"]`);
                                if (input) {
                                    input.value = relationshipData[field] || '';
                                }
                            });
                        });
                    }
                    
                    updateAvailableColumns();
                    showAlert('Draft restored successfully', 'success');
                }
            }
            
            // Clear the draft after loading or declining
            sessionStorage.removeItem('schema-manager-draft');
        }
    } catch (error) {
        
        sessionStorage.removeItem('schema-manager-draft');
    }
}

// Handle Enter key navigation
document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA' && !e.target.classList.contains('btn')) {
        e.preventDefault();
        const inputs = Array.from(document.querySelectorAll('input:not([type="checkbox"]), select, textarea'));
        const visibleInputs = inputs.filter(input => {
            const rect = input.getBoundingClientRect();
            return rect.width > 0 && rect.height > 0;
        });
        
        const currentIndex = visibleInputs.indexOf(e.target);
        if (currentIndex < visibleInputs.length - 1) {
            visibleInputs[currentIndex + 1].focus();
        }
    }
});

// Handle Escape key to close dropdowns
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const dropdowns = document.querySelectorAll('.column-dropdown');
        dropdowns.forEach(dropdown => {
            dropdown.style.display = 'none';
        });
    }
});

// Table name formatting is no longer needed since we use dropdown
// Event listeners are now handled in loadBusinesses() function

// Test API connectivity
async function testAPIConnectivity() {
    try {
        showAlert('Testing API connectivity...', 'info');
        const response = await fetch('/admin/businesses');
        
        
        if (response.ok) {
            const data = await response.json();
            showAlert(`API test successful, businesses found: ${data.businesses?.length || 0}`, 'success');
            return true;
        } else {
            showAlert(`API test failed with status: ${response.status}`, 'warning');
            return false;
        }
    } catch (error) {
        showAlert('API connectivity test failed', 'error');
        return false;
    }
}

// Check for edit mode URL parameters
async function checkEditMode() {
    const urlParams = new URLSearchParams(window.location.search);
    const businessId = urlParams.get('business_id');
    const tableName = urlParams.get('table_name');
    const mode = urlParams.get('mode');
    
    if (mode === 'edit' && businessId && tableName) {
        
        
        // Wait for businesses to load first
        let attempts = 0;
        const maxAttempts = 20;
        
        const waitForBusinesses = () => {
            return new Promise((resolve) => {
                const checkBusinesses = () => {
                    const businessSelect = document.getElementById('businessId');
                    if (businessSelect && businessSelect.options.length > 1) {
                        resolve();
                    } else if (attempts < maxAttempts) {
                        attempts++;
                        setTimeout(checkBusinesses, 500);
                    } else {
                        
                        resolve();
                    }
                };
                checkBusinesses();
            });
        };
        
        await waitForBusinesses();
        
        // Set business and wait for tables to load
        const businessSelect = document.getElementById('businessId');
        if (businessSelect) {
            businessSelect.value = businessId;
            
            try {
                await onBusinessChange();
                
                // Wait for tables to be populated
                let tableAttempts = 0;
                const waitForTables = () => {
                    return new Promise((resolve) => {
                        const checkTables = () => {
                            const tableSelect = document.getElementById('tableName');
                            if (tableSelect && tableSelect.options.length > 1) {
                                resolve();
                            } else if (tableAttempts < maxAttempts) {
                                tableAttempts++;
                                setTimeout(checkTables, 500);
                            } else {
                                
                                resolve();
                            }
                        };
                        checkTables();
                    });
                };
                
                await waitForTables();
                
                // Set table and load schema
                const tableSelect = document.getElementById('tableName');
                if (tableSelect) {
                    tableSelect.value = tableName;
                    await loadExistingSchema();
                }
            } catch (error) {
                
                showAlert('Error loading schema for editing', 'error');
            }
        }
    }
}

// Load existing schema functionality
async function loadExistingSchema() {
    const businessId = document.getElementById('businessId').value;
    const tableName = document.getElementById('tableName').value;
    
    if (!businessId || !tableName) {
        showAlert('Please select a business and table first', 'error');
        return;
    }
    
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        const headers = {};
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        
        
        // Show loading indicator
        showAlert('Loading schema details...', 'info');
        
        let response = await fetch(`/admin/businesses/${businessId}/schemas`, { headers });
        
        if (!response.ok) {
            
            if (response.status === 401) {
                showAlert('Authentication failed. Please log in again.', 'error');
                return;
            } else if (response.status === 404) {
                showAlert(`No schemas found for business ${businessId}`, 'error');
                return;
            } else {
                const errorText = await response.text();
                
                showAlert(`Failed to load schemas: ${response.status} ${response.statusText}`, 'error');
                return;
            }
        }
        
        const data = await response.json();
        
        
        // Find the specific schema for the table
        const schema = data.schemas?.find(s => s.table_name === tableName);
        if (!schema) {
            
            showAlert(`No existing schema found for table "${tableName}". You can create a new one.`, 'info');
            return;
        }
            
            
            
            // Populate form with existing schema data
            document.getElementById('schemaDescription').value = schema.schema_description || '';
            
            // Clear existing columns and populate with schema columns
            clearColumns();
            if (schema.columns && schema.columns.length > 0) {
                
                await populateColumnsFromSchema(schema.columns);
            } else {
                
            }
            
            // Clear existing relationships and populate with schema relationships
            clearRelationships();
            if (schema.relationships && schema.relationships.length > 0) {
                populateRelationshipsFromSchema(schema.relationships);
            }
            
            // Update save button to indicate update mode
            const saveBtn = document.getElementById('saveBtn');
            const deleteBtn = document.getElementById('deleteBtn');
            saveBtn.innerHTML = '🔄 Update Schema';
            saveBtn.setAttribute('data-update-mode', 'true');
            
            // Show delete button when in update mode
            if (deleteBtn) {
                deleteBtn.style.display = 'inline-block';
            }
            
            showAlert(`Loaded existing schema for table "${tableName}"`, 'success');
    } catch (error) {
        showAlert('Error loading existing schema', 'error');
    }
}

// Populate columns from existing schema
async function populateColumnsFromSchema(schemaColumns) {
    // Clear existing columns first
    clearColumns();
    
    for (let index = 0; index < schemaColumns.length; index++) {
        const col = schemaColumns[index];
        
        // Create column directly without async database loading
        columnCount++;
        const container = document.getElementById('columnsContainer');
        const columnDiv = document.createElement('div');
        columnDiv.className = 'column-item';
        columnDiv.setAttribute('data-column-id', columnCount);
        
        columnDiv.innerHTML = `
            <div class="column-header">
                <div class="column-number">${columnCount}</div>
                <input type="text" class="column-input" placeholder="Column Name" data-field="name" required>
                <select class="column-input" data-field="type" required>
                    <option value="">Select Type</option>
                    <option value="VARCHAR">VARCHAR</option>
                    <option value="TEXT">TEXT</option>
                    <option value="INTEGER">INTEGER</option>
                    <option value="BIGINT">BIGINT</option>
                    <option value="DECIMAL">DECIMAL</option>
                    <option value="BOOLEAN">BOOLEAN</option>
                    <option value="DATE">DATE</option>
                    <option value="TIMESTAMP">TIMESTAMP</option>
                    <option value="JSON">JSON</option>
                </select>
                <input type="number" class="column-input" placeholder="Max Length" data-field="max_length">
                <input type="text" class="column-input" placeholder="Default Value" data-field="default">
                <select class="column-input constraint-select" data-field="constraints">
                    <option value="NONE">None</option>
                    <option value="PRIMARY KEY">PRIMARY KEY</option>
                    <option value="FOREIGN KEY">FOREIGN KEY</option>
                    <option value="UNIQUE">UNIQUE</option>
                    <option value="NOT NULL">NOT NULL</option>
                    <option value="INDEX">INDEX</option>
                    <option value="AUTO_INCREMENT">AUTO INCREMENT</option>
                </select>
                <div class="nullable-section">
                    <input type="checkbox" id="nullable-${columnCount}" data-field="nullable" checked>
                    <label for="nullable-${columnCount}">Nullable</label>
                </div>
                <input type="text" class="column-input" placeholder="Business Meaning" data-field="business_meaning">
                <input type="text" class="column-input" placeholder="Description" data-field="description">
                <button class="remove-btn" onclick="removeColumn(this)" title="Remove Column">×</button>
            </div>
        `;
        
        container.appendChild(columnDiv);
        
        if (columnDiv) {
            const nameInput = columnDiv.querySelector('[data-field="name"]');
            const typeSelect = columnDiv.querySelector('[data-field="type"]');
            const lengthInput = columnDiv.querySelector('[data-field="max_length"]');
            const defaultInput = columnDiv.querySelector('[data-field="default"]');
            const nullableCheckbox = columnDiv.querySelector('[data-field="nullable"]');
            const constraintSelect = columnDiv.querySelector('[data-field="constraints"]');
            const descriptionInput = columnDiv.querySelector('[data-field="description"]');
            const businessMeaningInput = columnDiv.querySelector('[data-field="business_meaning"]');
            
            if (nameInput) {
                nameInput.value = col.name || '';
            }
            if (typeSelect) {
                typeSelect.value = col.type || '';
            }
            if (lengthInput && col.max_length) {
                lengthInput.value = col.max_length;
            }
            if (defaultInput && col.default) {
                defaultInput.value = col.default;
            }
            if (nullableCheckbox) {
                nullableCheckbox.checked = col.nullable !== false;
            }
            if (descriptionInput) {
                descriptionInput.value = col.description || '';
            }
            if (businessMeaningInput) {
                businessMeaningInput.value = col.business_meaning || '';
            }
            
            // Set constraint
            let constraintValue = 'NONE';
            if (col.constraints && Array.isArray(col.constraints) && col.constraints.length > 0) {
                constraintValue = col.constraints[0];
            }
            if (constraintSelect) {
                constraintSelect.value = constraintValue;
            }
        } else {
        }
    }
    
    updateAvailableColumns();
}

// Populate relationships from existing schema
function populateRelationshipsFromSchema(schemaRelationships) {
    schemaRelationships.forEach((rel) => {
        addRelationship();
        const relationshipDiv = document.querySelector(`[data-relationship-id="${relationshipCount}"]`);
        
        if (relationshipDiv) {
            const typeSelect = relationshipDiv.querySelector('[data-field="relationship_type"]');
            const toTableInput = relationshipDiv.querySelector('[data-field="referenced_table"]');
            const toColumnInput = relationshipDiv.querySelector('[data-field="referenced_column"]');
            const descriptionInput = relationshipDiv.querySelector('[data-field="description"]');
            
            if (typeSelect) typeSelect.value = rel.relationship_type || '';
            if (toTableInput) toTableInput.value = rel.referenced_table || '';
            if (toColumnInput) toColumnInput.value = rel.referenced_column || '';
            if (descriptionInput) descriptionInput.value = rel.description || '';
        }
    });
}
// Clear all relationships
function clearRelationships() {
    const container = document.getElementById('relationshipsContainer');
    container.innerHTML = '';
    relationshipCount = 0;
}

// Modified save function to handle both create and update
async function saveSchema() {
    const saveBtn = document.getElementById('saveBtn');
    const isUpdateMode = saveBtn.getAttribute('data-update-mode') === 'true';
    
    const businessId = document.getElementById('businessId').value;
    const tableName = document.getElementById('tableName').value;
    const schemaDescription = document.getElementById('schemaDescription').value.trim();
    
    // Validation
    if (!businessId || !tableName || !schemaDescription) {
        showAlert('Please fill in all required fields (Business, Table Name, Schema Description)', 'error');
        return;
    }
    
    // Collect form data (existing logic)
    const columns = [];
    const columnItems = document.querySelectorAll('.column-item');
    
    columnItems.forEach((item, index) => {
        const name = item.querySelector('[data-field="name"]').value.trim();
        const type = item.querySelector('[data-field="type"]').value;
        const maxLength = item.querySelector('[data-field="max_length"]').value;
        const defaultValue = item.querySelector('[data-field="default"]').value;
        const businessMeaning = item.querySelector('[data-field="business_meaning"]').value.trim();
        const nullable = item.querySelector('[data-field="nullable"]').checked;
        const constraintValue = item.querySelector('[data-field="constraints"]').value;
        
        const constraints = [];
        if (constraintValue && constraintValue !== 'NONE') {
            constraints.push(constraintValue);
        }
        
        const column = {
            name: name,
            type: type,
            max_length: maxLength ? parseInt(maxLength) : null,
            nullable: nullable,
            default: defaultValue || null,
            position: index + 1,
            business_meaning: businessMeaning || null,
            description: item.querySelector('[data-field="description"]').value.trim() || null,
            constraints: constraints
        };
        
        columns.push(column);
    });
    
    // Collect relationships (aligned with relationship template fields)
    const relationships = [];
    const relationshipItems = document.querySelectorAll('.relationship-item');
    
    relationshipItems.forEach((item) => {
        const relationshipType = item.querySelector('[data-field="relationship_type"]').value;
        const referencedTable = item.querySelector('[data-field="referenced_table"]').value.trim();
        const referencedColumn = item.querySelector('[data-field="referenced_column"]').value.trim();
        const description = item.querySelector('[data-field="description"]').value.trim();
        
        // Note: From-column is chosen from availableColumns via dropdown on the column row; here we only store referenced side
        if (relationshipType && referencedTable && referencedColumn) {
            relationships.push({
                relationship_type: relationshipType,
                referenced_table: referencedTable,
                referenced_column: referencedColumn,
                description: description || null
            });
        }
    });
    
    const schemaData = {
        business_id: businessId,
        table_name: tableName,
        schema_description: schemaDescription,
        columns: columns,
        relationships: relationships
    };
    
    try {
        saveBtn.disabled = true;
        saveBtn.innerHTML = isUpdateMode ? '🔄 Updating...' : '💾 Saving...';
        
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        const headers = {
            'Content-Type': 'application/json'
        };
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        const method = isUpdateMode ? 'PUT' : 'POST';
        const endpoint = isUpdateMode 
            ? `/admin/businesses/${businessId}/schemas/${tableName}`
            : `/admin/businesses/${businessId}/schemas`;
        
        
        let response = await fetch(endpoint, {
            method: method,
            headers: headers,
            body: JSON.stringify(schemaData)
        });
        
        if (!response.ok && response.status === 401) {
            delete headers['Authorization'];
            response = await fetch(endpoint, {
                method: method,
                headers: headers,
                body: JSON.stringify(schemaData)
            });
        }
        
        if (response.ok) {
            const result = await response.json();
            
            
            const action = isUpdateMode ? 'updated' : 'created';
            showAlert(`Schema ${action} successfully!`, 'success');
            
            // Reset update mode
            saveBtn.innerHTML = '💾 Save Schema';
            saveBtn.removeAttribute('data-update-mode');
            
            // Hide delete button when not in update mode
            const deleteBtn = document.getElementById('deleteBtn');
            if (deleteBtn) {
                deleteBtn.style.display = 'none';
            }
            
            // Clear draft
            localStorage.removeItem('schemaDraft');
            
        } else {
            const errorText = await response.text();
            
            showAlert(`Error ${isUpdateMode ? 'updating' : 'saving'} schema: ${errorText}`, 'error');
        }
        
    } catch (error) {
        
        showAlert(`Error ${isUpdateMode ? 'updating' : 'saving'} schema`, 'error');
    } finally {
        saveBtn.disabled = false;
        if (!saveBtn.getAttribute('data-update-mode')) {
            saveBtn.innerHTML = '💾 Save Schema';
        } else {
            saveBtn.innerHTML = '🔄 Update Schema';
        }
    }
}

// Delete schema functionality
async function deleteSchema() {
    const businessId = document.getElementById('businessId').value;
    const tableName = document.getElementById('tableName').value;
    
    if (!businessId || !tableName) {
        showAlert('Please select a business and table first', 'error');
        return;
    }
    
    // Double confirmation for delete operation
    const confirmDelete = confirm(
        `⚠️ WARNING: This will permanently delete the schema for table "${tableName}".\n\n` +
        'This action cannot be undone. Are you absolutely sure you want to delete this schema?'
    );
    
    if (!confirmDelete) {
        return;
    }
    
    // Second confirmation
    const finalConfirm = confirm(
        `🚨 FINAL CONFIRMATION\n\n` +
        `Delete schema for table: "${tableName}"\n` +
        `Business ID: ${businessId}\n\n` +
        'Type "DELETE" in the next prompt to confirm.'
    );
    
    if (!finalConfirm) {
        return;
    }
    
    const userInput = prompt('Type "DELETE" (in capital letters) to confirm deletion:');
    if (userInput !== 'DELETE') {
        showAlert('Deletion cancelled - confirmation text did not match', 'info');
        return;
    }
    
    try {
        const deleteBtn = document.getElementById('deleteBtn');
        deleteBtn.disabled = true;
        deleteBtn.innerHTML = '🗑️ Deleting...';
        
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        const headers = {};
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        
        let response = await fetch(`/admin/businesses/${businessId}/schemas/${tableName}`, {
            method: 'DELETE',
            headers: headers
        });
        
        if (!response.ok && response.status === 401) {
            response = await fetch(`/admin/businesses/${businessId}/schemas/${tableName}`, {
                method: 'DELETE'
            });
        }
        
        if (response.ok) {
            const result = await response.json();
            
            
            showAlert(`Schema for table "${tableName}" deleted successfully!`, 'success');
            
            // Reset form and hide delete button
            resetForm();
            deleteBtn.style.display = 'none';
            
            // Reset save button
            const saveBtn = document.getElementById('saveBtn');
            saveBtn.innerHTML = '💾 Save Schema';
            saveBtn.removeAttribute('data-update-mode');
            
        } else {
            const errorText = await response.text();
            
            showAlert(`Error deleting schema: ${errorText}`, 'error');
        }
        
    } catch (error) {
        
        showAlert('Error deleting schema', 'error');
    } finally {
        const deleteBtn = document.getElementById('deleteBtn');
        deleteBtn.disabled = false;
        deleteBtn.innerHTML = '🗑️ Delete Schema';
    }
}

// Auto-save draft periodically
setInterval(saveDraft, 30000); // Save every 30 seconds

// Save draft before page unload
window.addEventListener('beforeunload', function(e) {
    saveDraft();
});

// Add test button for debugging (only in development)
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(() => {
            const testBtn = document.createElement('button');
            testBtn.textContent = 'Test API';
            testBtn.style.position = 'fixed';
            testBtn.style.top = '10px';
            testBtn.style.right = '10px';
            testBtn.style.zIndex = '9999';
            testBtn.style.padding = '5px 10px';
            testBtn.style.fontSize = '12px';
            testBtn.onclick = testAPIConnectivity;
            document.body.appendChild(testBtn);
        }, 2000);
    });
}