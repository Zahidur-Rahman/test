// Business Schema Manager JavaScript
let columnCount = 0;
let relationshipCount = 0;

document.addEventListener('DOMContentLoaded', function() {
    loadBusinesses();
    
    const businessSelect = document.getElementById('businessId');
    const tableSelect = document.getElementById('tableName');
    
    if (businessSelect) {
        businessSelect.addEventListener('change', onBusinessChange);
    }
    
    if (tableSelect) {
        tableSelect.addEventListener('change', onTableChange);
    }
    
    // Check for edit mode URL parameters
    setTimeout(() => checkEditMode(), 100);
    
    console.log('Current URL:', window.location.href);
    console.log('Available tokens:', {
        localStorage: localStorage.getItem('token') ? 'present' : 'none',
        sessionStorage: sessionStorage.getItem('token') ? 'present' : 'none'
    });
});

// Load businesses for dropdown
async function loadBusinesses() {
    const select = document.getElementById('businessId');
    select.innerHTML = '<option value="">Loading businesses...</option>';
    select.disabled = true;
    
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        const headers = {};
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        const response = await fetch('/admin/businesses', { headers });
        
        if (response.ok) {
            const data = await response.json();
            select.innerHTML = '<option value="">Select Business</option>';
            
            if (data.businesses && data.businesses.length > 0) {
                data.businesses.forEach(business => {
                    const option = document.createElement('option');
                    option.value = business.business_id;
                    option.textContent = `${business.name || business.business_id} (${business.business_id})`;
                    select.appendChild(option);
                });
            } else {
                select.innerHTML = '<option value="">No businesses found</option>';
            }
        } else {
            throw new Error(`Failed to load businesses: ${response.status}`);
        }
    } catch (error) {
        console.error('Error loading businesses:', error);
        select.innerHTML = '<option value="">Error loading businesses</option>';
        showAlert(`Error loading businesses: ${error.message}`, 'error');
    } finally {
        select.disabled = false;
    }
}

// Handle business selection change
async function onBusinessChange() {
    const businessId = document.getElementById('businessId').value;
    const tableSelect = document.getElementById('tableName');
    const tableFilter = document.getElementById('tableNameFilter');
    
    if (!businessId) {
        tableSelect.innerHTML = '<option value="">Select a business first</option>';
        if (tableFilter) tableFilter.style.display = 'none';
        clearColumns();
        return;
    }
    
    // Show loading state
    tableSelect.innerHTML = '<option value="">Loading tables...</option>';
    tableSelect.disabled = true;
    if (tableFilter) tableFilter.style.display = 'none';
    
    try {
        await loadTables(businessId);
        // Show search filter after tables are loaded
        if (tableSelect.options.length > 1 && tableFilter) {
            tableFilter.style.display = 'block';
            setupTableFilter();
        }
    } catch (error) {
        console.error('Error loading tables:', error);
        showAlert('Error loading tables for selected business', 'error');
        tableSelect.innerHTML = '<option value="">Error loading tables</option>';
    } finally {
        tableSelect.disabled = false;
    }
}

// Load tables for selected business
async function loadTables(businessId) {
    const tableSelect = document.getElementById('tableName');
    
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        const headers = {};
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        console.log(`Loading tables for business: ${businessId}`);
        let response = await fetch(`/admin/businesses/${businessId}/tables`, { headers });
        
        if (!response.ok && response.status === 401) {
            console.log('Trying without authentication...');
            response = await fetch(`/admin/businesses/${businessId}/tables`);
        }
        
        if (response.ok) {
            const data = await response.json();
            tableSelect.innerHTML = '<option value="">Select Table</option>';
            
            const tables = data.tables || data.data || data || [];
            
            if (tables.length > 0) {
                tables.forEach(table => {
                    const option = document.createElement('option');
                    option.value = typeof table === 'string' ? table : table.name;
                    option.textContent = typeof table === 'string' ? table : table.name;
                    tableSelect.appendChild(option);
                });
                
                console.log(`Loaded ${tables.length} tables for business ${businessId}`);
            } else {
                tableSelect.innerHTML = '<option value="">No tables found</option>';
                showAlert('No tables found for this business', 'warning');
            }
        } else {
            throw new Error(`Failed to fetch tables: ${response.status} ${response.statusText}`);
        }
    } catch (error) {
        console.error('Error in loadTables:', error);
        tableSelect.innerHTML = '<option value="">Error loading tables</option>';
        throw error;
    }
}

// Setup table filter functionality
function setupTableFilter() {
    const tableSelect = document.getElementById('tableName');
    const tableFilter = document.getElementById('tableNameFilter');
    
    if (!tableFilter || !tableSelect) return;
    
    // Store original options
    const originalOptions = Array.from(tableSelect.options);
    
    tableFilter.addEventListener('input', function() {
        const filterValue = this.value.toLowerCase();
        
        // Clear current options
        tableSelect.innerHTML = '';
        
        // Filter and add matching options
        originalOptions.forEach(option => {
            if (option.textContent.toLowerCase().includes(filterValue) || option.value === '') {
                tableSelect.appendChild(option.cloneNode(true));
            }
        });
    });
}

// Handle table selection change
async function onTableChange() {
    const businessId = document.getElementById('businessId').value;
    const tableName = document.getElementById('tableName').value;
    
    if (!businessId || !tableName) {
        clearColumns();
        return;
    }
    
    // Clear existing columns and show empty state
    clearColumns();
    showAlert('Table selected. Use "Add Column" to add columns from the database.', 'info');
}

// Load available columns from database
async function loadAvailableColumns(businessId, tableName) {
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        const headers = {};
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        const response = await fetch(`/admin/businesses/${businessId}/tables/${tableName}/columns`, { headers });
        
        if (response.ok) {
            const data = await response.json();
            return data.columns || [];
        } else {
            console.error('Failed to load columns:', response.status);
            return [];
        }
    } catch (error) {
        console.error('Error loading available columns:', error);
        return [];
    }
}

// Populate column details when selected from dropdown
function populateColumnDetails(selectElement, columnId) {
    const selectedOption = selectElement.options[selectElement.selectedIndex];
    const columnDiv = document.querySelector(`[data-column-id="${columnId}"]`);
    
    if (selectedOption && columnDiv) {
        const nameInput = columnDiv.querySelector('[data-field="name"]');
        const typeInput = columnDiv.querySelector('[data-field="type"]');
        const constraintSelect = columnDiv.querySelector('[data-field="constraints"]');
        
        if (nameInput) nameInput.value = selectedOption.value;
        if (typeInput) typeInput.value = selectedOption.dataset.type || '';
        if (constraintSelect) {
            const constraint = selectedOption.dataset.constraint || 'NONE';
            constraintSelect.value = constraint;
        }
    }
}

// Add a new column with dropdown selection
async function addColumn() {
    const businessId = document.getElementById('businessId').value;
    const tableName = document.getElementById('tableName').value;
    
    if (!businessId || !tableName) {
        showAlert('Please select a business and table first', 'error');
        return;
    }
    
    try {
        // Load available columns from the database
        const columns = await loadAvailableColumns(businessId, tableName);
        
        if (columns.length === 0) {
            showAlert('No columns found in the selected table', 'error');
            return;
        }
        
        columnCount++;
        const container = document.getElementById('columnsContainer');
        
        const columnDiv = document.createElement('div');
        columnDiv.className = 'column-item';
        columnDiv.setAttribute('data-column-id', columnCount);
        
        // Create column dropdown options
        const columnOptions = columns.map(col => 
            `<option value="${col.name}" data-type="${col.type}" data-constraint="${col.constraint || 'NONE'}" data-nullable="${col.nullable}">${col.name} (${col.type})</option>`
        ).join('');
        
        columnDiv.innerHTML = `
            <div class="column-header">
                <div class="column-number">${columnCount}</div>
                <select class="column-input" data-field="column-select" onchange="populateColumnDetails(this, ${columnCount})" required>
                    <option value="">Choose a column</option>
                    ${columnOptions}
                </select>
                <input type="text" class="column-input" placeholder="Column Name" data-field="name" readonly>
                <input type="text" class="column-input" placeholder="Data Type" data-field="type" readonly>
                <select class="column-input constraint-select" data-field="constraints">
                    <option value="NONE">None</option>
                    <option value="PRIMARY KEY">PRIMARY KEY</option>
                    <option value="FOREIGN KEY">FOREIGN KEY</option>
                    <option value="UNIQUE">UNIQUE</option>
                    <option value="NOT NULL">NOT NULL</option>
                    <option value="INDEX">INDEX</option>
                    <option value="AUTO_INCREMENT">AUTO INCREMENT</option>
                </select>
                <input type="text" class="column-input" placeholder="Description" data-field="description">
                <button class="remove-btn" onclick="removeColumn(${columnCount})" title="Remove Column">×</button>
            </div>
        `;
        
        container.appendChild(columnDiv);
        
    } catch (error) {
        console.error('Error adding column:', error);
        showAlert('Error loading column options', 'error');
    }
}

// Remove a column
function removeColumn(columnId) {
    if (document.querySelectorAll('.column-item').length <= 1) {
        showAlert('At least one column is required', 'error');
        return;
    }
    
    const confirmation = confirm('Are you sure you want to remove this column?');
    if (!confirmation) return;
    
    const columnItem = document.querySelector(`[data-column-id="${columnId}"]`);
    if (columnItem) {
        columnItem.remove();
        updateColumnNumbers();
    }
}

// Update column numbers after removal
function updateColumnNumbers() {
    const columns = document.querySelectorAll('.column-item');
    columns.forEach((column, index) => {
        const numberDiv = column.querySelector('.column-number');
        numberDiv.textContent = index + 1;
        column.setAttribute('data-column-id', index + 1);
    });
    columnCount = columns.length;
}

// Clear all columns
function clearColumns() {
    const container = document.getElementById('columnsContainer');
    container.innerHTML = '';
    columnCount = 0;
}

// Add a new relationship
function addRelationship() {
    relationshipCount++;
    const relationshipsContainer = document.getElementById('relationshipsContainer');
    
    const relationshipDiv = document.createElement('div');
    relationshipDiv.className = 'relationship-item';
    relationshipDiv.setAttribute('data-relationship-id', relationshipCount);
    
    relationshipDiv.innerHTML = `
        <div class="relationship-header">
            <div class="relationship-number">#${relationshipCount}</div>
            <div class="form-group">
                <label>Relationship Type *</label>
                <select data-field="type" class="relationship-input" required>
                    <option value="">Select type</option>
                    <option value="PRIMARY KEY">PRIMARY KEY</option>
                    <option value="FOREIGN KEY">FOREIGN KEY</option>
                </select>
            </div>
            <div class="form-group">
                <label>Related Table *</label>
                <input type="text" data-field="related_table" class="relationship-input" placeholder="e.g., orders" required>
            </div>
            <div class="form-group">
                <label>Foreign Key Column *</label>
                <input type="text" data-field="foreign_key" class="relationship-input" placeholder="e.g., customer_id" required>
            </div>
            <div class="form-group">
                <label>Referenced Column *</label>
                <input type="text" data-field="referenced_column" class="relationship-input" placeholder="e.g., id" required>
            </div>
            <div class="form-group">
                <label>Description</label>
                <input type="text" data-field="description" class="relationship-input" placeholder="Brief description of this relationship">
            </div>
            <button class="remove-btn" onclick="removeRelationship(${relationshipCount})" title="Remove Relationship">×</button>
        </div>
    `;
    
    relationshipsContainer.appendChild(relationshipDiv);
}

// Remove a relationship
function removeRelationship(relationshipId) {
    const confirmation = confirm('Are you sure you want to remove this relationship?');
    if (!confirmation) return;
    
    const relationshipItem = document.querySelector(`[data-relationship-id="${relationshipId}"]`);
    if (relationshipItem) {
        relationshipItem.remove();
        updateRelationshipNumbers();
    }
}

// Update relationship numbers after removal
function updateRelationshipNumbers() {
    const relationships = document.querySelectorAll('.relationship-item');
    relationships.forEach((relationship, index) => {
        const numberDiv = relationship.querySelector('.relationship-number');
        numberDiv.textContent = `#${index + 1}`;
        relationship.setAttribute('data-relationship-id', index + 1);
    });
    relationshipCount = relationships.length;
}

// Clear all relationships
function clearRelationships() {
    const container = document.getElementById('relationshipsContainer');
    container.innerHTML = '';
    relationshipCount = 0;
}

// Check for edit mode URL parameters
async function checkEditMode() {
    const urlParams = new URLSearchParams(window.location.search);
    const businessId = urlParams.get('business_id');
    const tableName = urlParams.get('table_name');
    const mode = urlParams.get('mode');
    
    if (mode === 'edit' && businessId && tableName) {
        console.log(`Edit mode detected: business_id=${businessId}, table_name=${tableName}`);
        
        // Wait for businesses to load first
        let attempts = 0;
        const maxAttempts = 20;
        
        const waitForBusinesses = () => {
            return new Promise((resolve) => {
                const checkBusinesses = () => {
                    const businessSelect = document.getElementById('businessId');
                    if (businessSelect && businessSelect.options.length > 1) {
                        resolve();
                    } else if (attempts < maxAttempts) {
                        attempts++;
                        setTimeout(checkBusinesses, 500);
                    } else {
                        console.error('Timeout waiting for businesses to load');
                        resolve();
                    }
                };
                checkBusinesses();
            });
        };
        
        await waitForBusinesses();
        
        // Set business and wait for tables to load
        const businessSelect = document.getElementById('businessId');
        if (businessSelect) {
            businessSelect.value = businessId;
            
            try {
                await onBusinessChange();
                
                // Wait for tables to be populated
                let tableAttempts = 0;
                const waitForTables = () => {
                    return new Promise((resolve) => {
                        const checkTables = () => {
                            const tableSelect = document.getElementById('tableName');
                            if (tableSelect && tableSelect.options.length > 1) {
                                resolve();
                            } else if (tableAttempts < maxAttempts) {
                                tableAttempts++;
                                setTimeout(checkTables, 500);
                            } else {
                                console.error('Timeout waiting for tables to load');
                                resolve();
                            }
                        };
                        checkTables();
                    });
                };
                
                await waitForTables();
                
                // Set table and load schema
                const tableSelect = document.getElementById('tableName');
                if (tableSelect) {
                    tableSelect.value = tableName;
                    await loadExistingSchema();
                }
            } catch (error) {
                console.error('Error in edit mode setup:', error);
                showAlert('Error loading schema for editing', 'error');
            }
        }
    }
}

// Load existing schema functionality
async function loadExistingSchema() {
    const businessId = document.getElementById('businessId').value;
    const tableName = document.getElementById('tableName').value;
    
    if (!businessId || !tableName) {
        showAlert('Please select a business and table first', 'error');
        return;
    }
    
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        const headers = {};
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        console.log(`Loading existing schema for table: ${tableName} in business: ${businessId}`);
        
        // Show loading indicator
        showAlert('Loading schema details...', 'info');
        
        let response = await fetch(`/admin/businesses/${businessId}/schemas`, { headers });
        
        if (!response.ok) {
            console.error(`Schema fetch failed with status: ${response.status}`);
            if (response.status === 401) {
                showAlert('Authentication failed. Please log in again.', 'error');
                return;
            } else if (response.status === 404) {
                showAlert(`No schemas found for business ${businessId}`, 'error');
                return;
            } else {
                const errorText = await response.text();
                console.error('Schema fetch error:', errorText);
                showAlert(`Failed to load schemas: ${response.status} ${response.statusText}`, 'error');
                return;
            }
        }
        
        const data = await response.json();
        console.log('Schemas response:', data);
        
        // Find the specific schema for the table
        const schema = data.schemas?.find(s => s.table_name === tableName);
        if (!schema) {
            console.warn(`Schema not found for table: ${tableName}`);
            console.log('Available schemas:', data.schemas?.map(s => s.table_name));
            showAlert(`No existing schema found for table "${tableName}". You can create a new one.`, 'info');
            return;
        }
            
        console.log('Existing schema loaded:', schema);
        
        // Populate form with existing schema data
        document.getElementById('schemaDescription').value = schema.schema_description || '';
        
        // Clear existing columns and populate with schema columns
        clearColumns();
        if (schema.columns && schema.columns.length > 0) {
            populateColumnsFromSchema(schema.columns);
        }
        
        // Clear existing relationships and populate with schema relationships
        clearRelationships();
        if (schema.relationships && schema.relationships.length > 0) {
            populateRelationshipsFromSchema(schema.relationships);
        }
        
        // Update save button to indicate update mode
        const saveBtn = document.getElementById('saveBtn');
        const deleteBtn = document.getElementById('deleteBtn');
        saveBtn.innerHTML = '🔄 Update Schema';
        saveBtn.setAttribute('data-update-mode', 'true');
        
        // Show delete button when in update mode
        if (deleteBtn) {
            deleteBtn.style.display = 'inline-block';
        }
        
        showAlert(`Loaded existing schema for table "${tableName}"`, 'success');
    } catch (error) {
        console.error('Error loading existing schema:', error);
        showAlert('Error loading existing schema', 'error');
    }
}

// Populate columns from existing schema
function populateColumnsFromSchema(schemaColumns) {
    schemaColumns.forEach(async (col, index) => {
        await addColumn();
        const columnDiv = document.querySelector(`[data-column-id="${columnCount}"]`);
        
        if (columnDiv) {
            const columnSelect = columnDiv.querySelector('[data-field="column-select"]');
            const nameInput = columnDiv.querySelector('[data-field="name"]');
            const typeInput = columnDiv.querySelector('[data-field="type"]');
            const constraintSelect = columnDiv.querySelector('[data-field="constraints"]');
            const descriptionInput = columnDiv.querySelector('[data-field="description"]');
            
            if (columnSelect) columnSelect.value = col.name || '';
            if (nameInput) nameInput.value = col.name || '';
            if (typeInput) typeInput.value = col.type || '';
            if (constraintSelect) {
                const constraint = col.constraint || (col.is_primary_key ? 'PRIMARY KEY' : 'NONE');
                constraintSelect.value = constraint;
            }
            if (descriptionInput) descriptionInput.value = col.description || '';
        }
    });
}

// Populate relationships from existing schema
function populateRelationshipsFromSchema(schemaRelationships) {
    schemaRelationships.forEach((rel, index) => {
        addRelationship();
        const relationshipDiv = document.querySelector(`[data-relationship-id="${relationshipCount}"]`);
        
        if (relationshipDiv) {
            const typeSelect = relationshipDiv.querySelector('[data-field="type"]');
            const relatedTableInput = relationshipDiv.querySelector('[data-field="related_table"]');
            const foreignKeyInput = relationshipDiv.querySelector('[data-field="foreign_key"]');
            const referencedColumnInput = relationshipDiv.querySelector('[data-field="referenced_column"]');
            const descriptionInput = relationshipDiv.querySelector('[data-field="description"]');
            
            if (typeSelect) typeSelect.value = rel.type || '';
            if (relatedTableInput) relatedTableInput.value = rel.related_table || '';
            if (foreignKeyInput) foreignKeyInput.value = rel.foreign_key || '';
            if (referencedColumnInput) referencedColumnInput.value = rel.referenced_column || '';
            if (descriptionInput) descriptionInput.value = rel.description || '';
        }
    });
}

// Save schema functionality
async function saveSchema() {
    const businessId = document.getElementById('businessId').value;
    const tableName = document.getElementById('tableName').value;
    const schemaDescription = document.getElementById('schemaDescription').value;
    
    if (!businessId || !tableName || !schemaDescription) {
        showAlert('Please fill in all required fields', 'error');
        return;
    }
    
    // Collect column data
    const columns = [];
    const columnItems = document.querySelectorAll('.column-item');
    
    for (const columnItem of columnItems) {
        const name = columnItem.querySelector('[data-field="name"]').value;
        const type = columnItem.querySelector('[data-field="type"]').value;
        const constraints = columnItem.querySelector('[data-field="constraints"]').value;
        const description = columnItem.querySelector('[data-field="description"]').value;
        
        if (!name || !type) {
            showAlert('Please fill in all column names and types', 'error');
            return;
        }
        
        columns.push({
            name,
            type,
            constraint: constraints !== 'NONE' ? constraints : null,
            description: description || null,
            is_primary_key: constraints === 'PRIMARY KEY',
            is_nullable: constraints !== 'NOT NULL' && constraints !== 'PRIMARY KEY'
        });
    }
    
    // Collect relationship data
    const relationships = [];
    const relationshipItems = document.querySelectorAll('.relationship-item');
    
    for (const relationshipItem of relationshipItems) {
        const type = relationshipItem.querySelector('[data-field="type"]').value;
        const relatedTable = relationshipItem.querySelector('[data-field="related_table"]').value;
        const foreignKey = relationshipItem.querySelector('[data-field="foreign_key"]').value;
        const referencedColumn = relationshipItem.querySelector('[data-field="referenced_column"]').value;
        const description = relationshipItem.querySelector('[data-field="description"]').value;
        
        if (type && relatedTable && foreignKey && referencedColumn) {
            relationships.push({
                type,
                related_table: relatedTable,
                foreign_key: foreignKey,
                referenced_column: referencedColumn,
                description: description || null
            });
        }
    }
    
    const schemaData = {
        business_id: businessId,
        table_name: tableName,
        schema_description: schemaDescription,
        columns,
        relationships
    };
    
    try {
        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        const headers = {
            'Content-Type': 'application/json'
        };
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        const saveBtn = document.getElementById('saveBtn');
        const isUpdateMode = saveBtn.getAttribute('data-update-mode') === 'true';
        
        let response;
        if (isUpdateMode) {
            response = await fetch(`/admin/businesses/${businessId}/schemas/${tableName}`, {
                method: 'PUT',
                headers,
                body: JSON.stringify(schemaData)
            });
        } else {
            response = await fetch(`/admin/businesses/${businessId}/schemas`, {
                method: 'POST',
                headers,
                body: JSON.stringify(schemaData)
            });
        }
        
        if (response.ok) {
            const result = await response.json();
            showAlert(isUpdateMode ? 'Schema updated successfully!' : 'Schema saved successfully!', 'success');
            
            if (!isUpdateMode) {
                // Reset form after successful save
                resetForm();
            }
        } else {
            const errorData = await response.json();
            throw new Error(errorData.detail || `HTTP ${response.status}`);
        }
    } catch (error) {
        console.error('Error saving schema:', error);
        showAlert(`Error ${document.getElementById('saveBtn').getAttribute('data-update-mode') === 'true' ? 'updating' : 'saving'} schema: ${error.message}`, 'error');
    }
}

// Reset form
function resetForm() {
    document.getElementById('businessId').value = '';
    document.getElementById('tableName').innerHTML = '<option value="">Select a business first</option>';
    document.getElementById('schemaDescription').value = '';
    clearColumns();
    clearRelationships();
    
    const saveBtn = document.getElementById('saveBtn');
    const deleteBtn = document.getElementById('deleteBtn');
    saveBtn.innerHTML = '💾 Save Schema';
    saveBtn.removeAttribute('data-update-mode');
    if (deleteBtn) {
        deleteBtn.style.display = 'none';
    }
    
    showAlert('Form reset successfully', 'info');
}

// Go back to admin
function goBack() {
    window.location.href = 'admin.html';
}

// Show alert function
function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alertContainer');
    if (!alertContainer) return;
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.innerHTML = `
        <span>${message}</span>
        <button class="alert-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    alertContainer.appendChild(alertDiv);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentElement) {
            alertDiv.remove();
        }
    }, 5000);
}
