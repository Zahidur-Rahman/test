from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.models.chat_graph_state import ChatGraphState
import logging
import re
import time
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class AgentRouter:
    def __init__(self, agent_registry=None):
        self.llm_service = MistralLLMService()
        self.agent_registry = agent_registry
        self.classification_history = []  # Track classification decisions for learning
        
    async def classify_and_route(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Dynamically classify the query and route to appropriate agent.
        Returns the result from the selected agent.
        """
        try:
            # Convert state to ChatGraphState for consistency
            if isinstance(state, dict):
                context = ChatGraphState(**state)
            else:
                context = state
                
            # Hard override: if there is an active pause that requires confirmation,
            # always route to the customer agent to resume/execute
            if getattr(context, 'pause_reason', None) in {'confirm_update', 'confirm_delete'}:
                agent = self.agent_registry.get_agent('customer')
                result = await agent.ainvoke(state)
                if isinstance(result, dict):
                    result['routed_agent'] = 'customer'
                    result['routing_confidence'] = 'forced_pause_resume'
                return result

            # Perform dynamic classification
            agent_type = await self._classify_query_dynamically(context)
            logger.info(f"[AGENT_CLASSIFIED] {agent_type}")
            
            # Track the classification decision
            self._track_classification(context.message, agent_type)
            
            # Get the appropriate agent
            agent = self.agent_registry.get_agent(agent_type)
            if not agent:
                logger.error(f"[AgentRouter] Agent '{agent_type}' not found, falling back to general")
                agent = self.agent_registry.get_agent('general')
            
            # Execute with the selected agent
            result = await agent.ainvoke(state)
            
            # Add routing metadata to result
            if isinstance(result, dict):
                result['routed_agent'] = agent_type
                result['routing_confidence'] = 'high'
            
            return result
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in classification/routing: {e}")
            # Fallback to general agent
            fallback_agent = self.agent_registry.get_agent('general')
            return await fallback_agent.ainvoke(state)
    
    async def _classify_query_dynamically(self, context: ChatGraphState) -> str:
        """
        Use LLM to dynamically classify if query should go to customer agent or general agent.
        This is the primary classification method that understands intent and context.
        """
        try:
            # Build conversation context for better classification
            conversation_context = self._build_conversation_context(context)
            
            classification_prompt = f"""
You are an agent router for a business chatbot. Route queries to appropriate agents.

AGENTS:
1. 'customer' - Customer Data Agent: Handles customer data operations (add/edit/delete/view customer records)
2. 'general' - General Agent: Handles all other business data queries

CONTEXT:
{conversation_context}

QUERY: "{context.message}"

RULES:
- Customer data intent → 'customer'
- Other business data → 'general'
- "client" and "customer" are the same
- Consider conversation context

EXAMPLES:
- "Add customer" → customer
- "Update customer" → customer
- "Show customers" → customer
- "Sales numbers" → general
- "Orders" → general
- "Menu" → general

RESPONSE: "customer" or "general"
"""
            
            # Get LLM classification
            classification_response = await self.llm_service.chat([
                {"role": "system", "content": classification_prompt},
                {"role": "user", "content": context.message}
            ])
            
            # Parse and normalize response
            raw = classification_response.strip().lower()
            # Remove quotes, asterisks, punctuation and whitespace to get a clean token
            cleaned = re.sub(r"[^a-z]", "", raw)
            if cleaned in ["customer", "general"]:
                agent_type = cleaned
            else:
                # Fallback: detect keywords in raw response
                if "customer" in raw:
                    agent_type = "customer"
                elif "general" in raw:
                    agent_type = "general"
                else:
                    logger.warning(f"[AgentRouter] Invalid classification '{classification_response}', defaulting to general")
                    return 'general'
                
            return agent_type
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in dynamic classification: {e}")
            # Fallback to rule-based classification
            return self._fallback_classification(context.message)
    
    def _build_conversation_context(self, context: ChatGraphState) -> str:
        """Build conversation context for better classification."""
        if not context.conversation_history:
            return "No previous conversation context."
        
        # Get last 4 messages for context
        recent_messages = context.conversation_history[-4:]
        context_str = "RECENT CONVERSATION:\n"
        
        for msg in recent_messages:
            # Handle both ChatMessage objects and dictionaries
            if hasattr(msg, 'role') and hasattr(msg, 'content'):
                # ChatMessage object
                role = msg.role
                content = msg.content
            elif isinstance(msg, dict):
                # Dictionary
                role = msg.get('role', 'unknown')
                content = msg.get('content', 'unknown')
            else:
                # Fallback
                role = 'unknown'
                content = str(msg)
            context_str += f"{role.upper()}: {content}\n"
            
        return context_str
    
    def _fallback_classification(self, message: str) -> str:
        """
        Intelligent fallback classification using pattern analysis and intent detection.
        This is used only when LLM classification fails.
        """
        message_lower = message.lower()
        
        # Analyze intent patterns rather than just keywords
        customer_data_patterns = [
            # Direct customer data operations
            ('add', 'customer'), ('insert', 'customer'), ('create', 'customer'),
            ('update', 'customer'), ('modify', 'customer'), ('edit', 'customer'),
            ('delete', 'customer'), ('remove', 'customer'), ('drop', 'customer'),
            # Customer data queries
            ('show', 'customer'), ('find', 'customer'), ('search', 'customer'),
            ('list', 'customer'), ('get', 'customer'), ('view', 'customer'),
            # Customer data references
            ('customer', 'data'), ('customer', 'record'), ('customer', 'information'),
            ('customer', 'details'), ('customer', 'management'),
            # Client variations
            ('add', 'client'), ('insert', 'client'), ('create', 'client'),
            ('update', 'client'), ('modify', 'client'), ('edit', 'client'),
            ('delete', 'client'), ('remove', 'client'), ('drop', 'client'),
            ('show', 'client'), ('find', 'client'), ('search', 'client'),
            ('list', 'client'), ('get', 'client'), ('view', 'client'),
            # Last/Recent patterns for customers/clients
            ('last', 'customer'), ('last', 'client'), ('recent', 'customer'),
            ('recent', 'client'), ('latest', 'customer'), ('latest', 'client')
        ]
        
        # Check for customer data operation patterns
        for pattern in customer_data_patterns:
            if all(word in message_lower for word in pattern):
                return 'customer'
        
        # Additional customer update patterns
        customer_update_patterns = [
            'update last customer', 'update customer name', 'change customer name',
            'modify customer', 'edit customer', 'update customer to',
            'last customer name', 'customer name to'
        ]
        
        for pattern in customer_update_patterns:
            if pattern in message_lower:
                return 'customer'
        
        # Check for compound words and variations
        customer_compound_patterns = [
            'clientadded', 'customeradded', 'clientadd', 'customeradd',
            'lastclient', 'lastcustomer', 'recentclient', 'recentcustomer',
            'showclient', 'showcustomer', 'findclient', 'findcustomer'
        ]
        
        for pattern in customer_compound_patterns:
            if pattern in message_lower:
                return 'customer'
        
        # Check for business data patterns (orders, sales, inventory, etc.)
        business_data_patterns = [
            ('show', 'order'), ('find', 'order'), ('list', 'order'),
            ('show', 'sale'), ('find', 'sale'), ('list', 'sale'),
            ('show', 'inventory'), ('find', 'inventory'), ('list', 'inventory'),
            ('show', 'product'), ('find', 'product'), ('list', 'product'),
            ('show', 'employee'), ('find', 'employee'), ('list', 'employee')
        ]
        
        for pattern in business_data_patterns:
            if all(word in message_lower for word in pattern):
                return 'general'
        
        # Check for general data operations
        general_data_operations = [
            'show me', 'find', 'search', 'list', 'get all', 'how many',
            'what are', 'display', 'report', 'data', 'information', 'records'
        ]
        
        for operation in general_data_operations:
            if operation in message_lower:
                return 'general'
        
        # Check for customer service patterns (not customer data)
        customer_service_patterns = [
            'help', 'support', 'issue', 'problem', 'complaint', 'refund',
            'return', 'shipping', 'delivery', 'track', 'account', 'password',
            'login', 'register', 'signup', 'broken', 'wrong', 'missing'
        ]
        
        for pattern in customer_service_patterns:
            if pattern in message_lower:
                return 'general'
        
        # Default to general for ambiguous queries
        return 'general'

    def _track_classification(self, query: str, agent_type: str, confidence: str = 'high'):
        """
        Track classification decisions for potential learning and improvement.
        """
        classification_record = {
            'query': query,
            'agent_type': agent_type,
            'confidence': confidence,
            'timestamp': time.time()
        }
        self.classification_history.append(classification_record)
        
        # Keep only last 1000 classifications to prevent memory bloat
        if len(self.classification_history) > 1000:
            self.classification_history = self.classification_history[-1000:]
    
    def get_classification_stats(self):
        """
        Get statistics about classification decisions for monitoring and improvement.
        """
        if not self.classification_history:
            return {'total': 0, 'customer': 0, 'general': 0}
        
        total = len(self.classification_history)
        customer_count = sum(1 for record in self.classification_history if record['agent_type'] == 'customer')
        general_count = sum(1 for record in self.classification_history if record['agent_type'] == 'general')
        
        return {
            'total': total,
            'customer': customer_count,
            'general': general_count,
            'customer_percentage': (customer_count / total) * 100 if total > 0 else 0,
            'general_percentage': (general_count / total) * 100 if total > 0 else 0
        }

 