from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.mcp.mcp_client import MCPClient
import logging
import re

logger = logging.getLogger(__name__)
# Temporarily enable INFO level to track business ID issues
logger.setLevel(logging.INFO)

class CustomerSQLGenerator:
    """
    Customer-specific SQL generator that handles:
    - Business filtering (zid = business_id)
    - Auto-insert of zid values
    - Auto-increment of xcus values
    """
    
    def __init__(self, mcp_client: MCPClient = None):
        self.mcp_client = mcp_client or MCPClient(script_path="backend/app/mcp/server_enhanced.py")
        self.llm_service = MistralLLMService()
    
    async def generate_next_xcus(self, business_id: int) -> str:
        """
        Generate the next auto-incremented xcus value for the given business.
        """
        try:
            # Ensure business_id is the correct value, not incremented
            actual_business_id = int(business_id)
            logger.info(f"Generating next xcus for business_id: {actual_business_id}")
            
            # Use a simpler and more reliable SQL query to get the next xcus value
            sql_query = f"""
            SELECT 
              'CUS-' || lpad(
                COALESCE(
                  (
                    SELECT MAX(CAST(SUBSTRING(xcus, 5) AS INTEGER)) + 1
                    FROM cacus 
                    WHERE xcus LIKE 'CUS-%' AND zid = {actual_business_id}
                  ),
                  1
                )::text, 
                6, 
                '0'
              )
            """
            
            result = await self.mcp_client.execute_query(sql_query, str(business_id))
            
            # Parse the result to extract the generated xcus
            if isinstance(result, dict) and 'content' in result:
                for item in result['content']:
                    if 'text' in item:
                        try:
                            import json
                            parsed = json.loads(item['text'])
                            if 'results' in parsed and parsed['results']:
                                # Try different possible column names
                                result_row = parsed['results'][0]
                                for key in result_row:
                                    if key.startswith('?column') or key == 'xcus' or 'CUS-' in str(result_row[key]):
                                        value = str(result_row[key])
                                        if 'CUS-' in value:
                                            return value
                                # If no CUS- found, return the first value
                                return str(list(result_row.values())[0])
                        except Exception as e:
                            logger.warning(f"JSON parsing failed: {e}")
                            # If JSON parsing fails, try to extract from text directly
                            text = item['text']
                            # Look for CUS- pattern in the result
                            match = re.search(r'CUS-\d+', text)
                            if match:
                                return match.group(0)
            
            # Fallback
            logger.warning(f"Could not parse xcus generation result: {result}")
            return 'CUS-000001'
            
        except Exception as e:
            logger.error(f"Error generating next xcus for business {business_id}: {e}")
            return 'CUS-000001'
    
    def add_business_filter(self, sql: str, business_id: int) -> str:
        """
        Add business filtering (zid = business_id) to SELECT/UPDATE/DELETE queries.
        """
        sql_upper = sql.upper().strip()
        
        # Handle SELECT queries
        if sql_upper.startswith('SELECT'):
            if 'WHERE' in sql_upper:
                # Add zid filter to existing WHERE clause
                sql = re.sub(r'WHERE\s+', f'WHERE zid = {business_id} AND ', sql, flags=re.IGNORECASE)
            else:
                # Add WHERE clause with zid filter
                sql = re.sub(r'FROM\s+(\w+)', f'FROM \\1 WHERE zid = {business_id}', sql, flags=re.IGNORECASE)
            
            # Ensure ORDER BY xcus is used for customer queries
            sql = self.ensure_order_by_xcus(sql)
        
        # Handle UPDATE queries
        elif sql_upper.startswith('UPDATE'):
            if 'WHERE' in sql_upper:
                # Add zid filter to existing WHERE clause
                sql = re.sub(r'WHERE\s+', f'WHERE zid = {business_id} AND ', sql, flags=re.IGNORECASE)
            else:
                # Add WHERE clause with zid filter
                sql = re.sub(r'SET\s+(.+?)(?:\s*$)', f'SET \\1 WHERE zid = {business_id}', sql, flags=re.IGNORECASE)
        
        # Handle DELETE queries
        elif sql_upper.startswith('DELETE'):
            if 'WHERE' in sql_upper:
                # Add zid filter to existing WHERE clause
                sql = re.sub(r'WHERE\s+', f'WHERE zid = {business_id} AND ', sql, flags=re.IGNORECASE)
            else:
                # Add WHERE clause with zid filter
                sql = re.sub(r'FROM\s+(\w+)', f'FROM \\1 WHERE zid = {business_id}', sql, flags=re.IGNORECASE)
        
        return sql
    
    def ensure_order_by_xcus(self, sql: str) -> str:
        """
        Ensure that SELECT queries use ORDER BY xcus for customer data.
        """
        sql_upper = sql.upper().strip()
        
        if not sql_upper.startswith('SELECT'):
            return sql
        
        # Check if ORDER BY already exists
        if 'ORDER BY' in sql_upper:
            # If ORDER BY exists but doesn't use xcus, replace it
            if 'ORDER BY XCUS' not in sql_upper:
                # Replace existing ORDER BY with xcus
                sql = re.sub(r'ORDER BY\s+[^;]*', 'ORDER BY xcus', sql, flags=re.IGNORECASE)
        else:
            # Add ORDER BY xcus if it doesn't exist
            sql = sql.rstrip(';').strip() + ' ORDER BY xcus'
        
        return sql
    
    def add_xstatuscus_to_insert(self, sql: str) -> str:
        """
        Add xstatuscus = 'Open' to INSERT queries for cacus table.
        """
        sql_upper = sql.upper().strip()
        
        if not sql_upper.startswith('INSERT'):
            return sql
        
        # Check if this is an INSERT into cacus table
        if 'CACUS' not in sql_upper:
            return sql
        
        # Handle INSERT INTO table (columns) VALUES (values)
        if 'VALUES' in sql_upper:
            # Extract table name and columns
            match = re.match(r'INSERT\s+INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)', sql, re.IGNORECASE)
            if match:
                table_name, columns, values = match.groups()
                
                # Check if xstatuscus is already in columns
                if 'xstatuscus' in columns.lower():
                    # Replace the xstatuscus value with 'Open'
                    value_list = [v.strip() for v in values.split(',')]
                    column_list = [c.strip() for c in columns.split(',')]
                    
                    # Find xstatuscus position
                    xstatuscus_index = None
                    for i, col in enumerate(column_list):
                        if col.lower() == 'xstatuscus':
                            xstatuscus_index = i
                            break
                    
                    if xstatuscus_index is not None and xstatuscus_index < len(value_list):
                        # Replace the xstatuscus value
                        value_list[xstatuscus_index] = "'Open'"
                        values = ', '.join(value_list)
                else:
                    # Add xstatuscus to columns if not present
                    columns = f"xstatuscus, {columns}"
                    values = f"'Open', {values}"
                
                result = f"INSERT INTO {table_name} ({columns}) VALUES ({values})"
                return result
        
        # Handle INSERT INTO table VALUES (values)
        else:
            match = re.match(r'INSERT\s+INTO\s+(\w+)\s*VALUES\s*\(([^)]+)\)', sql, re.IGNORECASE)
            if match:
                table_name, values = match.groups()
                # Add xstatuscus as first value
                values = f"'Open', {values}"
                result = f"INSERT INTO {table_name} VALUES ({values})"
                return result
        
        return sql
    
    def add_zid_to_insert(self, sql: str, business_id: int) -> str:
        """
        Add zid = business_id to INSERT queries.
        CRITICAL: Use the exact business_id provided, do not increment it.
        """
        sql_upper = sql.upper().strip()
        
        # Ensure we use the exact business_id, not an incremented value
        actual_business_id = int(business_id)
        logger.info(f"Adding zid to INSERT with business_id: {actual_business_id}")
        
        if sql_upper.startswith('INSERT'):
            # Handle INSERT INTO table (columns) VALUES (values)
            if 'VALUES' in sql_upper:
                # Extract table name and columns
                match = re.match(r'INSERT\s+INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)', sql, re.IGNORECASE)
                if match:
                    table_name, columns, values = match.groups()
                    
                    # Check if zid is already in columns
                    if 'zid' in columns.lower():
                        # Replace the zid value with the correct business_id
                        # Split values and find zid position
                        value_list = [v.strip() for v in values.split(',')]
                        column_list = [c.strip() for c in columns.split(',')]
                        
                        # Find zid position
                        zid_index = None
                        for i, col in enumerate(column_list):
                            if col.lower() == 'zid':
                                zid_index = i
                                break
                        
                        if zid_index is not None and zid_index < len(value_list):
                            # CRITICAL FIX: Use actual_business_id, not incremented value
                            value_list[zid_index] = str(actual_business_id)
                            values = ', '.join(value_list)
                            logger.info(f"Replaced zid value with: {actual_business_id}")
                    else:
                        # Add zid to columns if not present
                        columns = f"zid, {columns}"
                        values = f"{actual_business_id}, {values}"
                        logger.info(f"Added zid column with value: {actual_business_id}")
                    
                    result = f"INSERT INTO {table_name} ({columns}) VALUES ({values})"
                    logger.info(f"Final INSERT SQL: {result}")
                    return result
            
            # Handle INSERT INTO table VALUES (values)
            else:
                match = re.match(r'INSERT\s+INTO\s+(\w+)\s*VALUES\s*\(([^)]+)\)', sql, re.IGNORECASE)
                if match:
                    table_name, values = match.groups()
                    # Add zid as first value
                    values = f"{actual_business_id}, {values}"
                    result = f"INSERT INTO {table_name} VALUES ({values})"
                    logger.info(f"Final INSERT SQL: {result}")
                    return result
        
        return sql
    
    async def process_customer_sql(self, sql: str, business_id: int, operation_type: str = None) -> str:
        """
        Process customer SQL based on operation type:
        - SELECT/UPDATE/DELETE: Add business filtering
        - INSERT: Add zid and auto-generate xcus if needed
        """
        try:
            # Convert business_id to integer
            business_id_int = int(business_id)
            
            sql_upper = sql.upper().strip()
            
            # Handle different operation types
            if sql_upper.startswith('SELECT') or sql_upper.startswith('UPDATE') or sql_upper.startswith('DELETE'):
                # Add business filtering
                processed_sql = self.add_business_filter(sql, business_id_int)
                return processed_sql
            
            elif sql_upper.startswith('INSERT'):
                # Add zid to INSERT
                processed_sql = self.add_zid_to_insert(sql, business_id_int)
                
                # Add xstatuscus to INSERT for cacus table
                processed_sql = self.add_xstatuscus_to_insert(processed_sql)
                
                # Check if xcus needs to be auto-generated
                if 'xcus' in processed_sql.lower():
                    # Generate next xcus value
                    next_xcus = await self.generate_next_xcus(business_id_int)
                    
                    # Find the position of xcus in the VALUES clause and replace it
                    # This is more reliable than regex for complex SQL
                    try:
                        # Parse the SQL to find xcus position
                        match = re.match(r'INSERT\s+INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)', processed_sql, re.IGNORECASE)
                        if match:
                            table_name, columns, values = match.groups()
                            column_list = [c.strip() for c in columns.split(',')]
                            value_list = [v.strip() for v in values.split(',')]
                            
                            # Find xcus position
                            xcus_index = None
                            for i, col in enumerate(column_list):
                                if col.lower() == 'xcus':
                                    xcus_index = i
                                    break
                            
                            if xcus_index is not None and xcus_index < len(value_list):
                                # Replace the xcus value
                                value_list[xcus_index] = f"'{next_xcus}'"
                                new_values = ', '.join(value_list)
                                processed_sql = f"INSERT INTO {table_name} ({columns}) VALUES ({new_values})"
                            else:
                                # logger.warning(f"Could not find xcus position in columns: {column_list}")  # Suppressed
                                pass
                        else:
                            # logger.warning(f"Could not parse INSERT statement: {processed_sql}")  # Suppressed
                            pass
                    except Exception as e:
                        logger.error(f"Error replacing xcus value: {e}")
                        # Fallback to regex
                        processed_sql = re.sub(
                            r"'CUS-[^']*'", 
                            f"'{next_xcus}'", 
                            processed_sql, 
                            flags=re.IGNORECASE
                        )
                    
                    # logger.info(f"After xcus replacement: {processed_sql}")  # Suppressed
                else:
                    # logger.info("No xcus found in INSERT statement")  # Suppressed
                    pass
                
                return processed_sql
            
            else:
                # Unknown operation type, return as-is
                return sql
                
        except Exception as e:
            logger.error(f"Error processing customer SQL: {e}")
            return sql
    
    def validate_customer_sql(self, sql: str) -> bool:
        """
        Validate that the SQL is safe for customer operations.
        """
        sql_upper = sql.upper().strip()
        
        # Check for dangerous operations
        dangerous_operations = ['DROP', 'TRUNCATE', 'ALTER', 'CREATE', 'GRANT', 'REVOKE']
        for op in dangerous_operations:
            if op in sql_upper:
                logger.warning(f"Dangerous operation detected: {op}")
                return False
        
        # Check for valid customer operations
        valid_operations = ['SELECT', 'INSERT', 'UPDATE', 'DELETE']
        has_valid_operation = any(op in sql_upper for op in valid_operations)
        
        if not has_valid_operation:
            logger.warning("No valid customer operation detected")
            return False
        
        return True 