from typing import List
from backend.app.services.mistral_llm_service import MistralLLMService
import logging
import traceback

async def is_customer_database_related_query_dynamic(message: str, business_id: str, vector_search_service, conversation_history: List = None) -> bool:
    """
    Customer-specific LLM-based dynamic classification.
    Uses the LLM to intelligently determine if a query should generate SQL for customer data operations.
    """
    try:
        # 1. Get schema context for the query
        schema_results = await vector_search_service.search_schemas(business_id, message, top_k=3)
        
        # 2. Create schema context for the LLM
        schema_context = ""
        if schema_results and len(schema_results) > 0:
            schema_context = "Available customer database schemas:\n"
            for schema in schema_results:
                schema_context += f"- {schema.get('table_name', 'Unknown')}: {schema.get('schema_description', 'No description')}\n"
        else:
            schema_context = "No relevant customer database schemas found."
        
        # 3. Use LLM to classify the query with conversation context
        conversation_context = ""
        if conversation_history and len(conversation_history) > 0:
            # Get last 4 messages for context (2 exchanges)
            recent_messages = conversation_history[-4:]
            conversation_context = "RECENT CONVERSATION CONTEXT:\n"
            for msg in recent_messages:
                role = msg.get('role', msg.role if hasattr(msg, 'role') else 'unknown')
                content = msg.get('content', msg.content if hasattr(msg, 'content') else 'unknown')
                conversation_context += f"{role.upper()}: {content}\n"
        else:
            conversation_context = "No recent conversation context available."
        
        classification_prompt = f"""
You are an intelligent, context-aware customer data query classifier for a business chatbot system.

AVAILABLE CUSTOMER DATABASE SCHEMAS:
{schema_context}

{conversation_context}

CURRENT USER QUERY: "{message}"

TASK: Decide if this query should generate a SQL database query for customer data operations or be treated as general conversation.

CUSTOMER DATA CLASSIFICATION RULES:
- If the user is asking for specific customer data, records, or customer information that could be retrieved from the database, classify as CUSTOMER_DATABASE_QUERY.
- If the user is asking for general help, explanations, opinions, or casual conversation unrelated to customers, classify as GENERAL_CONVERSATION.
- If the user mentions specific customer names, customer IDs, or customer entities that could be looked up, classify as CUSTOMER_DATABASE_QUERY.
- If the user is asking "how to" questions about customer management or seeking customer-related advice, classify as CUSTOMER_DATABASE_QUERY.
- If the user asks "about" a customer and relevant customer database tables exist, classify as CUSTOMER_DATABASE_QUERY.
- If the user asks for customer information that could be found in business data, classify as CUSTOMER_DATABASE_QUERY.
- If the query is ambiguous, ask the user for clarification rather than guessing.
- Use conversation context ONLY if the current query is ambiguous or uses pronouns.
- Focus on customer data operations like adding, updating, deleting, viewing, or searching customer records.

CUSTOMER DATA OPERATIONS EXAMPLES:
- Customer management: add customer, update customer, delete customer, view customer
- Customer search: find customer, search customer, customer lookup, customer details
- Customer information: customer phone, customer address, customer email, customer name
- Customer lists: all customers, customer list, customer directory, customer database

EXAMPLES WITH CONTEXT:
- Previous: "show me customers" → Current: "and their contact info" → CUSTOMER_DATABASE_QUERY
- Previous: "find John Smith" → Current: "what about his phone number?" → CUSTOMER_DATABASE_QUERY
- Previous: "add a new customer" → Current: "with name John Doe" → CUSTOMER_DATABASE_QUERY
- Previous: "hello" → Current: "how are you?" → GENERAL_CONVERSATION
- Previous: "show me customers" → Current: "thanks, bye" → GENERAL_CONVERSATION
- Previous: "customer database" → Current: "what about it?" → CUSTOMER_DATABASE_QUERY

STANDALONE CUSTOMER EXAMPLES:
- "give me all information about customer Zahid" → CUSTOMER_DATABASE_QUERY
- "About customer John Smith" → CUSTOMER_DATABASE_QUERY
- "show me all customers" → CUSTOMER_DATABASE_QUERY
- "add a new customer" → CUSTOMER_DATABASE_QUERY
- "update customer phone number" → CUSTOMER_DATABASE_QUERY
- "delete customer record" → CUSTOMER_DATABASE_QUERY
- "find customer by name" → CUSTOMER_DATABASE_QUERY
- "customer contact information" → CUSTOMER_DATABASE_QUERY
- "how do I reset my password?" → GENERAL_CONVERSATION
- "what's the weather like?" → GENERAL_CONVERSATION
- "can you help me?" → GENERAL_CONVERSATION
- "hello" → GENERAL_CONVERSATION
- "customer management system" → CUSTOMER_DATABASE_QUERY
- "customer database operations" → CUSTOMER_DATABASE_QUERY

RESPONSE FORMAT: Respond with ONLY "CUSTOMER_DATABASE_QUERY" or "GENERAL_CONVERSATION" (no other text). If unsure, respond: "CLARIFICATION_NEEDED".

CLASSIFICATION:
"""
        # Use the LLM to classify
        llm_service = MistralLLMService()
        classification_response = await llm_service.chat([
            {"role": "system", "content": classification_prompt},
            {"role": "user", "content": message}
        ])
        # Parse the response
        classification = classification_response.strip().upper()
        if "CLARIFICATION_NEEDED" in classification:
            return False
        is_customer_database_query = "CUSTOMER_DATABASE_QUERY" in classification
        
        return is_customer_database_query
        
    except Exception as e:
        logging.error(f"[CustomerDynamicClassifier] Error in LLM-based classification: {e}\n{traceback.format_exc()}")
        # Conservative fallback - if LLM fails, check if we have customer schema matches
        try:
            schema_results = await vector_search_service.search_schemas(business_id, message, top_k=3)
            fallback_result = schema_results and len(schema_results) > 0
            return fallback_result
        except Exception as fallback_error:
            logging.error(f"[CustomerDynamicClassifier] Fallback classification also failed: {fallback_error}\n{traceback.format_exc()}")
            return False 