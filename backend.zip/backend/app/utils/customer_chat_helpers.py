from backend.app.services.mistral_llm_service import MistralLLMService

# Initialize LLM service for summarization
llm_service = MistralLLMService()

async def summarize_customer_data_with_llm(customer_data, user_query=""):
    """
    Use LLM to create a natural language summary of customer data.
    """
    try:
        # Filter out empty fields
        non_empty_data = {}
        for field_name, value in customer_data.items():
            if not is_empty_value(value):
                friendly_name = get_user_friendly_field_name(field_name)
                non_empty_data[friendly_name] = value
        
        if not non_empty_data:
            return "Customer record found but all fields are empty."
        
        # Create a structured summary for the LLM
        data_summary = "\n".join([f"• {name}: {value}" for name, value in non_empty_data.items()])
        
        prompt = f"""
You are a helpful customer service assistant. Based on the following customer data, provide a natural, conversational summary.

Customer Data:
{data_summary}

User's original query: "{user_query}"

Please provide a friendly, concise summary that:
1. Mentions the customer's name and ID if available
2. Highlights the most important information
3. Uses natural language (not technical field names)
4. Is conversational and helpful
5. Addresses what the user was likely looking for

Keep it brief but informative. Don't list every field - focus on the most relevant information.
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": "You are a helpful customer service assistant that provides clear, friendly summaries of customer information."},
            {"role": "user", "content": prompt}
        ])
        
        return response.strip()
        
    except Exception as e:
        # Fallback to regular formatting if LLM fails
        return format_single_customer_record(customer_data)

async def generate_insert_confirmation_message(sql, business_id):
    """
    Generate a user-friendly confirmation message for INSERT operations.
    Extracts the inserted data from the SQL and presents it in a readable format.
    """
    try:
        # Parse the INSERT SQL to extract the inserted data
        import re
        
        # Handle INSERT INTO table (columns) VALUES (values)
        match = re.match(r'INSERT\s+INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)', sql, re.IGNORECASE)
        if match:
            table_name, columns, values = match.groups()
            column_list = [col.strip() for col in columns.split(',')]
            value_list = [val.strip().strip("'\"") for val in values.split(',')]
            
            # Create a mapping of column names to values
            inserted_data = {}
            for i, col in enumerate(column_list):
                if i < len(value_list):
                    inserted_data[col] = value_list[i]
            
            return format_insert_confirmation(table_name, inserted_data)
        
        # Handle INSERT INTO table VALUES (values)
        match = re.match(r'INSERT\s+INTO\s+(\w+)\s*VALUES\s*\(([^)]+)\)', sql, re.IGNORECASE)
        if match:
            table_name, values = match.groups()
            value_list = [val.strip().strip("'\"") for val in values.split(',')]
            
            # For VALUES without column names, we'll use generic field names
            # This is less ideal but still provides some information
            return format_generic_insert_confirmation(table_name, value_list)
        
        # Fallback for complex INSERT statements
        return "Customer record has been successfully created!"
        
    except Exception as e:
        # Fallback if parsing fails
        return "Customer record has been successfully created!"

async def generate_update_confirmation_message(sql, business_id):
    """
    Generate a user-friendly confirmation message for UPDATE operations.
    Extracts the updated data from the SQL and presents it in a readable format.
    """
    try:
        # Parse the UPDATE SQL to extract the updated data
        import re
        
        # Handle UPDATE table SET column1 = value1, column2 = value2 WHERE condition
        match = re.match(r'UPDATE\s+(\w+)\s+SET\s+(.+?)\s+WHERE\s+(.+)', sql, re.IGNORECASE | re.DOTALL)
        if match:
            table_name, set_clause, where_clause = match.groups()
            
            # Parse the SET clause to extract updated fields
            updated_fields = {}
            set_parts = [part.strip() for part in set_clause.split(',')]
            
            for part in set_parts:
                # Handle field = value pattern
                field_match = re.match(r'(\w+)\s*=\s*(.+)', part, re.IGNORECASE)
                if field_match:
                    field_name = field_match.group(1).strip()
                    field_value = field_match.group(2).strip().strip("'\"")
                    updated_fields[field_name] = field_value
            
            return format_update_confirmation(table_name, updated_fields, where_clause)
        
        # Fallback for complex UPDATE statements
        return "Customer information has been successfully updated!"
        
    except Exception as e:
        # Fallback if parsing fails
        return "Customer information has been successfully updated!"

async def generate_delete_confirmation_message(sql, business_id):
    """
    Generate a user-friendly confirmation message for DELETE operations.
    Extracts the deleted customer information from the SQL and presents it in a readable format.
    """
    try:
        # Parse the DELETE SQL to extract the customer information
        import re
        
        # Handle DELETE FROM table WHERE condition
        match = re.match(r'DELETE\s+FROM\s+(\w+)\s+WHERE\s+(.+)', sql, re.IGNORECASE | re.DOTALL)
        if match:
            table_name, where_clause = match.groups()
            
            return format_delete_confirmation(table_name, where_clause)
        
        # Fallback for complex DELETE statements
        return "Customer record has been successfully deleted!"
        
    except Exception as e:
        # Fallback if parsing fails
        return "Customer record has been successfully deleted!"

def format_insert_confirmation(table_name, inserted_data):
    """
    Format INSERT confirmation with specific data details.
    """
    if table_name.upper() != 'CACUS':
        return f"Record has been successfully created in {table_name} table."
    
    # Extract key customer information
    customer_id = inserted_data.get('xcus', 'Unknown')
    first_name = inserted_data.get('xfirst', '')
    last_name = inserted_data.get('xlast', '')
    organization = inserted_data.get('xorg', '')
    email = inserted_data.get('xemail', '')
    phone = inserted_data.get('xphone', '')
    city = inserted_data.get('xcity', '')
    status = inserted_data.get('xstatuscus', 'Open')
    
    # Build the confirmation message
    confirmation_parts = []
    
    # Customer identification
    if first_name or last_name:
        name_parts = []
        if first_name:
            name_parts.append(first_name)
        if last_name:
            name_parts.append(last_name)
        name = ' '.join(name_parts)
        confirmation_parts.append(f"**{name}** (ID: {customer_id})")
    else:
        confirmation_parts.append(f"**Customer {customer_id}**")
    
    # Organization
    if organization:
        confirmation_parts.append(f"Organization: **{organization}**")
    
    # Contact information
    contact_info = []
    if email:
        contact_info.append(f"Email: {email}")
    if phone:
        contact_info.append(f"Phone: {phone}")
    if contact_info:
        confirmation_parts.append(f"Contact: {', '.join(contact_info)}")
    
    # Location
    if city:
        confirmation_parts.append(f"Location: {city}")
    
    # Status
    if status:
        confirmation_parts.append(f"Status: {status}")
    
    # Build the final message
    message = f"✅ **Customer Successfully Created!**\n\n"
    
    # Customer identification
    if first_name or last_name:
        name_parts = []
        if first_name:
            name_parts.append(first_name)
        if last_name:
            name_parts.append(last_name)
        name = ' '.join(name_parts)
        message += f"**{name}** (ID: {customer_id})\n"
    else:
        message += f"**Customer {customer_id}**\n"
    
    # Additional details in a structured format
    details = []
    if organization:
        details.append(f"Organization: {organization}")
    if email:
        details.append(f"Email: {email}")
    if phone:
        details.append(f"Phone: {phone}")
    if city:
        details.append(f"Location: {city}")
    if status:
        details.append(f"Status: {status}")
    
    if details:
        message += "\n" + "\n".join(details) + "\n"
    
    message += "\nThe customer has been added to your database and is ready for use."
    
    return message

def format_generic_insert_confirmation(table_name, values):
    """
    Format INSERT confirmation for VALUES without column names.
    """
    if table_name.upper() != 'CACUS':
        return f"Record has been successfully created in {table_name} table."
    
    # Try to identify key values by position (assuming standard order)
    if len(values) >= 3:
        customer_id = values[2] if len(values) > 2 else 'Unknown'  # xcus is typically 3rd
        first_name = values[4] if len(values) > 4 else ''  # xfirst is typically 5th
        last_name = values[5] if len(values) > 5 else ''   # xlast is typically 6th
        
        name_parts = []
        if first_name and first_name not in ['', 'null', 'none']:
            name_parts.append(first_name)
        if last_name and last_name not in ['', 'null', 'none']:
            name_parts.append(last_name)
        
        if name_parts:
            name = ' '.join(name_parts)
            return f"✅ **Customer Successfully Created!**\n\n**{name}** (ID: {customer_id})\n\nThe customer has been added to your database and is ready for use."
        else:
            return f"✅ **Customer Successfully Created!**\n\n**Customer {customer_id}**\n\nThe customer has been added to your database and is ready for use."
    
    return "✅ **Customer Successfully Created!**\n\nThe customer has been added to your database and is ready for use."

def format_update_confirmation(table_name, updated_fields, where_clause):
    """
    Format UPDATE confirmation with specific data details.
    """
    if table_name.upper() != 'CACUS':
        return f"Record has been successfully updated in {table_name} table."
    
    # Extract customer identifier from WHERE clause
    customer_id = extract_customer_id_from_where(where_clause)
    
    # Map field names to user-friendly names
    friendly_updates = []
    for field_name, value in updated_fields.items():
        friendly_name = get_user_friendly_field_name(field_name)
        if not is_empty_value(value):
            friendly_updates.append(f"{friendly_name}: {value}")
    
    if not friendly_updates:
        return "Customer information has been successfully updated!"
    
    # Build the confirmation message
    message = f"✅ **Customer Information Updated!**\n\n"
    
    if customer_id:
        message += f"**Customer {customer_id}** has been updated with:\n\n"
    else:
        message += "The following information has been updated:\n\n"
    
    # List the updated fields
    for update in friendly_updates:
        message += f"• {update}\n"
    
    message += "\nThe changes have been saved to your database."
    
    return message

def format_delete_confirmation(table_name, where_clause):
    """
    Format DELETE confirmation with specific customer details.
    """
    if table_name.upper() != 'CACUS':
        return f"Record has been successfully deleted from {table_name} table."
    
    # Extract customer identifier from WHERE clause
    customer_id = extract_customer_id_from_where(where_clause)
    
    # Build the confirmation message
    message = f"🗑️ **Customer Deleted Successfully!**\n\n"
    
    if customer_id:
        message += f"**Customer {customer_id}** has been permanently removed from your database."
    else:
        message += "The customer record has been permanently removed from your database."
    
    message += "\n\nAll associated data has been deleted and cannot be recovered."
    
    return message

def extract_customer_id_from_where(where_clause):
    """
    Extract customer ID from WHERE clause.
    """
    try:
        import re
        
        # Look for xcus = 'CUS-XXXXXX' pattern
        match = re.search(r"xcus\s*=\s*['\"]([^'\"]+)['\"]", where_clause, re.IGNORECASE)
        if match:
            return match.group(1)
        
        # Look for other common patterns
        match = re.search(r"id\s*=\s*['\"]([^'\"]+)['\"]", where_clause, re.IGNORECASE)
        if match:
            return match.group(1)
        
        return None
        
    except Exception:
        return None

def build_customer_system_prompt(context, conversation_history, schema_context):
    schema_text = ""
    if schema_context:
        for schema in schema_context:
            schema_text += f"\nTable: {schema.get('table_name', 'Unknown')}\n"
            schema_text += f"Description: {schema.get('schema_description', 'No description')}\n"
            schema_text += "Columns:\n"
            for col in schema.get('columns', []):
                col_name = col.get('name', 'Unknown')
                col_type = col.get('type', 'Unknown')
                col_desc = col.get('description', 'No description')
                schema_text += f"  - {col_name}: {col_type} ({col_desc})\n"
            
            # Highlight primary keys and foreign keys
            primary_keys = []
            foreign_keys = []
            if schema.get('relationships'):
                schema_text += "Relationships:\n"
                for rel in schema.get('relationships', []):
                    rel_type = rel.get('relationship_type', 'unknown')
                    if rel_type == 'primary_key':
                        primary_keys.append(rel.get('from_column', 'Unknown'))
                        schema_text += f"  - PRIMARY KEY: {rel.get('from_column', 'Unknown')}\n"
                    elif rel_type == 'foreign_key':
                        foreign_keys.append(rel.get('from_column', 'Unknown'))
                        schema_text += f"  - FOREIGN KEY: {rel.get('from_column', 'Unknown')} -> {rel.get('referenced_table', 'Unknown')}.{rel.get('referenced_column', 'Unknown')}\n"
                    else:
                        schema_text += f"  - {rel.get('from_table', 'Unknown')}.{rel.get('from_column', 'Unknown')} -> {rel.get('to_table', 'Unknown')}.{rel.get('to_column', 'Unknown')}\n"
            
            if primary_keys:
                schema_text += f"PRIMARY KEYS: {', '.join(primary_keys)}\n"
            if foreign_keys:
                schema_text += f"FOREIGN KEYS: {', '.join(foreign_keys)}\n"
            schema_text += "\n"
    else:
        schema_text = "No relevant schema context found."

    system_prompt = (
        "You are a customer data management assistant. Help manage customer records and information.\n\n"
        f"CUSTOMER DATA:\n{schema_text}\n\n"
        "CONVERSATION:\n"
    )
    for msg in conversation_history:
        role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
        content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
        system_prompt += f"{role.upper()}: {content}\n"
    system_prompt += (
        f"\nREQUEST: {context.message}\n\n"
        "CUSTOMER OPERATIONS:\n"
        "- Add/Update/Delete customer records\n"
        "- View/Search/List customers\n\n"
        "GUIDELINES:\n"
        "- Be friendly and concise\n"
        "- Confirm before changes\n"
        "- Ask for clarification if needed\n"
        "- Use schema and conversation context\n"
        "- Maintain data privacy\n"
        "- Provide helpful guidance\n"
    )
    return system_prompt

def build_customer_sql_prompt(context, conversation_history, schema_context):
    schema_text = ""
    if schema_context:
        for schema in schema_context:
            schema_text += f"\nTable: {schema.get('table_name', 'Unknown')}\n"
            schema_text += f"Description: {schema.get('schema_description', 'No description')}\n"
            schema_text += "Columns:\n"
            for col in schema.get('columns', []):
                col_name = col.get('name', 'Unknown')
                col_type = col.get('type', 'Unknown')
                col_desc = col.get('description', 'No description')
                schema_text += f"  - {col_name}: {col_type} ({col_desc})\n"
            
            # Highlight primary keys and foreign keys
            primary_keys = []
            foreign_keys = []
            if schema.get('relationships'):
                schema_text += "Relationships:\n"
                for rel in schema.get('relationships', []):
                    rel_type = rel.get('relationship_type', 'unknown')
                    if rel_type == 'primary_key':
                        primary_keys.append(rel.get('from_column', 'Unknown'))
                        schema_text += f"  - PRIMARY KEY: {rel.get('from_column', 'Unknown')}\n"
                    elif rel_type == 'foreign_key':
                        foreign_keys.append(rel.get('from_column', 'Unknown'))
                        schema_text += f"  - FOREIGN KEY: {rel.get('from_column', 'Unknown')} -> {rel.get('referenced_table', 'Unknown')}.{rel.get('referenced_column', 'Unknown')}\n"
                    else:
                        schema_text += f"  - {rel.get('from_table', 'Unknown')}.{rel.get('from_column', 'Unknown')} -> {rel.get('to_table', 'Unknown')}.{rel.get('to_column', 'Unknown')}\n"
            
            if primary_keys:
                schema_text += f"PRIMARY KEYS: {', '.join(primary_keys)}\n"
            if foreign_keys:
                schema_text += f"FOREIGN KEYS: {', '.join(foreign_keys)}\n"
            schema_text += "\n"
    else:
        schema_text = "No relevant schema context found."

    sql_prompt = (
        "You are an expert SQL assistant for customer data management in PostgreSQL. "
        "Convert customer requests to safe SQL queries.\n\n"
        f"CUSTOMER SCHEMAS:\n{schema_text}\n"
        "CONVERSATION:\n"
    )
    for msg in conversation_history:
        role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
        content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
        sql_prompt += f"{role.upper()}: {content}\n"
    sql_prompt += (
        f"\nREQUEST: {context.message}\n"
        "CUSTOMER OPERATIONS:\n"
        "- SELECT: View/search/list customers\n"
        "- INSERT: Add new customers\n"
        "- UPDATE: Modify customer info\n"
        "- DELETE: Remove customers (with confirmation)\n\n"
        "RULES:\n"
        "- NO dummy data (use '' for empty values)\n"
        "- Focus on cacus table and customer data\n"
        "- Use SELECT/INSERT/UPDATE/DELETE only\n"
        "- Always use WHERE for UPDATE/DELETE\n"
        f"- For INSERT: VALUES ({context.business_id}, 'CUS-000040', '', '', '', '', '', '', '', '', '')\n"
        "- ALWAYS use ORDER BY xcus for customer queries\n"
        "- For 'last customer': Use WHERE xcus = (SELECT xcus FROM cacus ORDER BY xcus DESC LIMIT 1)\n"
        "- For 'first customer': Use WHERE xcus = (SELECT xcus FROM cacus ORDER BY xcus ASC LIMIT 1)\n"
        "- NEVER update xcus field (customer code) - it's a unique identifier\n"
        "- Use ILIKE for partial name matches\n"
        "- Output SQL only, no explanations\n"
        "- Use primary keys in WHERE clauses\n"
    )
    return sql_prompt

def get_customer_primary_keys_from_schema(schema_context):
    """Extract primary keys from customer schema context for validation"""
    primary_keys = {}
    for schema in schema_context:
        table_name = schema.get('table_name', 'Unknown')
        table_primary_keys = []
        
        if schema.get('relationships'):
            for rel in schema.get('relationships', []):
                if rel.get('relationship_type') == 'primary_key':
                    table_primary_keys.append(rel.get('from_column', 'Unknown'))
        
        if table_primary_keys:
            primary_keys[table_name] = table_primary_keys
    
    return primary_keys

def get_customer_foreign_keys_from_schema(schema_context):
    """Extract foreign keys from customer schema context for validation"""
    foreign_keys = {}
    for schema in schema_context:
        table_name = schema.get('table_name', 'Unknown')
        table_foreign_keys = []
        
        if schema.get('relationships'):
            for rel in schema.get('relationships', []):
                if rel.get('relationship_type') == 'foreign_key':
                    table_foreign_keys.append({
                        'column': rel.get('from_column', 'Unknown'),
                        'referenced_table': rel.get('referenced_table', 'Unknown'),
                        'referenced_column': rel.get('referenced_column', 'Unknown')
                    })
        
        if table_foreign_keys:
            foreign_keys[table_name] = table_foreign_keys
    
    return foreign_keys

def clean_customer_sql_from_llm(sql_response):
    # Remove markdown/code block and common prefixes, as in your main.py
    sql_query = sql_response.strip()
    if sql_query.startswith('```'):
        lines = sql_query.split('\n')
        if len(lines) > 1:
            sql_lines = []
            for line in lines[1:]:
                if line.strip() == '```':
                    break
                sql_lines.append(line)
            sql_query = '\n'.join(sql_lines).strip()
    lines = sql_query.split('\n')
    if lines:
        first_line = lines[0].strip()
        prefixes_to_remove = ['sql query:', 'sql:', 'query:']
        for prefix in prefixes_to_remove:
            if first_line.lower().startswith(prefix):
                first_line = first_line[len(prefix):].strip()
                break
        lines[0] = first_line
        sql_query = '\n'.join(lines).strip()
    sql_query = sql_query.rstrip(';').strip()
    return sql_query

def format_customer_db_result(mcp_result):
    """
    Format customer database results in a user-friendly way.
    Filters out empty fields and uses readable field names.
    """
    if isinstance(mcp_result, dict):
        if mcp_result.get('success') and mcp_result.get('results'):
            rows = mcp_result['results']
            if not rows:
                return "I couldn't find any matching customer records for your request."
            
            if len(rows) == 1:
                return format_single_customer_record(rows[0])
            else:
                return format_multiple_customer_records(rows)
        elif mcp_result.get('success'):
            return "Customer query executed successfully, but no records found."
        elif mcp_result.get('error'):
            return f"Error: {mcp_result['error']}"
        else:
            # Fallback: pretty-print JSON
            import json
            return json.dumps(mcp_result, indent=2)
    
    # Try to parse as JSON string
    try:
        import json
        parsed = json.loads(mcp_result)
        return format_customer_db_result(parsed)
    except Exception:
        pass
    
    # Fallback: return as-is
    return str(mcp_result)

def get_user_friendly_field_name(field_name):
    """
    Convert database field names to user-friendly names.
    """
    field_mapping = {
        'xcus': 'Customer ID',
        'xorg': 'Organization',
        'xfirst': 'First Name',
        'xlast': 'Last Name',
        'xmiddle': 'Middle Name',
        'xemail': 'Email',
        'xphone': 'Phone',
        'xmobile': 'Mobile',
        'xfax': 'Fax',
        'xadd1': 'Address Line 1',
        'xadd2': 'Address Line 2',
        'xcity': 'City',
        'xstate': 'State',
        'xzip': 'ZIP Code',
        'xcountry': 'Country',
        'xtitle': 'Title',
        'xstatuscus': 'Status',
        'xtcus': 'Customer Type',
        'xgcus': 'Customer Group',
        'xtaxscope': 'Tax Scope',
        'xaccar': 'AR Account',
        'xacctd': 'TD Account',
        'xcrlimit': 'Credit Limit',
        'xcreditr': 'Credit Rating',
        'xcrterms': 'Credit Terms',
        'xdisc': 'Discount',
        'xagent': 'Agent',
        'xcomm': 'Commission',
        'xpayins': 'Payment Instructions',
        'xindustry': 'Industry',
        'xdatecra': 'Created Date',
        'xdateapp': 'Application Date',
        'xdateexp': 'Expiry Date',
        'xdatecorp': 'Incorporation Date',
        'xdatecre': 'Credit Date',
        'xdatefst': 'First Order Date',
        'xbilladd': 'Billing Address',
        'xlicense': 'License',
        'xtypebo': 'Business Type',
        'xeccnum': 'ECC Number',
        'xeccrange': 'ECC Range',
        'xeccdiv': 'ECC Division',
        'xecccom': 'ECC Company',
        'xvatnum': 'VAT Number',
        'xcstnum': 'CST Number',
        'xpannum': 'PAN Number',
        'xregoff': 'Registration Office',
        'xmethodpay': 'Payment Method',
        'xmethodship': 'Shipping Method',
        'xrem': 'Remarks',
        'xpoints': 'Points',
        'xvalid': 'Valid',
        'xwh': 'Warehouse',
        'xaccdef': 'Default Account',
        'xlogo': 'Logo',
        'xshort': 'Short Name',
        'xsalute': 'Salutation',
        'xurl': 'Website',
        'xid': 'ID',
        'xtaxnum': 'Tax Number',
        'xgprice': 'Group Price',
        'xsic': 'SIC Code',
        'zid': 'Business ID',
        'ztime': 'Created Time',
        'zutime': 'Updated Time'
    }
    
    return field_mapping.get(field_name, field_name.title().replace('_', ' '))

def is_empty_value(value):
    """
    Check if a value is considered empty for display purposes.
    """
    if value is None:
        return True
    if isinstance(value, str) and value.strip() == '':
        return True
    if isinstance(value, str) and value.strip().lower() in ['null', 'none', '']:
        return True
    return False

def format_single_customer_record(customer_data):
    """
    Format a single customer record in a readable way.
    Only shows non-empty fields with user-friendly names.
    """
    if not customer_data:
        return "No customer data available."
    
    # Filter out empty fields and format non-empty ones
    formatted_fields = []
    
    for field_name, value in customer_data.items():
        if not is_empty_value(value):
            friendly_name = get_user_friendly_field_name(field_name)
            formatted_fields.append(f"{friendly_name}: {value}")
    
    if not formatted_fields:
        return "Customer record found but all fields are empty."
    
    # Create a readable summary
    customer_id = customer_data.get('xcus', 'Unknown')
    name_parts = []
    if customer_data.get('xfirst'):
        name_parts.append(customer_data['xfirst'])
    if customer_data.get('xlast'):
        name_parts.append(customer_data['xlast'])
    
    if name_parts:
        name = ' '.join(name_parts)
        summary = f"Customer {customer_id} ({name})"
    else:
        summary = f"Customer {customer_id}"
    
    # Add organization if available
    if customer_data.get('xorg'):
        summary += f" from {customer_data['xorg']}"
    
    summary += ":\n"
    
    # Add formatted fields
    summary += "\n".join(f"• {field}" for field in formatted_fields)
    
    return summary

def format_multiple_customer_records(customers_data):
    """
    Format multiple customer records in a table format.
    Only shows non-empty fields and uses user-friendly column names.
    """
    if not customers_data:
        return "No customer records found."
    
    # Get all unique field names from all records
    all_fields = set()
    for customer in customers_data:
        all_fields.update(customer.keys())
    
    # Filter out empty fields across all records
    non_empty_fields = []
    for field in all_fields:
        # Check if this field has any non-empty values across all records
        has_data = any(not is_empty_value(customer.get(field)) for customer in customers_data)
        if has_data:
            non_empty_fields.append(field)
    
    if not non_empty_fields:
        return "Customer records found but all fields are empty."
    
    # Sort fields to put important ones first
    field_priority = ['xcus', 'xfirst', 'xlast', 'xorg', 'xemail', 'xphone', 'xcity', 'xstatuscus']
    sorted_fields = []
    
    # Add priority fields first
    for field in field_priority:
        if field in non_empty_fields:
            sorted_fields.append(field)
            non_empty_fields.remove(field)
    
    # Add remaining fields
    sorted_fields.extend(sorted(non_empty_fields))
    
    # Create table header
    headers = [get_user_friendly_field_name(field) for field in sorted_fields]
    table_lines = [" | ".join(headers)]
    table_lines.append("-|-".join(["---"] * len(headers)))
    
    # Add data rows
    for customer in customers_data:
        row_data = []
        for field in sorted_fields:
            value = customer.get(field, '')
            if is_empty_value(value):
                row_data.append('-')
            else:
                row_data.append(str(value))
        table_lines.append(" | ".join(row_data))
    
    return f"Found {len(customers_data)} customer record(s):\n\n" + "\n".join(table_lines) 