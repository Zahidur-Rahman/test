import { useEffect, useState } from 'react'
import { apiFetch } from '../utils/api'

export default function Admin() {
  const [businesses, setBusinesses] = useState<any[]>([])
  const [users, setUsers] = useState<any[]>([])

  useEffect(() => {
    (async () => {
      const biz = await apiFetch('/admin/businesses')
      setBusinesses(biz.items || [])
      const usr = await apiFetch('/admin/users')
      setUsers(usr.items || [])
    })()
  }, [])

  return (
    <div className="min-h-screen p-6 max-w-5xl mx-auto">
      <h1 className="text-2xl font-semibold mb-6">Admin Dashboard</h1>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Businesses</h2>
        <div className="bg-white border rounded p-4">
          <pre className="text-xs whitespace-pre-wrap">{JSON.stringify(businesses, null, 2)}</pre>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-2">Users</h2>
        <div className="bg-white border rounded p-4">
          <pre className="text-xs whitespace-pre-wrap">{JSON.stringify(users, null, 2)}</pre>
        </div>
      </section>
    </div>
  )
}
