// Admin Dashboard JavaScript
// Set window.ADMIN_API_BASE = 'http://localhost:8000' in admin.html if serving from a different origin
const API_BASE = (typeof window !== 'undefined' && window.ADMIN_API_BASE) ? window.ADMIN_API_BASE.replace(/\/$/, '') : '';
class AdminDashboard {
    constructor() {
        this.currentSection = 'dashboard';
        this.currentPage = 1;
        this.pageSize = 50;
        this.currentBusinessId = null;
        this.editingItem = null;
        // Caches for edit/detail views without extra API calls
        this.businessesCache = [];
        this.usersCache = [];
        this.schemasCache = [];
        this.init();
    }

    toggleDbConfigFields(enabled) {
        const fields = document.getElementById('dbConfigFields');
        if (fields) fields.style.display = enabled ? 'block' : 'none';
        this.setDbFieldsDisabled(!enabled);
    }

    setDbFieldsDisabled(disabled) {
        const ids = ['dbHost','dbName','dbUser','dbPassword','dbPort','dbSSLMode'];
        ids.forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.disabled = disabled;
                // Required only when enabled (create or toggle on)
                if (id !== 'dbSSLMode') {
                    el.required = !disabled;
                }
            }
        });
    }

    async init() {
        this.setupEventListeners();
        await this.checkAuth();
        this.loadDashboard();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                this.switchSection(section);
            });
        });

        // Forms
        document.getElementById('businessForm').addEventListener('submit', (e) => this.handleBusinessSubmit(e));
        document.getElementById('userForm').addEventListener('submit', (e) => this.handleUserSubmit(e));
        document.getElementById('schemaForm').addEventListener('submit', (e) => this.handleSchemaSubmit(e));

        // Edit DB config toggle (may not exist on page load in some contexts)
        const editDbToggle = document.getElementById('editDbConfig');
        if (editDbToggle) {
            editDbToggle.addEventListener('change', () => this.toggleDbConfigFields(editDbToggle.checked));
        }

        // Schema mode toggle (may not exist on page load)
        const schemaModeSelect = document.getElementById('schemaMode');
        if (schemaModeSelect) {
            schemaModeSelect.addEventListener('change', () => this.toggleSchemaMode());
        }
    }

    async checkAuth() {
        try {
            const response = await fetch(`${API_BASE}/auth/me`, {
                credentials: 'include'
            });
            
            if (!response.ok) {
                window.location.href = `${API_BASE}/login.html`;
                return;
            }
            
            const user = await response.json();
            if (user.role !== 'admin') {
                alert('Access denied. Admin role required.');
                window.location.href = '/login.html';
                return;
            }
            
            document.getElementById('adminUserName').textContent = user.username;
        } catch (error) {
            console.error('Auth check failed:', error);
            console.error('Error details:', error.message, error.stack);
            window.location.href = `${API_BASE}/login.html`;
        }
    }

    switchSection(section) {
        // Update navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        document.querySelector(`[data-section="${section}"]`).classList.add('active');

        // Update sections
        document.querySelectorAll('.admin-section').forEach(sec => {
            sec.classList.remove('active');
        });
        document.getElementById(`${section}-section`).classList.add('active');

        // Update page title
        const titles = {
            dashboard: 'Dashboard',
            businesses: 'Businesses',
            users: 'Users',
            schemas: 'Schemas',
            settings: 'Settings'
        };
        document.getElementById('pageTitle').textContent = titles[section];

        this.currentSection = section;
        this.loadSectionData(section);
    }

    async loadSectionData(section) {
        switch (section) {
            case 'dashboard':
                await this.loadDashboard();
                break;
            case 'businesses':
                await this.loadBusinesses();
                break;
            case 'users':
                await this.loadUsers();
                await this.loadBusinessOptions();
                break;
            case 'schemas':
                await this.loadBusinessOptions('schemaBusinessSelect');
                break;
        }
    }

    async loadDashboard() {
        try {
            // Load stats
            const [bizResp, userResp] = await Promise.all([
                this.apiCall('/admin/businesses?include_inactive=true'),
                this.apiCall('/admin/users?page_size=1000')
            ]);

            const businesses = bizResp?.businesses || [];
            const users = userResp?.users || [];
            const activeBusinesses = businesses.filter(b => (b.status || 'active') === 'active').length;
            let totalSchemas = 0;
            
            for (const business of businesses) {
                try {
                    const schemaResp = await this.apiCall(`/admin/businesses/${business.business_id}/schemas`);
                    const schemas = schemaResp?.schemas || [];
                    totalSchemas += schemas.length;
                } catch (e) {
                    // Skip if error
                }
            }

            document.getElementById('totalBusinesses').textContent = businesses.length;
            document.getElementById('totalUsers').textContent = users.length;
            document.getElementById('totalSchemas').textContent = totalSchemas;
            document.getElementById('activeBusinesses').textContent = activeBusinesses;

        } catch (error) {
            console.error('Failed to load dashboard:', error);
        }
    }

    async loadBusinesses() {
        const includeInactive = document.getElementById('includeInactive').checked;
        try {
            const resp = await this.apiCall(`/admin/businesses?include_inactive=${includeInactive}`);
            const businesses = resp?.businesses || [];
            this.businessesCache = businesses;
            this.renderBusinessesTable(businesses);
        } catch (error) {
            console.error('Failed to load businesses:', error);
            this.showError('Failed to load businesses');
        }
    }

    renderBusinessesTable(businesses) {
        const tbody = document.getElementById('businessesTableBody');
        if (businesses.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="no-data">No businesses found</td></tr>';
            return;
        }

        tbody.innerHTML = businesses.map(business => `
            <tr>
                <td>${this.escapeHtml(business.business_id)}</td>
                <td>${this.escapeHtml(business.name || 'N/A')}</td>
                <td><span class="status-badge status-${business.status}">${business.status}</span></td>
                <td>${this.formatDate(business.created_at)}</td>
                <td class="action-buttons">
                    <button class="action-btn edit" onclick="adminDashboard.editBusiness('${business.business_id}')">Edit</button>
                    <button class="action-btn delete" onclick="adminDashboard.deleteBusiness('${business.business_id}')">Delete</button>
                </td>
            </tr>
        `).join('');
    }

    async loadUsers() {
        const page = this.currentPage;
        const pageSize = this.pageSize;
        const role = document.getElementById('roleFilter')?.value || '';
        const businessId = document.getElementById('businessFilter')?.value || '';

        try {
            const params = new URLSearchParams({
                page: page.toString(),
                page_size: pageSize.toString()
            });
            if (role) params.append('role', role);
            if (businessId) params.append('business_id', businessId);

            const resp = await this.apiCall(`/admin/users?${params}`);
            const users = resp?.users || [];
            this.usersCache = users;
            this.renderUsersTable(users);
            this.updatePagination(users.length);
        } catch (error) {
            console.error('Failed to load users:', error);
            this.showError('Failed to load users');
        }
    }

    renderUsersTable(users) {
        const tbody = document.getElementById('usersTableBody');
        if (users.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="no-data">No users found</td></tr>';
            return;
        }

        tbody.innerHTML = users.map(user => `
            <tr>
                <td>${this.escapeHtml(user.username)}</td>
                <td>${this.escapeHtml(user.email)}</td>
                <td><span class="status-badge status-${user.role === 'admin' ? 'active' : 'inactive'}">${user.role}</span></td>
                <td>${this.escapeHtml(user.business_id)}</td>
                <td>${this.formatDate(user.last_login)}</td>
                <td class="action-buttons">
                    <button class="action-btn edit" onclick="adminDashboard.editUser('${user.username}')">Edit</button>
                    <button class="action-btn delete" onclick="adminDashboard.deleteUser('${user.username}')">Delete</button>
                </td>
            </tr>
        `).join('');
    }

    async loadSchemas() {
        const businessId = document.getElementById('schemaBusinessSelect').value;
        if (!businessId) {
            document.getElementById('schemasTableBody').innerHTML = '<tr><td colspan="6" class="no-data">Select a business to view schemas</td></tr>';
            document.getElementById('addSchemaBtn').disabled = true;
            document.getElementById('reindexBtn').disabled = true;
            this.currentBusinessId = null;
            return;
        }

        console.log(`Loading schemas for business: ${businessId}`);
        this.currentBusinessId = businessId;
        document.getElementById('addSchemaBtn').disabled = false;
        document.getElementById('reindexBtn').disabled = false;

        try {
            const resp = await this.apiCall(`/admin/businesses/${businessId}/schemas`);
            console.log('Schemas response:', resp);
            const schemas = resp?.schemas || [];
            this.schemasCache = schemas;
            this.renderSchemasTable(schemas);
            
            if (schemas.length === 0) {
                this.showSuccess(`No schemas found for business ${businessId}. Create your first schema using the "Add Schema" button.`);
            } else {
                this.showSuccess(`Loaded ${schemas.length} schemas for business ${businessId}`);
            }
        } catch (error) {
            console.error('Failed to load schemas:', error);
            this.showError(`Failed to load schemas: ${error.message}`);
            document.getElementById('schemasTableBody').innerHTML = '<tr><td colspan="6" class="no-data">Failed to load schema details</td></tr>';
        }
    }

    renderSchemasTable(schemas) {
        const tbody = document.getElementById('schemasTableBody');
        if (schemas.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="no-data">No schemas found for this business</td></tr>';
            return;
        }

        tbody.innerHTML = schemas.map(schema => `
            <tr>
                <td>${this.escapeHtml(schema.table_name)}</td>
                <td>${this.escapeHtml(schema.schema_description || 'N/A')}</td>
                <td>${schema.columns ? schema.columns.length : 0} columns</td>
                <td>${this.escapeHtml(schema.vector_id || 'Not indexed')}</td>
                <td>${this.formatDate(schema.updated_at)}</td>
                <td class="action-buttons">
                    <button class="action-btn edit" onclick="adminDashboard.editSchema('${schema.table_name}')">Edit</button>
                    <button class="action-btn delete" onclick="adminDashboard.deleteSchema('${schema.table_name}')">Delete</button>
                </td>
            </tr>
        `).join('');
    }

    async loadBusinessOptions(selectId = 'businessFilter') {
        try {
            const resp = await this.apiCall('/admin/businesses');
            const businesses = resp?.businesses || [];
            this.businessesCache = businesses;
            const select = document.getElementById(selectId);
            if (!select) return;

            const currentValue = select.value;
            select.innerHTML = selectId === 'businessFilter' ? 
                '<option value="">All Businesses</option>' : 
                '<option value="">Select Business</option>';
            
            businesses.forEach(business => {
                const option = document.createElement('option');
                option.value = business.business_id;
                option.textContent = business.business_id;
                select.appendChild(option);
            });

            if (currentValue) select.value = currentValue;

            // Also populate user modal business select
            if (selectId === 'businessFilter') {
                const userBusinessSelect = document.getElementById('userBusinessId');
                if (userBusinessSelect) {
                    const userCurrentValue = userBusinessSelect.value;
                    userBusinessSelect.innerHTML = '<option value="">Select Business</option>';
                    businesses.forEach(business => {
                        const option = document.createElement('option');
                        option.value = business.business_id;
                        option.textContent = business.business_id;
                        userBusinessSelect.appendChild(option);
                    });
                    if (userCurrentValue) userBusinessSelect.value = userCurrentValue;
                }
            }
        } catch (error) {
            console.error('Failed to load business options:', error);
        }
    }

    // Modal Management
    showCreateBusinessModal() {
        this.editingItem = null;
        document.getElementById('businessModalTitle').textContent = 'Add Business';
        document.getElementById('businessForm').reset();
        document.getElementById('businessId').disabled = false;
        // Show DB config fields and ensure required for create
        const wrapper = document.getElementById('editDbConfigWrapper');
        const toggle = document.getElementById('editDbConfig');
        const fields = document.getElementById('dbConfigFields');
        if (wrapper) wrapper.style.display = 'none';
        if (toggle) toggle.checked = true;
        if (fields) fields.style.display = 'block';
        this.setDbFieldsDisabled(false);
        this.showModal('businessModal');
    }

    showCreateUserModal() {
        this.editingItem = null;
        document.getElementById('userModalTitle').textContent = 'Add User';
        document.getElementById('userForm').reset();
        document.getElementById('userUsername').disabled = false;
        document.getElementById('passwordGroup').style.display = 'block';
        document.getElementById('userPassword').required = true;
        this.showModal('userModal');
    }

    showCreateSchemaModal() {
        // Check for business ID from schema section or main context
        const schemaBusinessId = document.getElementById('schemaBusinessSelect')?.value;
        const businessId = schemaBusinessId || this.currentBusinessId;
        
        if (!businessId) {
            this.showError('Please select a business first');
            return;
        }
        
        // Redirect to the dedicated schema builder page
        window.location.href = `schema-builder.html?business_id=${businessId}`;
    }

    toggleSchemaMode() {
        const mode = document.getElementById('schemaMode').value;
        const introspectMode = document.getElementById('introspectMode');
        const manualMode = document.getElementById('manualMode');
        
        if (mode === 'introspect') {
            introspectMode.style.display = 'block';
            manualMode.style.display = 'none';
            document.getElementById('schemaTableSelect').required = true;
            document.getElementById('schemaTableNameManual').required = false;
        } else {
            introspectMode.style.display = 'none';
            manualMode.style.display = 'block';
            document.getElementById('schemaTableSelect').required = false;
            document.getElementById('schemaTableNameManual').required = true;
        }
    }

    async testDatabaseConnection() {
        console.log('testDatabaseConnection called');
        if (!this.currentBusinessId) {
            console.error('No currentBusinessId set');
            this.showError('Please select a business first');
            return;
        }

        const statusEl = document.getElementById('connectionStatus');
        const testBtn = document.getElementById('testConnectionBtn');
        
        if (!statusEl || !testBtn) {
            console.error('Modal elements not found:', { statusEl, testBtn });
            this.showError('Modal elements not found');
            return;
        }
        
        try {
            testBtn.disabled = true;
            statusEl.textContent = 'Testing...';
            statusEl.className = 'connection-status testing';
            
            console.log(`Testing connection for business: ${this.currentBusinessId}`);
            const response = await this.apiCall(`/admin/businesses/${this.currentBusinessId}/test-connection`, 'POST');
            
            console.log('Connection test response:', response);
            
            if (response.success) {
                statusEl.textContent = '✅ Connected';
                statusEl.className = 'connection-status connected';
                this.showSuccess('Database connection successful');
                // Auto-load tables after successful connection
                setTimeout(() => this.loadDatabaseTables(), 500);
            } else {
                statusEl.textContent = '❌ Connection Failed';
                statusEl.className = 'connection-status failed';
                this.showError('Database connection failed. Please check your database configuration.');
            }
        } catch (error) {
            statusEl.textContent = '❌ Connection Error';
            statusEl.className = 'connection-status failed';
            console.error('Connection test failed:', error);
            this.showError(`Connection error: ${error.message}`);
        } finally {
            testBtn.disabled = false;
        }
    }

    async loadDatabaseTables() {
        if (!this.currentBusinessId) {
            this.showError('Please select a business first');
            return;
        }

        const loadBtn = document.getElementById('loadTablesBtn');
        const tableSelect = document.getElementById('schemaTableSelect');
        
        try {
            loadBtn.disabled = true;
            loadBtn.textContent = '🔄 Loading...';
            
            console.log(`Loading tables for business: ${this.currentBusinessId}`);
            const response = await this.apiCall(`/admin/businesses/${this.currentBusinessId}/tables`);
            console.log('Tables response:', response);
            
            const tables = response.tables || [];
            
            // Clear existing options
            tableSelect.innerHTML = '<option value="">Select a table...</option>';
            
            // Add table options
            tables.forEach(table => {
                const option = document.createElement('option');
                option.value = table.table_name;
                option.textContent = `${table.table_name}${table.description ? ' - ' + table.description : ''}`;
                tableSelect.appendChild(option);
            });
            
            // Clear columns preview when tables are reloaded
            const previewEl = document.getElementById('columnsPreview');
            if (previewEl) {
                previewEl.innerHTML = '<p class="text-muted">Select a table to see its columns</p>';
            }
            
            if (tables.length === 0) {
                this.showError('No tables found in the database. Make sure your database has tables in the public schema.');
                tableSelect.innerHTML = '<option value="">No tables found</option>';
            } else {
                this.showSuccess(`Loaded ${tables.length} tables from database`);
            }
        } catch (error) {
            console.error('Failed to load tables:', error);
            this.showError(`Failed to load database tables: ${error.message}`);
            tableSelect.innerHTML = '<option value="">Error loading tables</option>';
        } finally {
            loadBtn.disabled = false;
            loadBtn.textContent = '🔄 Load Tables';
        }
    }

    async loadTableColumns() {
        const tableName = document.getElementById('schemaTableSelect').value;
        if (!tableName) {
            this.showError('Please select a table first');
            return;
        }

        const businessId = this.currentBusinessId;
        if (!businessId) {
            this.showError('Please select a business first');
            return;
        }

        try {
            // Load columns and relationships in parallel
            const [columnsResponse, relationshipsResponse] = await Promise.all([
                this.apiCall(`/admin/businesses/${businessId}/tables/${tableName}/columns`),
                this.apiCall(`/admin/businesses/${businessId}/tables/${tableName}/relationships`)
            ]);

            this.currentTableColumns = columnsResponse.columns || [];
            this.currentTableRelationships = relationshipsResponse.relationships || [];

            // Show column configuration step
            document.getElementById('columnConfigurationStep').style.display = 'block';

            // Populate column dropdown
            this.populateColumnDropdown();

        } catch (error) {
            console.error('Error loading table columns:', error);
            this.showError('Failed to load table columns');
        }
    }
    
    // Step workflow methods
    proceedToColumnSelection() {
        const description = document.getElementById('schemaDescription').value.trim();
        if (!description) {
            this.showError('Please enter a schema description');
            return;
        }
        
        // Hide description step, show column configuration
        document.getElementById('tableDescriptionStep').style.display = 'none';
        document.getElementById('columnConfigurationStep').style.display = 'block';
        document.getElementById('previousStepBtn').style.display = 'inline-block';
        
        // Render column selection UI
        const tableSelect = document.getElementById('schemaTableSelect');
        this.renderColumnSelection(tableSelect.value);
    }
    
    proceedToRelationships() {
        // Get selected columns from multiselect
        const columnSelect = document.getElementById('columnSelect');
        const selectedOptions = Array.from(columnSelect.selectedOptions);
        
        if (selectedOptions.length === 0) {
            this.showError('Please select at least one column');
            return;
        }

        // Store selected columns
        this.selectedColumns = new Set(selectedOptions.map(option => option.value));
        
        // Show relationships step
        document.getElementById('relationshipsConfigurationStep').style.display = 'block';
        document.getElementById('saveSchemaBtn').style.display = 'inline-block';
        
        // Render relationships
        this.renderRelationshipsPreview();
    }
    
    previousStep() {
        const columnStep = document.getElementById('columnConfigurationStep');
        const relationshipStep = document.getElementById('relationshipsConfigurationStep');
        const descriptionStep = document.getElementById('tableDescriptionStep');
        
        if (relationshipStep.style.display !== 'none') {
            // From relationships back to columns
            relationshipStep.style.display = 'none';
            columnStep.style.display = 'block';
            document.getElementById('saveSchemaBtn').style.display = 'none';
        } else if (columnStep.style.display !== 'none') {
            // From columns back to description
            columnStep.style.display = 'none';
            descriptionStep.style.display = 'block';
            document.getElementById('previousStepBtn').style.display = 'none';
        }
    }
    
    updateColumnBusinessMeaning(columnName, businessMeaning) {
        const column = this.currentTableColumns.find(col => col.name === columnName);
        if (column) {
            column.business_meaning = businessMeaning;
        }
    }
    
    resetSchemaModal() {
        // Reset all steps to initial state
        document.getElementById('tableDescriptionStep').style.display = 'none';
        document.getElementById('columnConfigurationStep').style.display = 'none';
        document.getElementById('relationshipsConfigurationStep').style.display = 'none';
        document.getElementById('previousStepBtn').style.display = 'none';
        document.getElementById('saveSchemaBtn').style.display = 'none';
        document.getElementById('proceedToRelationshipsBtn').style.display = 'none';
        
        // Clear form data
        document.getElementById('schemaTableSelect').value = '';
        document.getElementById('schemaDescription').value = '';
        document.getElementById('columnsPreview').innerHTML = '<p class="text-muted">Select a table to see its columns</p>';
        document.getElementById('relationshipsPreview').innerHTML = '<p class="text-muted">Loading relationships...</p>';
        
        // Reset internal state
        this.selectedColumns = new Set();
        this.currentTableColumns = [];
        this.currentTableRelationships = [];
    }
    
    renderTableRelationships(relationships, tableName) {
        const relationshipsPreview = document.getElementById('relationshipsPreview');
        
        if (relationships.length === 0) {
            relationshipsPreview.innerHTML = '<p class="text-muted">No relationships found for this table</p>';
            return;
        }
        
        let html = `<div class="relationships-list">`;
        
        relationships.forEach(rel => {
            const isSource = rel.source_table === tableName;
            const direction = isSource ? '→' : '←';
            const otherTable = isSource ? rel.target_table : rel.source_table;
            const thisColumn = isSource ? rel.source_column : rel.target_column;
            const otherColumn = isSource ? rel.target_column : rel.source_column;
            
            html += `
                <div class="relationship-item">
                    <span class="relationship-source">${tableName}.${thisColumn}</span>
                    <span class="relationship-arrow">${direction}</span>
                    <span class="relationship-target">${otherTable}.${otherColumn}</span>
                    <small class="relationship-type">(${rel.relationship_type})</small>
                </div>
            `;
        });
        
        html += '</div>';
        relationshipsPreview.innerHTML = html;
    }
    
    toggleColumnSelection(columnName) {
        const columnItem = document.querySelector(`[data-column="${columnName}"]`);
        const checkbox = columnItem.querySelector('.column-checkbox');
        
        if (checkbox.checked) {
            this.selectedColumns.add(columnName);
            columnItem.classList.add('selected');
        } else {
            this.selectedColumns.delete(columnName);
            columnItem.classList.remove('selected');
        }
    }
    
    selectAllColumns() {
        const checkboxes = document.querySelectorAll('.column-checkbox');
        const columnItems = document.querySelectorAll('.column-item');
        
        checkboxes.forEach(cb => cb.checked = true);
        columnItems.forEach(item => item.classList.add('selected'));
        
        // Update selected columns set
        this.selectedColumns.clear();
        this.currentTableColumns.forEach(col => this.selectedColumns.add(col.name));
    }
    
    deselectAllColumns() {
        const checkboxes = document.querySelectorAll('.column-checkbox');
        const columnItems = document.querySelectorAll('.column-item');
        
        checkboxes.forEach(cb => cb.checked = false);
        columnItems.forEach(item => item.classList.remove('selected'));
        
        // Clear selected columns set
        this.selectedColumns.clear();
    }
    
    updateColumnDescription(columnName, description) {
        // Store the description update for later use when saving schema
        if (!this.columnDescriptions) {
            this.columnDescriptions = {};
        }
        this.columnDescriptions[columnName] = description;
    }
    
    async showRelationshipDiagram() {
        const businessId = this.getSelectedBusinessId();
        if (!businessId) {
            this.showMessage('Please select a business first', 'error');
            return;
        }
        
        // Show the relationship modal
        this.showModal('relationshipModal');
        
        // Load and render the diagram
        await this.loadAndRenderDiagram(businessId);
    }
    
    async loadAndRenderDiagram(businessId) {
        const diagramContainer = document.getElementById('relationshipDiagram');
        
        try {
            diagramContainer.innerHTML = '<p class="text-muted">Loading diagram...</p>';
            
            // Get all tables and relationships
            const [tablesResponse, relationshipsResponse] = await Promise.all([
                this.apiCall(`/admin/businesses/${businessId}/tables`),
                this.apiCall(`/admin/businesses/${businessId}/relationships`)
            ]);
            
            this.renderRelationshipDiagram(tablesResponse.tables, relationshipsResponse.relationships);
        } catch (error) {
            console.error('Error loading diagram:', error);
            diagramContainer.innerHTML = '<p class="text-error">Error loading diagram</p>';
        }
    }
    
    renderRelationshipDiagram(tables, relationships) {
        const diagramContainer = document.getElementById('relationshipDiagram');
        
        // Clear container
        diagramContainer.innerHTML = '';
        
        // Simple layout algorithm - arrange tables in a grid
        const cols = Math.ceil(Math.sqrt(tables.length));
        const tableWidth = 200;
        const tableHeight = 150;
        const spacing = 50;
        
        tables.forEach((table, index) => {
            const row = Math.floor(index / cols);
            const col = index % cols;
            const x = col * (tableWidth + spacing) + 50;
            const y = row * (tableHeight + spacing) + 50;
            
            const tableDiv = document.createElement('div');
            tableDiv.className = 'diagram-table';
            tableDiv.style.left = x + 'px';
            tableDiv.style.top = y + 'px';
            tableDiv.innerHTML = `
                <div class="diagram-table-header">${table.table_name}</div>
                <div class="diagram-columns">
                    <div class="diagram-column">Loading columns...</div>
                </div>
            `;
            
            diagramContainer.appendChild(tableDiv);
            
            // Load columns for this table (simplified for demo)
            this.loadTableColumnsForDiagram(table.table_name, tableDiv);
        });
        
        // Draw relationship lines (simplified)
        this.drawRelationshipLines(relationships, tables);
    }
    
    async loadTableColumnsForDiagram(tableName, tableDiv) {
        const businessId = this.getSelectedBusinessId();
        try {
            const response = await this.apiCall(`/admin/businesses/${businessId}/tables/${tableName}/columns`);
            const columnsContainer = tableDiv.querySelector('.diagram-columns');
            
            let html = '';
            response.columns.slice(0, 5).forEach(col => { // Show only first 5 columns
                const classes = [];
                if (col.is_primary_key) classes.push('primary-key');
                if (col.name.toLowerCase().includes('_id')) classes.push('foreign-key');
                
                html += `<div class="diagram-column ${classes.join(' ')}">${col.name} (${col.type})</div>`;
            });
            
            if (response.columns.length > 5) {
                html += `<div class="diagram-column">... +${response.columns.length - 5} more</div>`;
            }
            
            columnsContainer.innerHTML = html;
        } catch (error) {
            console.error('Error loading columns for diagram:', error);
        }
    }
    
    drawRelationshipLines(relationships, tables) {
        // Simplified relationship line drawing
        // In a production app, you'd use a proper diagramming library like D3.js or vis.js
        relationships.forEach(rel => {
            const sourceTable = tables.find(t => t.table_name === rel.source_table);
            const targetTable = tables.find(t => t.table_name === rel.target_table);
            
            if (sourceTable && targetTable) {
                // This is a very basic line drawing - in reality you'd want proper connectors
                console.log(`Relationship: ${rel.source_table}.${rel.source_column} → ${rel.target_table}.${rel.target_column}`);
            }
        });
    }
    
    async refreshRelationships() {
        const businessId = this.getSelectedBusinessId();
        if (businessId) {
            await this.loadAndRenderDiagram(businessId);
        }
    }
    
    exportDiagram() {
        // Simple export functionality
        const diagramContainer = document.getElementById('relationshipDiagram');
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        
        // This is a placeholder - you'd use a proper export library
        this.showMessage('Diagram export feature coming soon!', 'info');
    }

    async editBusiness(businessId) {
        try {
            const business = this.businessesCache.find(b => b.business_id === businessId);
            if (!business) throw new Error('Business not found in cache');
            this.editingItem = business;
            document.getElementById('businessModalTitle').textContent = 'Edit Business';
            document.getElementById('businessId').value = business.business_id;
            document.getElementById('businessId').disabled = true;
            document.getElementById('businessName').value = business.name || '';
            document.getElementById('businessDescription').value = business.description || '';
            document.getElementById('businessStatus').value = business.status || 'active';
            // Hide DB config by default on edit; allow enabling via toggle
            const wrapper = document.getElementById('editDbConfigWrapper');
            const toggle = document.getElementById('editDbConfig');
            const fields = document.getElementById('dbConfigFields');
            if (wrapper) wrapper.style.display = 'block';
            if (toggle) toggle.checked = false;
            if (fields) fields.style.display = 'none';
            this.setDbFieldsDisabled(true);
            this.showModal('businessModal');
        } catch (error) {
            console.error('Failed to load business:', error);
            this.showError('Failed to load business details');
        }
    }

    async editUser(username) {
        try {
            const user = this.usersCache.find(u => u.username === username);
            if (!user) throw new Error('User not found in cache');
            this.editingItem = user;
            document.getElementById('userModalTitle').textContent = 'Edit User';
            document.getElementById('userUsername').value = user.username;
            document.getElementById('userUsername').disabled = true;
            document.getElementById('userEmail').value = user.email;
            document.getElementById('userRole').value = user.role;
            document.getElementById('userBusinessId').value = user.business_id;
            document.getElementById('passwordGroup').style.display = 'none';
            document.getElementById('userPassword').required = false;
            this.showModal('userModal');
        } catch (error) {
            console.error('Failed to load user:', error);
            this.showError('Failed to load user details');
        }
    }

    async editSchema(tableName) {
        try {
            const schema = this.schemasCache.find(s => s.table_name === tableName);
            if (!schema) throw new Error('Schema not found in cache');
            
            console.log('Redirecting to edit schema:', schema);
            
            // Redirect to Business Schema Manager with edit parameters
            const businessId = this.currentBusinessId;
            const editUrl = `business-schema-manager.html?business_id=${businessId}&table_name=${tableName}&mode=edit`;
            
            console.log('Navigating to:', editUrl);
            window.location.href = editUrl;
            
        } catch (error) {
            console.error('Failed to redirect to schema editor:', error);
            this.showError('Failed to open schema editor: ' + error.message);
        }
    }

    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }

    closeModal() {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            modal.classList.remove('show');
        });
        document.body.style.overflow = '';
        
        // Reset schema modal steps when closing
        if (window.adminDashboard) {
            window.adminDashboard.resetSchemaModal();
        }
    }

    // Form Handlers
    async handleBusinessSubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = {
            business_id: document.getElementById('businessId').value,
            name: document.getElementById('businessName').value,
            description: document.getElementById('businessDescription').value,
            status: document.getElementById('businessStatus').value
        };

        // For create, backend requires db_config
        if (!this.editingItem) {
            data.db_config = {
                host: document.getElementById('dbHost').value,
                database: document.getElementById('dbName').value,
                user: document.getElementById('dbUser').value,
                password: document.getElementById('dbPassword').value,
                port: parseInt(document.getElementById('dbPort').value || '5432', 10),
                ssl_mode: document.getElementById('dbSSLMode').value || 'require'
            };
        } else {
            // Include db_config on update only if explicitly toggled on
            const toggle = document.getElementById('editDbConfig');
            if (toggle && toggle.checked) {
                data.db_config = {
                    host: document.getElementById('dbHost').value,
                    database: document.getElementById('dbName').value,
                    user: document.getElementById('dbUser').value,
                    password: document.getElementById('dbPassword').value,
                    port: parseInt(document.getElementById('dbPort').value || '5432', 10),
                    ssl_mode: document.getElementById('dbSSLMode').value || 'require'
                };
            }
        }

        try {
            if (this.editingItem) {
                // Backend expects PUT for updates
                await this.apiCall(`/admin/businesses/${this.editingItem.business_id}`, 'PUT', data);
                this.showSuccess('Business updated successfully');
            } else {
                await this.apiCall('/admin/businesses', 'POST', data);
                this.showSuccess('Business created successfully');
            }
            this.closeModal();
            this.loadBusinesses();
        } catch (error) {
            console.error('Failed to save business:', error);
            this.showError('Failed to save business');
        }
    }

    async handleUserSubmit(e) {
        e.preventDefault();
        const username = document.getElementById('userUsername').value.trim();
        const email = document.getElementById('userEmail').value.trim();
        const role = document.getElementById('userRole').value;
        const businessSelect = document.getElementById('userBusinessId');
        let business_id = businessSelect.value.trim();
        
        // Extract just the business ID if it contains the full display text
        if (business_id.includes(' - ')) {
            business_id = business_id.split(' - ')[0].trim();
        }
        
        // Debug log to see what's being sent
        console.log('User form data:', { username, email, role, business_id });

        const data = { username, email, role, business_id };

        if (!this.editingItem) {
            const pwd = document.getElementById('userPassword').value.trim();
            data.password = pwd;
        }

        try {
            if (this.editingItem) {
                // Backend expects PUT with user_id path param
                await this.apiCall(`/admin/users/${this.editingItem.user_id}`, 'PUT', data);
                this.showSuccess('User updated successfully');
            } else {
                await this.apiCall('/admin/users', 'POST', data);
                this.showSuccess('User created successfully');
            }
            this.closeModal();
            this.loadUsers();
        } catch (error) {
            console.error('Failed to save user:', error);
            // Show specific error message from backend if available
            const errorMessage = error.message || 'Failed to save user';
            this.showError(errorMessage);
        }
    }

    async handleSchemaSubmit(e) {
        e.preventDefault();
        const mode = document.getElementById('schemaMode').value;
        let base = {};

        if (mode === 'introspect') {
            const tableName = document.getElementById('schemaTableSelect').value;
            if (!tableName) {
                this.showError('Please select a table');
                return;
            }

            try {
                // Get table details with columns from database
                const response = await this.apiCall(`/admin/businesses/${this.currentBusinessId}/tables/${tableName}`);
                base = {
                    table_name: response.table_name,
                    schema_description: document.getElementById('schemaDescription').value || response.description,
                    columns: response.columns
                };
            } catch (error) {
                console.error('Failed to get table details:', error);
                this.showError('Failed to get table details from database');
                return;
            }
        } else {
            // Manual mode
            base = {
                table_name: document.getElementById('schemaTableNameManual').value,
                schema_description: document.getElementById('schemaDescriptionManual').value
            };

            try {
                base.columns = JSON.parse(document.getElementById('schemaColumnsManual').value);
            } catch (error) {
                this.showError('Invalid JSON format for columns');
                return;
            }
        }

        try {
            if (this.editingItem) {
                await this.apiCall(`/admin/businesses/${this.currentBusinessId}/schemas/${this.editingItem.table_name}`, 'PUT', base);
            } else {
                await this.apiCall(`/admin/businesses/${this.currentBusinessId}/schemas`, 'POST', base);
            }
            this.showSuccess('Schema saved successfully');
            this.closeModal();
            this.loadSchemas();
        } catch (error) {
            console.error('Failed to save schema:', error);
            this.showError('Failed to save schema');
        }
    }

    async submitSchemaForm(event) {
        event.preventDefault();
        
        const formData = new FormData(event.target);
        const mode = formData.get('schemaMode');
        
        let schemaData;
        
        if (mode === 'introspect') {
            const tableName = document.getElementById('schemaTableName').value;
            const description = document.getElementById('schemaDescription').value;
            const columnDescription = document.getElementById('columnDescription').value;
            
            if (!tableName || !description) {
                this.showError('Please fill in all required fields');
                return;
            }
            
            if (this.selectedColumns.size === 0) {
                this.showError('Please select at least one column');
                return;
            }
            
            // Get selected columns with descriptions and business meanings
            const selectedColumns = [];
            this.currentTableColumns.forEach((column, index) => {
                if (this.selectedColumns.has(column.name)) {
                    selectedColumns.push({
                        name: column.name,
                        type: column.type,
                        max_length: column.max_length,
                        nullable: column.is_nullable,
                        default: column.default,
                        position: index,
                        business_meaning: columnDescription || '',
                        description: columnDescription || ''
                    });
                }
            });
            
            // Get manual relationship data
            const relationshipType = document.getElementById('relationshipType').value;
            const referencedTable = document.getElementById('referencedTable').value;
            const referencedColumn = document.getElementById('referencedColumn').value;
            const relationshipDescription = document.getElementById('relationshipDescription').value;
            
            const relationships = [];
            if (referencedTable && referencedColumn) {
                relationships.push({
                    table_name: tableName,
                    relationship_type: relationshipType,
                    referenced_table: referencedTable,
                    referenced_column: referencedColumn,
                    description: relationshipDescription
                });
            }
            
            schemaData = {
                table_name: tableName,
                schema_description: description,
                columns: selectedColumns,
                relationships: relationships
            };
        } else {
            // Manual mode
            const tableName = formData.get('schemaTableNameManual');
            const description = formData.get('schemaDescriptionManual');
            const columnsJson = formData.get('schemaColumnsManual');
            
            if (!tableName || !description || !columnsJson) {
                this.showError('Please fill in all required fields');
                return;
            }
            
            try {
                const columns = JSON.parse(columnsJson);
                schemaData = {
                    table_name: tableName,
                    schema_description: description,
                    columns: columns,
                    relationships: []
                };
            } catch (error) {
                this.showError('Invalid JSON format for columns');
                return;
            }
        }
        
        try {
            const response = await this.apiCall(`/admin/businesses/${this.currentBusinessId}/schemas`, 'POST', schemaData);
            
            if (response.success) {
                this.showSuccess(`Schema created successfully: ${response.message}`);
                closeModal();
                this.loadSchemas();
            } else {
                this.showError('Failed to create schema');
            }
        } catch (error) {
            console.error('Error creating schema:', error);
            this.showError(`Error creating schema: ${error.message}`);
        }
    }

    // Delete Operations
    async deleteBusiness(businessId) {
        if (!confirm(`Are you sure you want to delete business "${businessId}"? This action cannot be undone.`)) {
            return;
        }

        try {
            await this.apiCall(`/admin/businesses/${businessId}`, 'DELETE');
            this.showSuccess('Business deleted successfully');
            this.loadBusinesses();
        } catch (error) {
            console.error('Failed to delete business:', error);
            this.showError('Failed to delete business');
        }
    }

    async deleteUser(username) {
        if (!confirm(`Are you sure you want to delete user "${username}"? This action cannot be undone.`)) {
            return;
        }

        try {
            const user = this.usersCache.find(u => u.username === username);
            if (!user) throw new Error('User not found in cache');
            if (!user.user_id) throw new Error('User record missing user_id; cannot delete');
            const userId = encodeURIComponent(user.user_id);
            await this.apiCall(`/admin/users/${userId}`, 'DELETE');
            this.showSuccess('User deleted successfully');
            this.loadUsers();
        } catch (error) {
            console.error('Failed to delete user:', error);
            this.showError(`Failed to delete user: ${error.message}`);
        }
    }

    async deleteSchema(tableName) {
        if (!confirm(`Are you sure you want to delete schema "${tableName}"? This action cannot be undone.`)) {
            return;
        }

        try {
            const businessId = this.currentBusinessId || document.getElementById('businessFilter')?.value;
            if (!businessId) {
                throw new Error('Please select a business first');
            }
            await this.apiCall(`/admin/businesses/${encodeURIComponent(businessId)}/schemas/${encodeURIComponent(tableName)}`, 'DELETE');
            this.showSuccess('Schema deleted successfully');
            this.loadSchemas();
        } catch (error) {
            console.error('Failed to delete schema:', error);
            this.showError(`Failed to delete schema: ${error.message}`);
        }
    }

    // Utility Functions
    async reindexSchemas() {
        if (!this.currentBusinessId) {
            this.showError('Please select a business first');
            return;
        }

        try {
            await this.apiCall(`/admin/system/reindex-schemas?business_id=${encodeURIComponent(this.currentBusinessId)}`, 'POST');
            this.showSuccess('Schemas reindexed successfully');
            this.loadSchemas();
        } catch (error) {
            console.error('Failed to reindex schemas:', error);
            this.showError('Failed to reindex schemas');
        }
    }

    changePage(direction) {
        this.currentPage = Math.max(1, this.currentPage + direction);
        this.loadUsers();
    }

    updatePagination(userCount) {
        document.getElementById('pageInfo').textContent = `Page ${this.currentPage}`;
        document.getElementById('prevPage').disabled = this.currentPage <= 1;
        document.getElementById('nextPage').disabled = userCount < this.pageSize;
    }

    refreshCurrentSection() {
        this.loadSectionData(this.currentSection);
    }

    async saveSettings() {
        const pageSize = parseInt(document.getElementById('defaultPageSize').value);
        const refreshInterval = parseInt(document.getElementById('refreshInterval').value);
        
        this.pageSize = pageSize;
        localStorage.setItem('adminPageSize', pageSize.toString());
        localStorage.setItem('adminRefreshInterval', refreshInterval.toString());
        
        this.showSuccess('Settings saved successfully');
    }

    async exportData() {
        try {
            const [businesses, users] = await Promise.all([
                this.apiCall('/admin/businesses?include_inactive=true'),
                this.apiCall('/admin/users?page_size=1000')
            ]);
            
            const data = { businesses, users, exported_at: new Date().toISOString() };
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `admin-export-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showSuccess('Data exported successfully');
        } catch (error) {
            console.error('Failed to export data:', error);
            this.showError('Failed to export data');
        }
    }

    confirmDatabaseReset() {
        if (confirm('⚠️ WARNING: This will delete ALL data. Type "RESET" to confirm.')) {
            const confirmation = prompt('Type "RESET" to confirm:');
            if (confirmation === 'RESET') {
                this.showError('Database reset functionality not implemented for safety');
            }
        }
    }

    async apiCall(url, method = 'GET', data = null) {
        const options = {
            method,
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            }
        };

        if (data) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(`${API_BASE}${url}`, options);
        
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = `${API_BASE}/login.html`;
                return;
            }
            let errorText = 'Request failed';
            try {
                const errJson = await response.json();
                errorText = errJson.detail || JSON.stringify(errJson);
            } catch (_) {
                try {
                    errorText = await response.text();
                } catch {}
            }
            console.error('API error', { url, status: response.status, error: errorText });
            throw new Error(errorText || 'Request failed');
        }

        return response.json();
    }

    showSuccess(message) {
        this.showMessage(message, 'success');
    }

    showError(message) {
        this.showMessage(message, 'error');
    }

    showMessage(message, type) {
        const existing = document.querySelector('.message');
        if (existing) existing.remove();

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.textContent = message;
        
        const header = document.querySelector('.admin-header');
        header.parentNode.insertBefore(messageDiv, header.nextSibling);
        
        setTimeout(() => messageDiv.remove(), 5000);
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    formatDate(dateString) {
        if (!dateString) return 'N/A';
        try {
            return new Date(dateString).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        } catch {
            return 'Invalid Date';
        }
    }
}

// Global functions for onclick handlers
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        fetch(`${API_BASE}/auth/logout`, { 
            method: 'POST', 
            credentials: 'include' 
        }).finally(() => {
            window.location.href = `${API_BASE}/login.html`;
        });
    }
}

// Function to open the schema manager
function openSchemaManager() {
    window.location.href = './business-schema-manager.html';
}

function showCreateBusinessModal() {
    adminDashboard.showCreateBusinessModal();
}

function showCreateUserModal() {
    adminDashboard.showCreateUserModal();
}

function showCreateSchemaModal() {
    adminDashboard.showCreateSchemaModal();
}

function closeModal() {
    adminDashboard.closeModal();
}

function refreshCurrentSection() {
    adminDashboard.refreshCurrentSection();
}

function loadBusinesses() {
    adminDashboard.loadBusinesses();
}

function loadUsers() {
    adminDashboard.loadUsers();
}

function loadSchemas() {
    adminDashboard.loadSchemas();
}

function changePage(direction) {
    adminDashboard.changePage(direction);
}

function reindexSchemas() {
    adminDashboard.reindexSchemas();
}

function saveSettings() {
    adminDashboard.saveSettings();
}

function exportData() {
    adminDashboard.exportData();
}

function confirmDatabaseReset() {
    adminDashboard.confirmDatabaseReset();
}

// Initialize dashboard when page loads
let adminDashboard;

// Handle modal overlay clicks
document.addEventListener('click', (e) => {
    if (e.target.id === 'modalOverlay') {
        closeModal();
    }
});

// Make adminDashboard globally accessible for HTML onclick handlers
document.addEventListener('DOMContentLoaded', () => {
    adminDashboard = new AdminDashboard();
    window.adminDashboard = adminDashboard;
    console.log('AdminDashboard initialized and attached to window');
});
