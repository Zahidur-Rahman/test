# Utilities Package 

import bcrypt

def hash_password(password: str) -> str:
    """Hash a password for storing in the database using bcrypt."""
    if password is None:
        raise ValueError("Password cannot be None")
    if isinstance(password, str):
        password_bytes = password.encode("utf-8")
    else:
        password_bytes = password
    hashed = bcrypt.hashpw(password_bytes, bcrypt.gensalt())
    return hashed.decode("utf-8")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a stored password against one provided by user using bcrypt."""
    if plain_password is None or hashed_password is None:
        return False
    plain_bytes = plain_password.encode("utf-8") if isinstance(plain_password, str) else plain_password
    hashed_bytes = hashed_password.encode("utf-8") if isinstance(hashed_password, str) else hashed_password
    try:
        return bcrypt.checkpw(plain_bytes, hashed_bytes)
    except ValueError:
        # Invalid hash format
        return False