from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
import logging
import re

logger = logging.getLogger(__name__)

# Initialize services
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

async def get_next_customer_id(business_id) -> str:
    """
    Generate the next customer ID in format CUS-XXXXXX where XXXXXX is a 6-digit auto-incremented number.
    This function is bulletproof and handles all edge cases.
    """
    logger.info(f"[CustomerID] Starting ID generation for business_id: {business_id}")
    
    try:
        # Step 1: Get all existing customer IDs with CUS- prefix for this business
        sql_query = f"""
        SELECT xcus FROM cacus 
        WHERE zid = {business_id} 
        AND xcus IS NOT NULL 
        AND xcus LIKE 'CUS-______'
        ORDER BY xcus
        """
        
        logger.info(f"[CustomerID] Executing query: {sql_query}")
        result = await mcp_client.execute_query(sql_query, str(business_id))
        
        # Step 2: Parse the MCP result carefully
        existing_numbers = []
        
        if isinstance(result, dict):
            if 'error' in result:
                logger.error(f"[CustomerID] Query error: {result['error']}")
                # On error, fall back to count-based approach
                raise Exception(f"Query failed: {result['error']}")
            
            if 'content' in result and result['content']:
                try:
                    import json
                    parsed = json.loads(result['content'][0]['text'])
                    rows = parsed.get('results', [])
                    
                    logger.info(f"[CustomerID] Found {len(rows)} existing customer records")
                    
                    # Step 3: Extract all existing numbers
                    for row in rows:
                        xcus = row.get('xcus', '')
                        if xcus and len(xcus) == 10 and xcus.startswith('CUS-'):
                            try:
                                # Extract the 6-digit number after CUS-
                                number_part = xcus[4:]
                                if number_part.isdigit() and len(number_part) == 6:
                                    existing_numbers.append(int(number_part))
                            except (ValueError, IndexError):
                                logger.warning(f"[CustomerID] Skipping invalid format: {xcus}")
                                continue
                    
                    logger.info(f"[CustomerID] Valid existing numbers: {sorted(existing_numbers)}")
                    
                except Exception as parse_error:
                    logger.error(f"[CustomerID] Error parsing result: {parse_error}")
                    logger.error(f"[CustomerID] Raw content: {result.get('content')}")
                    raise parse_error
        
        # Step 4: Determine next number
        if existing_numbers:
            next_number = max(existing_numbers) + 1
            logger.info(f"[CustomerID] Next number based on max({max(existing_numbers)}): {next_number}")
        else:
            next_number = 1
            logger.info(f"[CustomerID] No existing customers found, starting with: 1")
        
        # Step 5: Generate the ID
        generated_id = f"CUS-{next_number:06d}"
        logger.info(f"[CustomerID] Generated ID: {generated_id}")
        
        # Step 6: Verify uniqueness (double-check)
        verify_query = f"SELECT COUNT(*) as count FROM cacus WHERE zid = {business_id} AND xcus = '{generated_id}'"
        verify_result = await mcp_client.execute_query(verify_query, str(business_id))
        
        if isinstance(verify_result, dict) and 'content' in verify_result:
            try:
                verify_parsed = json.loads(verify_result['content'][0]['text'])
                verify_count = verify_parsed.get('results', [{}])[0].get('count', 0)
                
                if verify_count > 0:
                    logger.error(f"[CustomerID] Generated ID {generated_id} already exists! Falling back to timestamp.")
                    # Emergency fallback
                    import time
                    timestamp_number = int(time.time() * 1000) % 1000000
                    generated_id = f"CUS-{timestamp_number:06d}"
                    logger.warning(f"[CustomerID] Emergency fallback ID: {generated_id}")
            except Exception as verify_error:
                logger.warning(f"[CustomerID] Could not verify uniqueness: {verify_error}")
        
        return generated_id
        
    except Exception as e:
        logger.error(f"[CustomerID] All methods failed: {e}")
        
        # Ultimate fallback - timestamp-based
        import time
        import random
        timestamp = int(time.time() * 1000)
        random_part = random.randint(1, 999)
        fallback_number = (timestamp + random_part) % 1000000
        fallback_id = f"CUS-{fallback_number:06d}"
        
        logger.warning(f"[CustomerID] Using ultimate fallback: {fallback_id}")
        return fallback_id

async def get_customer_schema_context(business_id: str, query: str):
    """
    Get customer table schema context using vector search.
    """
    try:
        # Search for customer-related schemas
        schema_context = await vector_search_service.search_schemas(
            business_id, f"customer table {query}", top_k=2
        )
        return schema_context
    except Exception as e:
        logger.error(f"Error getting customer schema context: {e}")
        return []

def build_customer_sql_prompt(context, conversation_history, schema_context):
    """
    Build SQL generation prompt specifically for customer operations with context awareness.
    """
    schema_text = ""
    customer_table_columns = []
    
    if schema_context:
        for schema in schema_context:
            table_name = schema.get('table_name', 'Unknown')
            if 'customer' in table_name.lower() or 'cacus' in table_name.lower():
                schema_text += f"\nTable: {table_name}\n"
                schema_text += f"Description: {schema.get('schema_description', 'Customer data table')}\n"
                schema_text += "Columns:\n"
                
                for col in schema.get('columns', []):
                    col_name = col.get('name', 'Unknown')
                    col_type = col.get('type', 'Unknown')
                    col_desc = col.get('description', 'No description')
                    schema_text += f"  - {col_name}: {col_type} ({col_desc})\n"
                    customer_table_columns.append(col_name)
                
                # Add relationship info
                if schema.get('relationships'):
                    schema_text += "Relationships:\n"
                    for rel in schema.get('relationships', []):
                        rel_type = rel.get('relationship_type', 'unknown')
                        if rel_type == 'primary_key':
                            schema_text += f"  - PRIMARY KEY: {rel.get('from_column', 'Unknown')}\n"
                        elif rel_type == 'foreign_key':
                            schema_text += f"  - FOREIGN KEY: {rel.get('from_column', 'Unknown')} -> {rel.get('referenced_table', 'Unknown')}.{rel.get('referenced_column', 'Unknown')}\n"
                schema_text += "\n"
    else:
        schema_text = "No customer table schema found."

    # Extract recent data context for reference resolution
    recent_data_context = ""
    if conversation_history:
        # Look for recent customer data in conversation
        for msg in reversed(conversation_history[-4:]):  # Last 4 messages
            role = msg.get('role', '') if isinstance(msg, dict) else getattr(msg, 'role', '')
            content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
            
            if role == 'assistant' and ('Customer ID:' in content or 'CUS-' in content):
                recent_data_context = f"\nRECENT DATA CONTEXT:\nThe system just showed these customers:\n{content[:500]}...\n"
                break

    sql_prompt = f"""You are an expert SQL assistant for PostgreSQL customer operations with contextual awareness.

CUSTOMER TABLE SCHEMA:
{schema_text}

CONVERSATION CONTEXT:
"""
    
    for msg in conversation_history:
        role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
        content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
        sql_prompt += f"{role.upper()}: {content[:100]}{'...' if len(content) > 100 else ''}\n"
    
    sql_prompt += recent_data_context
    
    sql_prompt += f"""
CURRENT REQUEST: {context.message}

CONTEXTUAL REFERENCE HANDLING:
- When user says "these customers", "from these", "who has phone from these" - refer to the RECENT DATA CONTEXT above
- Extract specific customer IDs from recent data when user references "these", "his", "its", "those"
- For filtering queries on recent data, use WHERE xcus IN ('CUS-XXXXX', 'CUS-YYYYY', ...) with actual IDs from context
- Example: If recent data shows CUS-000115, CUS-000114, CUS-000113 and user asks "who has phone from these"
  Generate: SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus IN ('CUS-000115', 'CUS-000114', 'CUS-000113') AND xphone IS NOT NULL

CUSTOMER SQL RULES:
1. For INSERT operations:
   - zid (business_id) = {context.business_id} (ALWAYS required as INTEGER)
   - xcus (customer_id) will be AUTO-GENERATED by the system - NEVER include xcus in INSERT statements
   - xphone should be INTEGER (no quotes) if provided, NULL if missing
   - Use NULL for ANY missing fields, NEVER use empty strings or dummy data
   - Only insert fields that user has provided or NULL for missing ones
   - NO DUMMY VALUES: Use NULL for missing email, phone, organization, customer group

2. For SELECT operations:
   - Always include WHERE zid = {context.business_id}
   - Use ORDER BY xcus DESC for recent customers
   - Use ILIKE for name/text searches: WHERE xorg ILIKE '%search%'
   - For filtering by existing values: WHERE xphone IS NOT NULL (for customers with phone numbers)
   - For filtering by missing values: WHERE xphone IS NULL (for customers without phone numbers)

3. For UPDATE operations:
   - Always include WHERE zid = {context.business_id} AND xcus = 'CUS-XXXXXX'
   - Require specific customer identification
   - Only update fields that user wants to change

4. For DELETE operations:
   - Always include WHERE zid = {context.business_id} AND xcus = 'CUS-XXXXXX'
   - Require explicit customer identification
   - IMPORTANT: Check for foreign key dependencies before deletion
   - Use CASCADE deletion or delete dependent records first

EXAMPLES:
- INSERT with all fields: INSERT INTO cacus (zid, xemail, xphone, xgcus, xorg) VALUES ({context.business_id}, 'john@example.com', 123456789, 'VIP', 'TechCorp')
- INSERT with missing fields: INSERT INTO cacus (zid, xemail, xphone, xgcus, xorg) VALUES ({context.business_id}, 'john@example.com', NULL, NULL, 'TechCorp')
- INSERT with only email: INSERT INTO cacus (zid, xemail, xphone, xgcus, xorg) VALUES ({context.business_id}, 'john@example.com', NULL, NULL, NULL)
- SELECT all: SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 5
- SELECT with phone: SELECT * FROM cacus WHERE zid = {context.business_id} AND xphone IS NOT NULL ORDER BY xcus DESC
- SELECT without phone: SELECT * FROM cacus WHERE zid = {context.business_id} AND xphone IS NULL ORDER BY xcus DESC
- SELECT contextual with phone: SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus IN ('CUS-000115', 'CUS-000114', 'CUS-000113') AND xphone IS NOT NULL ORDER BY xcus DESC
- UPDATE: UPDATE cacus SET xemail = 'new@email.com' WHERE zid = {context.business_id} AND xcus = 'CUS-000001'
- DELETE: DELETE FROM cacus WHERE zid = {context.business_id} AND xcus = 'CUS-000001'

CRITICAL RULES:
- Always use zid as INTEGER value in SQL, never quoted as string
- xphone is INTEGER type - use actual numbers (123456789) or NULL for missing values
- NEVER include xcus in INSERT statements - it will be auto-generated
- The system will automatically add xcus after SQL generation
- Use NULL for missing fields regardless of type - this enables proper database filtering

OUTPUT: Generate ONLY the SQL query, no explanations or markdown.
"""
    
    return sql_prompt

def build_customer_system_prompt(context, conversation_history, schema_context):
    """
    Build system prompt for customer conversations.
    """
    schema_text = ""
    if schema_context:
        for schema in schema_context:
            table_name = schema.get('table_name', 'Unknown')
            if 'customer' in table_name.lower() or 'cacus' in table_name.lower():
                schema_text += f"\nCustomer Table: {table_name}\n"
                schema_text += "Available Fields:\n"
                for col in schema.get('columns', []):
                    col_name = col.get('name', 'Unknown')
                    col_desc = col.get('description', 'No description')
                    schema_text += f"  - {col_name}: {col_desc}\n"
    else:
        schema_text = "Customer table schema not available."

    system_prompt = f"""You are a specialized customer management assistant.

CUSTOMER DATA STRUCTURE:
{schema_text}

CONVERSATION HISTORY:
"""
    
    for msg in conversation_history:
        role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
        content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
        system_prompt += f"{role.upper()}: {content}\n"
    
    system_prompt += f"""
CURRENT REQUEST: {context.message}

CUSTOMER MANAGEMENT GUIDELINES:
1. For NEW CUSTOMERS:
   - Accept ANY customer information provided by user
   - DO NOT require all fields - user can add partial information
   - Use empty strings '' for any missing fields, NEVER dummy data
   - Customer ID (xcus) is MANDATORY and will be auto-generated as CUS-XXXXXX format
   - Business ID (zid) is automatically set to {context.business_id}
   - If user provides only email, create customer with just email and empty strings for other fields
   - The system automatically handles xcus field generation - users don't need to provide it

2. For CUSTOMER SEARCH:
   - Search by name, email, phone, or organization
   - Show relevant customer details clearly
   - Offer to refine search if multiple matches

3. For CUSTOMER UPDATES:
   - First identify the specific customer
   - Confirm changes before applying
   - Show what will be changed
   - Only update fields user wants to change

4. For CUSTOMER DELETION:
   - Require explicit customer identification
   - Warn about permanent deletion
   - Require confirmation

RESPONSE STYLE:
- Be friendly and professional
- Accept partial customer information (don't insist on all fields)
- Use empty strings for missing data, never dummy values
- Confirm actions before execution
- Provide clear status updates
- Handle errors gracefully
"""
    
    return system_prompt

def clean_sql_from_llm(sql_response):
    """
    Clean SQL response from LLM, removing markdown and prefixes.
    """
    sql_query = sql_response.strip()
    
    # Remove markdown code blocks
    if sql_query.startswith('```'):
        lines = sql_query.split('\n')
        if len(lines) > 1:
            sql_lines = []
            for line in lines[1:]:
                if line.strip() == '```':
                    break
                sql_lines.append(line)
            sql_query = '\n'.join(sql_lines).strip()
    
    # Remove common prefixes
    lines = sql_query.split('\n')
    if lines:
        first_line = lines[0].strip()
        prefixes_to_remove = ['sql query:', 'sql:', 'query:', 'answer:']
        for prefix in prefixes_to_remove:
            if first_line.lower().startswith(prefix):
                first_line = first_line[len(prefix):].strip()
                break
        lines[0] = first_line
        sql_query = '\n'.join(lines).strip()
    
    # Remove trailing semicolon
    sql_query = sql_query.rstrip(';').strip()
    
    return sql_query

def extract_customer_fields_from_message(message: str) -> dict:
    """
    Extract customer field information from natural language message.
    """
    fields = {}
    message_lower = message.lower()
    
    # Email extraction
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    email_match = re.search(email_pattern, message)
    if email_match:
        fields['xemail'] = email_match.group()
    
    # Phone extraction (basic patterns)
    phone_patterns = [
        r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',  # 123-456-7890 or 123.456.7890 or 1234567890
        r'\b\(\d{3}\)\s?\d{3}[-.]?\d{4}\b',  # (123) 456-7890
        r'\b\+\d{1,3}[-.]?\d{3,14}\b'  # International format
    ]
    
    for pattern in phone_patterns:
        phone_match = re.search(pattern, message)
        if phone_match:
            fields['xphone'] = phone_match.group()
            break
    
    # Organization extraction (look for "organization:", "company:", "org:")
    org_patterns = [
        r'(?:organization|company|org):\s*([^\n,]+)',
        r'(?:works at|from)\s+([A-Za-z0-9\s&.-]+)',
        r'(?:organization|company)\s+(?:is\s+)?([A-Za-z0-9\s&.-]+)'
    ]
    
    for pattern in org_patterns:
        org_match = re.search(pattern, message_lower)
        if org_match:
            fields['xorg'] = org_match.group(1).strip()
            break
    
    # Customer group extraction
    group_patterns = [
        r'(?:customer group|group):\s*([^\n,]+)',
        r'(?:vip|premium|standard|basic|gold|silver|bronze)',
        r'(?:group|tier)\s+(?:is\s+)?([A-Za-z0-9\s]+)'
    ]
    
    for pattern in group_patterns:
        group_match = re.search(pattern, message_lower)
        if group_match:
            fields['xgcus'] = group_match.group(1).strip() if group_match.groups() else group_match.group()
            break
    
    return fields

def format_customer_result(result_data):
    """
    Format customer query results for user-friendly display.
    Dynamically shows all available columns from the database.
    """
    if not result_data:
        return "No customer data found."
    
    if isinstance(result_data, list) and len(result_data) == 1:
        # Single customer - show all available fields
        customer = result_data[0]
        formatted = "Customer Information:\n"
        
        # Define preferred order for common fields
        preferred_order = ['xcus', 'xemail', 'xphone', 'xorg', 'xgcus']
        field_labels = {
            'xcus': 'Customer ID',
            'xemail': 'Email',
            'xphone': 'Phone', 
            'xorg': 'Organization',
            'xgcus': 'Customer Group',
            'zid': 'Business ID'
        }
        
        # Show preferred fields first
        for field in preferred_order:
            if field in customer:
                value = customer.get(field, '')
                if value:  # Only show non-empty values
                    label = field_labels.get(field, field.title())
                    formatted += f"• {label}: {value}\n"
        
        # Show any additional fields not in preferred order
        for field, value in customer.items():
            if field not in preferred_order and field != 'zid' and value:
                label = field_labels.get(field, field.replace('_', ' ').title())
                formatted += f"• {label}: {value}\n"
        
        return formatted
    
    elif isinstance(result_data, list) and len(result_data) > 1:
        # Multiple customers - show ALL available fields dynamically
        formatted = f"Found {len(result_data)} customers:\n\n"
        
        for i, customer in enumerate(result_data[:10], 1):  # Limit to 10 results
            # Show all non-empty fields for each customer
            customer_info = []
            
            # Process all fields in the customer record
            for field, value in customer.items():
                if value and field != 'zid':  # Skip empty values and business ID
                    # Get readable label for field
                    field_labels = {
                        'xcus': 'Customer ID',
                        'xemail': 'Email',
                        'xphone': 'Phone', 
                        'xorg': 'Organization',
                        'xgcus': 'Customer Group'
                    }
                    label = field_labels.get(field, field.replace('_', ' ').title())
                    customer_info.append(f"{label}: {value}")
            
            # Display customer with all available information
            if customer_info:
                formatted += f"{i}. {' | '.join(customer_info)}\n"
            else:
                formatted += f"{i}. Customer record (no display data)\n"
        
        if len(result_data) > 10:
            formatted += f"\n... and {len(result_data) - 10} more customers."
        
        return formatted
    
    else:
        return str(result_data)
