// Schema Builder JavaScript
const API_BASE = (typeof window !== 'undefined' && window.ADMIN_API_BASE) ? window.ADMIN_API_BASE.replace(/\/$/, '') : '';

class SchemaBuilder {
    constructor() {
        this.currentBusinessId = null;
        this.columnCounter = 0;
        this.relationshipCounter = 0;
        this.columns = [];
        this.relationships = [];
        this.init();
    }

    async init() {
        await this.loadBusinesses();
        this.setupEventListeners();
        
        // Get business ID from URL params if available
        const urlParams = new URLSearchParams(window.location.search);
        const businessId = urlParams.get('business_id');
        if (businessId) {
            document.getElementById('businessId').value = businessId;
            this.currentBusinessId = businessId;
        }
    }

    setupEventListeners() {
        document.getElementById('businessId').addEventListener('change', (e) => {
            this.currentBusinessId = e.target.value;
        });
    }

    async loadBusinesses() {
        try {
            const response = await this.apiCall('/admin/businesses');
            const businesses = response?.businesses || [];
            const select = document.getElementById('businessId');
            
            businesses.forEach(business => {
                const option = document.createElement('option');
                option.value = business.business_id;
                option.textContent = business.business_id;
                select.appendChild(option);
            });
        } catch (error) {
            console.error('Failed to load businesses:', error);
            this.showError('Failed to load businesses');
        }
    }

    toggleSchemaMode() {
        const mode = document.getElementById('schemaMode').value;
        const databaseMode = document.getElementById('databaseMode');
        const manualMode = document.getElementById('manualMode');
        
        if (mode === 'introspect') {
            databaseMode.style.display = 'block';
            manualMode.style.display = 'none';
        } else {
            databaseMode.style.display = 'none';
            manualMode.style.display = 'block';
        }
    }

    async testConnection() {
        if (!this.currentBusinessId) {
            this.showError('Please select a business first');
            return;
        }

        const statusEl = document.getElementById('connectionStatus');
        
        try {
            statusEl.textContent = 'Testing...';
            statusEl.className = 'connection-status testing';
            
            const response = await this.apiCall(`/admin/businesses/${this.currentBusinessId}/test-connection`, 'POST');
            
            if (response.success) {
                statusEl.textContent = '✅ Connected';
                statusEl.className = 'connection-status connected';
                this.showSuccess('Database connection successful');
            } else {
                statusEl.textContent = '❌ Connection Failed';
                statusEl.className = 'connection-status failed';
                this.showError('Database connection failed');
            }
        } catch (error) {
            statusEl.textContent = '❌ Connection Error';
            statusEl.className = 'connection-status failed';
            this.showError(`Connection error: ${error.message}`);
        }
    }

    async loadDatabaseTables() {
        if (!this.currentBusinessId) {
            this.showError('Please select a business first');
            return;
        }

        try {
            const response = await this.apiCall(`/admin/businesses/${this.currentBusinessId}/tables`);
            const tables = response.tables || [];
            const select = document.getElementById('tableName');
            
            select.innerHTML = '<option value="">Select Table</option>';
            
            tables.forEach(table => {
                const option = document.createElement('option');
                option.value = table.table_name;
                option.textContent = `${table.table_name}${table.description ? ' - ' + table.description : ''}`;
                select.appendChild(option);
            });
            
            if (tables.length === 0) {
                this.showError('No tables found in the database');
            } else {
                this.showSuccess(`Loaded ${tables.length} tables from database`);
            }
        } catch (error) {
            this.showError(`Failed to load database tables: ${error.message}`);
        }
    }

    async loadTableDetails() {
        const tableName = document.getElementById('tableName').value;
        if (!tableName || !this.currentBusinessId) return;

        try {
            const response = await this.apiCall(`/admin/businesses/${this.currentBusinessId}/tables/${tableName}`);
            
            // Clear existing columns
            this.columns = [];
            this.columnCounter = 0;
            document.getElementById('columnsContainer').innerHTML = '';
            
            // Add columns from database
            if (response.columns) {
                response.columns.forEach((column, index) => {
                    this.addColumn(column, index + 1);
                });
            }
            
            // Set description if available
            if (response.description) {
                document.getElementById('schemaDescription').value = response.description;
            }
            
            this.updatePreview();
        } catch (error) {
            this.showError(`Failed to load table details: ${error.message}`);
        }
    }

    addColumn(columnData = null, position = null) {
        const template = document.getElementById('columnTemplate');
        const clone = template.content.cloneNode(true);
        
        const columnItem = clone.querySelector('.column-item');
        const actualPosition = position || (this.columnCounter + 1);
        
        columnItem.dataset.position = actualPosition;
        clone.querySelector('.column-position').textContent = `#${actualPosition}`;
        
        if (columnData) {
            clone.querySelector('.column-name').value = columnData.name || '';
            clone.querySelector('.column-type').value = columnData.type || '';
            clone.querySelector('.column-max-length').value = columnData.max_length || '';
            clone.querySelector('.column-default').value = columnData.default || '';
            clone.querySelector('.column-nullable').checked = columnData.nullable !== false;
            clone.querySelector('.column-business-meaning').value = columnData.business_meaning || '';
            clone.querySelector('.column-description').value = columnData.description || '';
            clone.querySelector('.column-checkbox').checked = true;
            columnItem.classList.add('selected');
        }
        
        document.getElementById('columnsContainer').appendChild(clone);
        this.columnCounter = Math.max(this.columnCounter, actualPosition);
        this.updateColumnCount();
        this.updatePreview();
    }

    removeColumn(button) {
        const columnItem = button.closest('.column-item');
        columnItem.classList.add('removing');
        setTimeout(() => {
            columnItem.remove();
            this.updateColumnPositions();
            this.updateColumnCount();
            this.updatePreview();
        }, 300);
    }

    toggleColumn(checkbox) {
        const columnItem = checkbox.closest('.column-item');
        if (checkbox.checked) {
            columnItem.classList.add('selected');
        } else {
            columnItem.classList.remove('selected');
        }
        this.updatePreview();
    }

    toggleColumnDetails(button) {
        const columnItem = button.closest('.column-item');
        const details = columnItem.querySelector('.column-details');
        const isVisible = details.style.display !== 'none';
        
        details.style.display = isVisible ? 'none' : 'block';
        button.textContent = isVisible ? '⚙️' : '🔧';
    }

    updateColumnPositions() {
        const columnItems = document.querySelectorAll('.column-item');
        columnItems.forEach((item, index) => {
            const position = index + 1;
            item.dataset.position = position;
            item.querySelector('.column-position').textContent = `#${position}`;
        });
        this.columnCounter = columnItems.length;
    }

    updateColumnCount() {
        const count = document.querySelectorAll('.column-item').length;
        document.getElementById('columnCount').textContent = count;
    }

    selectAllColumns() {
        document.querySelectorAll('.column-checkbox').forEach(checkbox => {
            checkbox.checked = true;
            checkbox.closest('.column-item').classList.add('selected');
        });
        this.updatePreview();
    }

    deselectAllColumns() {
        document.querySelectorAll('.column-checkbox').forEach(checkbox => {
            checkbox.checked = false;
            checkbox.closest('.column-item').classList.remove('selected');
        });
        this.updatePreview();
    }

    addRelationship() {
        const template = document.getElementById('relationshipTemplate');
        const clone = template.content.cloneNode(true);
        
        this.relationshipCounter++;
        clone.querySelector('.relationship-number').textContent = `#${this.relationshipCounter}`;
        
        document.getElementById('relationshipsContainer').appendChild(clone);
        this.updateRelationshipCount();
        this.updatePreview();
    }

    removeRelationship(button) {
        const relationshipItem = button.closest('.relationship-item');
        relationshipItem.classList.add('removing');
        setTimeout(() => {
            relationshipItem.remove();
            this.updateRelationshipPositions();
            this.updateRelationshipCount();
            this.updatePreview();
        }, 300);
    }

    updateRelationshipPositions() {
        const relationshipItems = document.querySelectorAll('.relationship-item');
        relationshipItems.forEach((item, index) => {
            item.querySelector('.relationship-number').textContent = `#${index + 1}`;
        });
        this.relationshipCounter = relationshipItems.length;
    }

    updateRelationshipCount() {
        const count = document.querySelectorAll('.relationship-item').length;
        document.getElementById('relationshipCount').textContent = count;
    }

    updatePreview() {
        this.updateColumnsPreview();
        this.updateRelationshipsPreview();
    }

    updateColumnsPreview() {
        const selectedColumns = document.querySelectorAll('.column-item.selected');
        const preview = document.getElementById('columnsPreview');
        
        if (selectedColumns.length === 0) {
            preview.innerHTML = '<p class="text-muted">No columns selected</p>';
            return;
        }
        
        let html = '';
        selectedColumns.forEach(columnItem => {
            const name = columnItem.querySelector('.column-name').value || 'Unnamed';
            const type = columnItem.querySelector('.column-type').value || 'Unknown';
            const nullable = columnItem.querySelector('.column-nullable').checked;
            const businessMeaning = columnItem.querySelector('.column-business-meaning').value;
            
            html += `
                <div class="preview-item">
                    <div class="preview-item-name">${name} (${type})</div>
                    <div class="preview-item-details">
                        ${nullable ? 'Nullable' : 'Not Null'}
                        ${businessMeaning ? ` • ${businessMeaning}` : ''}
                    </div>
                </div>
            `;
        });
        
        preview.innerHTML = html;
    }

    updateRelationshipsPreview() {
        const relationships = document.querySelectorAll('.relationship-item');
        const preview = document.getElementById('relationshipsPreview');
        
        if (relationships.length === 0) {
            preview.innerHTML = '<p class="text-muted">No relationships defined</p>';
            return;
        }
        
        let html = '';
        relationships.forEach(relationshipItem => {
            const type = relationshipItem.querySelector('.relationship-type').value || 'Unknown';
            const table = relationshipItem.querySelector('.referenced-table').value || 'Unknown';
            const column = relationshipItem.querySelector('.referenced-column').value || 'Unknown';
            const description = relationshipItem.querySelector('.relationship-description').value;
            
            html += `
                <div class="preview-item">
                    <div class="preview-item-name">${type} → ${table}.${column}</div>
                    <div class="preview-item-details">
                        ${description || 'No description'}
                    </div>
                </div>
            `;
        });
        
        preview.innerHTML = html;
    }

    async saveSchema() {
        if (!this.validateForm()) return;
        
        const mode = document.getElementById('schemaMode').value;
        const businessId = this.currentBusinessId;
        const description = document.getElementById('schemaDescription').value;
        
        let tableName;
        if (mode === 'introspect') {
            tableName = document.getElementById('tableName').value;
        } else {
            tableName = document.getElementById('tableNameManual').value;
        }
        
        // Collect selected columns
        const selectedColumns = [];
        document.querySelectorAll('.column-item.selected').forEach(columnItem => {
            const column = {
                name: columnItem.querySelector('.column-name').value,
                type: columnItem.querySelector('.column-type').value,
                max_length: parseInt(columnItem.querySelector('.column-max-length').value) || null,
                nullable: columnItem.querySelector('.column-nullable').checked,
                default: columnItem.querySelector('.column-default').value || null,
                position: parseInt(columnItem.dataset.position),
                business_meaning: columnItem.querySelector('.column-business-meaning').value || null,
                description: columnItem.querySelector('.column-description').value || null
            };
            selectedColumns.push(column);
        });
        
        // Collect relationships
        const relationships = [];
        document.querySelectorAll('.relationship-item').forEach(relationshipItem => {
            const relationship = {
                relationship_type: relationshipItem.querySelector('.relationship-type').value,
                referenced_table: relationshipItem.querySelector('.referenced-table').value,
                referenced_column: relationshipItem.querySelector('.referenced-column').value,
                description: relationshipItem.querySelector('.relationship-description').value || null
            };
            if (relationship.relationship_type && relationship.referenced_table && relationship.referenced_column) {
                relationships.push(relationship);
            }
        });
        
        const schemaData = {
            table_name: tableName,
            schema_description: description,
            columns: selectedColumns,
            relationships: relationships
        };
        
        try {
            const response = await this.apiCall(`/admin/businesses/${businessId}/schemas`, 'POST', schemaData);
            this.showSuccess('Schema saved successfully!');
            
            // Optionally redirect back to admin
            setTimeout(() => {
                window.location.href = `admin.html?business_id=${businessId}#schemas`;
            }, 2000);
        } catch (error) {
            this.showError(`Failed to save schema: ${error.message}`);
        }
    }

    validateForm() {
        const businessId = this.currentBusinessId;
        const description = document.getElementById('schemaDescription').value;
        const mode = document.getElementById('schemaMode').value;
        
        if (!businessId) {
            this.showError('Please select a business');
            return false;
        }
        
        if (!description.trim()) {
            this.showError('Please enter a schema description');
            return false;
        }
        
        let tableName;
        if (mode === 'introspect') {
            tableName = document.getElementById('tableName').value;
        } else {
            tableName = document.getElementById('tableNameManual').value;
        }
        
        if (!tableName) {
            this.showError('Please enter or select a table name');
            return false;
        }
        
        const selectedColumns = document.querySelectorAll('.column-item.selected');
        if (selectedColumns.length === 0) {
            this.showError('Please select at least one column');
            return false;
        }
        
        // Validate selected columns have names and types
        for (let columnItem of selectedColumns) {
            const name = columnItem.querySelector('.column-name').value;
            const type = columnItem.querySelector('.column-type').value;
            
            if (!name || !type) {
                this.showError('All selected columns must have a name and type');
                return false;
            }
        }
        
        return true;
    }

    resetForm() {
        if (confirm('Are you sure you want to reset the form? All data will be lost.')) {
            document.getElementById('businessId').value = '';
            document.getElementById('schemaMode').value = 'introspect';
            document.getElementById('tableName').value = '';
            document.getElementById('tableNameManual').value = '';
            document.getElementById('schemaDescription').value = '';
            document.getElementById('columnsContainer').innerHTML = '';
            document.getElementById('relationshipsContainer').innerHTML = '';
            
            this.currentBusinessId = null;
            this.columnCounter = 0;
            this.relationshipCounter = 0;
            
            this.updateColumnCount();
            this.updateRelationshipCount();
            this.updatePreview();
            this.toggleSchemaMode();
        }
    }

    async apiCall(url, method = 'GET', data = null) {
        const options = {
            method,
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            }
        };

        if (data) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(`${API_BASE}${url}`, options);
        
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = `${API_BASE}/login.html`;
                return;
            }
            let errorText = 'Request failed';
            try {
                const errJson = await response.json();
                errorText = errJson.detail || JSON.stringify(errJson);
            } catch (_) {
                try {
                    errorText = await response.text();
                } catch {}
            }
            throw new Error(errorText || 'Request failed');
        }

        return response.json();
    }

    showSuccess(message) {
        this.showMessage(message, 'success');
    }

    showError(message) {
        this.showMessage(message, 'error');
    }

    showMessage(message, type) {
        const existing = document.querySelector('.message');
        if (existing) existing.remove();

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.textContent = message;
        
        const content = document.querySelector('.schema-content');
        content.insertBefore(messageDiv, content.firstChild);
        
        setTimeout(() => messageDiv.remove(), 5000);
    }
}

// Global functions
function goBack() {
    window.location.href = 'admin.html';
}

function toggleSchemaMode() {
    schemaBuilder.toggleSchemaMode();
}

function testConnection() {
    schemaBuilder.testConnection();
}

function loadDatabaseTables() {
    schemaBuilder.loadDatabaseTables();
}

function loadTableDetails() {
    schemaBuilder.loadTableDetails();
}

function addColumn() {
    schemaBuilder.addColumn();
}

function removeColumn(button) {
    schemaBuilder.removeColumn(button);
}

function toggleColumn(checkbox) {
    schemaBuilder.toggleColumn(checkbox);
}

function toggleColumnDetails(button) {
    schemaBuilder.toggleColumnDetails(button);
}

function selectAllColumns() {
    schemaBuilder.selectAllColumns();
}

function deselectAllColumns() {
    schemaBuilder.deselectAllColumns();
}

function addRelationship() {
    schemaBuilder.addRelationship();
}

function removeRelationship(button) {
    schemaBuilder.removeRelationship(button);
}

function updatePreview() {
    schemaBuilder.updatePreview();
}

function saveSchema() {
    schemaBuilder.saveSchema();
}

function resetForm() {
    schemaBuilder.resetForm();
}

// Initialize when page loads
let schemaBuilder;
document.addEventListener('DOMContentLoaded', () => {
    schemaBuilder = new SchemaBuilder();
});
