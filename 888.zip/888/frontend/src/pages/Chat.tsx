import { useEffect, useRef, useState } from 'react'
import { apiBaseUrl } from '../utils/api'

export default function Chat() {
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<string[]>([])
  const sessionIdRef = useRef<string | null>(null)

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessages(prev => [...prev, `You: ${input}` , 'Assistant: '])

    const res = await fetch(`${apiBaseUrl()}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ message: input, session_id: sessionIdRef.current || undefined })
    })

    const reader = res.body?.getReader()
    const decoder = new TextDecoder()
    if (!reader) return

    let assistantText = 'Assistant: '
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      const chunk = decoder.decode(value)
      // session id marker
      const match = chunk.match(/\[\[SESSION_ID\]\](.*?)\[\[\/SESSION_ID\]\]/)
      if (match) {
        sessionIdRef.current = match[1]
      }
      assistantText += chunk.replace(/\[\[SESSION_ID\]\].*?\[\[\/SESSION_ID\]\]/, '')
      setMessages(prev => [...prev.slice(0, -1), assistantText])
    }
  }

  useEffect(() => {
    // initialize first assistant message placeholder to stream into
    setMessages(['Assistant: '])
  }, [])

  return (
    <div className="min-h-screen p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-semibold mb-4">Chat</h1>
      <div className="border rounded p-4 mb-4 h-96 overflow-auto bg-white">
        {messages.map((m, i) => (
          <div key={i} className="whitespace-pre-wrap text-sm mb-2">{m}</div>
        ))}
      </div>
      <form onSubmit={sendMessage} className="flex gap-2">
        <input className="flex-1 border rounded px-3 py-2" value={input} onChange={e=>setInput(e.target.value)} placeholder="Type a message" />
        <button className="bg-blue-600 text-white px-4 rounded">Send</button>
      </form>
    </div>
  )
}
