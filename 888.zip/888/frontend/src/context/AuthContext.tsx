import React, { createContext, useContext, useEffect, useState } from 'react'
import { apiBaseUrl, apiFetch } from '../utils/api'

type User = { username: string; role: 'user' | 'admin'; business_id?: string }

type LoginInput = { username: string; password: string; business_id?: string }

type Ctx = {
  user: User | null
  loading: boolean
  error: string | null
  login: (input: LoginInput) => Promise<void>
  logout: () => Promise<void>
}

const AuthCtx = createContext<Ctx | null>(null)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    (async () => {
      try {
        const me = await apiFetch('/auth/me')
        setUser(me)
      } catch {
        setUser(null)
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  const login = async (input: LoginInput) => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`${apiBaseUrl()}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(input)
      })
      if (!res.ok) throw new Error('Login failed')
      const data = await res.json()
      // Backend returns top-level fields per LoginResponse
      setUser({ username: data.username, role: data.role, business_id: data.business_id })
      // route by role
      if (data.role === 'admin') window.location.href = '/admin'
      else window.location.href = '/chat'
    } catch (e: any) {
      setError(e.message || 'Login failed')
    } finally {
      setLoading(false)
    }
  }

  const logout = async () => {
    await apiFetch('/auth/logout', { method: 'POST' })
    setUser(null)
    window.location.href = '/login'
  }

  return (
    <AuthCtx.Provider value={{ user, loading, error, login, logout }}>
      {children}
    </AuthCtx.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthCtx)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
