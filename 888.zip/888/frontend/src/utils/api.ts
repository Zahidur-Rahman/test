export function apiBaseUrl() {
  return (import.meta as any).env?.VITE_API_BASE_URL || ''
}

export async function apiFetch(path: string, init?: RequestInit) {
  const res = await fetch(`${apiBaseUrl()}${path}`, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) },
    ...init,
  })
  if (!res.ok) throw new Error(await safeText(res) || `Request failed: ${res.status}`)
  const ct = res.headers.get('content-type') || ''
  if (ct.includes('application/json')) return res.json()
  return res.text()
}

async function safeText(res: Response) {
  try { return await res.text() } catch { return null }
}
