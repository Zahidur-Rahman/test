import re
import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

def summarize_conversation_history(conversation_history: List, max_messages: int = 6) -> List:
    """
    Summarize conversation history by keeping recent messages and summarizing older ones.
    """
    if not conversation_history or len(conversation_history) <= max_messages:
        return conversation_history
    
    # Keep the most recent messages
    recent_messages = conversation_history[-max_messages:]
    
    # Summarize older messages into a system message
    older_messages = conversation_history[:-max_messages]
    if older_messages:
        summary = create_conversation_summary(older_messages)
        summary_message = {
            'role': 'system',
            'content': f"Previous conversation summary: {summary}"
        }
        return [summary_message] + recent_messages
    
    return recent_messages

def create_conversation_summary(messages: List) -> str:
    """
    Create a concise summary of conversation messages.
    """
    if not messages:
        return "No previous conversation."
    
    # Extract key information from messages
    summary_parts = []
    for msg in messages:
        # Handle both ChatMessage objects and dictionaries
        if hasattr(msg, 'role') and hasattr(msg, 'content'):
            # ChatMessage object
            role = getattr(msg, 'role', 'unknown')
            content = getattr(msg, 'content', '')
        elif isinstance(msg, dict):
            # Dictionary
            role = msg.get('role', 'unknown')
            content = msg.get('content', '')
        else:
            # Fallback
            role = 'unknown'
            content = str(msg)
        
        # Only include user and assistant messages in summary
        if role in ['user', 'assistant']:
            # Truncate long content
            if len(content) > 100:
                content = content[:100] + "..."
            summary_parts.append(f"{role}: {content}")
    
    return "; ".join(summary_parts[-5:])  # Keep last 5 interactions

def optimize_schema_context(schema_context: List[Dict], query_intent: str = None) -> List[Dict]:
    """
    Optimize schema context by reducing detail and focusing on relevant information.
    """
    if not schema_context:
        return []
    
    optimized_schemas = []
    for schema in schema_context:
        optimized_schema = {
            'table_name': schema.get('table_name', 'Unknown'),
            'schema_description': schema.get('schema_description', 'No description')[:100],  # Truncate description
            'columns': []
        }
        
        # Limit columns and truncate descriptions
        columns = schema.get('columns', [])
        for col in columns[:8]:  # Limit to 8 columns
            optimized_col = {
                'name': col.get('name', 'Unknown'),
                'type': col.get('type', 'Unknown'),
                'description': col.get('description', '')[:100] if col.get('description') else ''  # Truncate descriptions
            }
            optimized_schema['columns'].append(optimized_col)
        
        optimized_schemas.append(optimized_schema)
    
    return optimized_schemas

def should_use_llm_formatting(response: str, response_type: str, response_info: Dict, settings=None) -> bool:
    """
    Determine if LLM formatting would add value to the response.
    """
    if not response or response_type == "customer_data":
        return False
    
    # Get configuration
    min_length = getattr(settings, 'LLM_FORMATTING_MIN_LENGTH', 200) if settings else 200
    max_length = getattr(settings, 'LLM_FORMATTING_MAX_LENGTH', 2000) if settings else 2000
    
    # Check length constraints
    if len(response) < min_length:
        return False
    
    if len(response) > max_length:
        return True
    
    # Check response type
    if response_type in ["db_result", "error"]:
        return False
    
    # Check if response has complex structure that could benefit from formatting
    if response_info.get('has_data', False) and response_info.get('record_count', 0) > 3:
        return True
    
    if response_info.get('action_performed', False):
        return True
    
    return False

def create_llm_formatting_prompt(response: str, response_type: str, response_info: Dict) -> str:
    """
    Create a prompt for the LLM to format the response beautifully.
    """
    base_prompt = f"""
Please format the following response to be more user-friendly and readable. 
Make it concise, well-structured, and easy to understand.

Response type: {response_type}
Response length: {len(response)} characters
Has data: {response_info.get('has_data', False)}
Record count: {response_info.get('record_count', 0)}
Action performed: {response_info.get('action_performed', False)}

Original response:
{response}

Please provide a beautifully formatted version that is:
1. Clear and concise
2. Well-structured with proper formatting
3. User-friendly and professional
4. Maintains all important information
5. Uses appropriate formatting (bold, lists, etc.) where helpful

Formatted response:
"""
    return base_prompt

def smart_format_response(response: str, response_type: str = "general", llm_service=None, settings=None) -> str:
    """
    Intelligently format and summarize responses based on type and content.
    Uses hybrid approach: rule-based for efficiency, LLM for beautiful formatting when needed.
    """
    if not response:
        return response
    
    # Extract key information
    response_info = extract_key_information(response)
    
    # For database results, use existing formatting first
    if response_type == "db_result":
        formatted_response = response  # Already formatted by existing functions
    elif response_type == "customer_data":
        # For customer data, return as-is without any processing
        formatted_response = response
        print(f"DEBUG: Customer data response length: {len(response)}")
        print(f"DEBUG: Customer data response preview: {response[:200]}...")
    else:
        # For general responses, apply rule-based summarization
        if len(response) > 500:
            formatted_response = summarize_long_response(response)
        else:
            formatted_response = response
    
    # Determine if LLM formatting would add value
    if llm_service and should_use_llm_formatting(formatted_response, response_type, response_info, settings):
        try:
            # Use LLM for beautiful formatting
            formatting_prompt = create_llm_formatting_prompt(formatted_response, response_type, response_info)
            llm_response = llm_service.chat([{"role": "user", "content": formatting_prompt}])
            
            # Clean up LLM response
            if llm_response and len(llm_response.strip()) > 0:
                return llm_response.strip()
            else:
                return formatted_response  # Fallback to rule-based
        except Exception as e:
            # If LLM formatting fails, fallback to rule-based
            print(f"LLM formatting failed: {e}")
            return formatted_response
    
    return formatted_response

def summarize_long_response(response: str) -> str:
    """
    Summarize long responses while preserving key information.
    """
    # Split into sentences
    sentences = re.split(r'[.!?]+', response)
    sentences = [s.strip() for s in sentences if s.strip()]
    
    if len(sentences) <= 3:
        return response
    
    # Keep first sentence (usually the main point)
    # Keep last sentence (usually conclusion)
    # Keep sentences with key words
    key_words = ['error', 'success', 'found', 'updated', 'deleted', 'added', 'important', 'note']
    
    important_sentences = []
    important_sentences.append(sentences[0])  # First sentence
    
    # Find sentences with key words
    for sentence in sentences[1:-1]:
        if any(word in sentence.lower() for word in key_words):
            important_sentences.append(sentence)
    
    important_sentences.append(sentences[-1])  # Last sentence
    
    # If we have too many important sentences, take the most relevant ones
    if len(important_sentences) > 4:
        important_sentences = important_sentences[:2] + important_sentences[-2:]
    
    return '. '.join(important_sentences) + '.'

def extract_key_information(response: str) -> Dict[str, Any]:
    """
    Extract key information from a response for formatting decisions.
    """
    response_lower = response.lower()
    
    info = {
        'type': 'general',
        'has_data': False,
        'has_error': False,
        'action_performed': False,
        'record_count': 0
    }
    
    # Check for database results
    if 'table' in response_lower or 'record' in response_lower or 'found' in response_lower:
        info['type'] = 'db_result'
        info['has_data'] = True
        
        # Count records
        record_matches = re.findall(r'found (\d+)', response_lower)
        if record_matches:
            info['record_count'] = int(record_matches[0])
    
    # Check for errors
    if 'error' in response_lower or 'failed' in response_lower or 'sorry' in response_lower:
        info['has_error'] = True
        info['type'] = 'error'
    
    # Check for actions
    action_words = ['added', 'updated', 'deleted', 'created', 'modified', 'inserted']
    if any(word in response_lower for word in action_words):
        info['action_performed'] = True
    
    # Check for customer data
    if 'customer' in response_lower and ('result' in response_lower or 'record' in response_lower):
        info['type'] = 'customer_data'
    
    return info

def create_optimized_prompt(base_prompt: str, conversation_history: List, 
                          schema_context: List[Dict], max_tokens: int = 2000) -> str:
    """
    Create an optimized prompt that fits within token limits.
    """
    # Start with base prompt
    optimized_prompt = base_prompt
    
    # Add summarized conversation history
    summarized_history = summarize_conversation_history(conversation_history)
    history_text = ""
    for msg in summarized_history:
        # Handle both ChatMessage objects and dictionaries
        if hasattr(msg, 'role') and hasattr(msg, 'content'):
            # ChatMessage object
            role = getattr(msg, 'role', 'unknown')
            content = getattr(msg, 'content', '')
        elif isinstance(msg, dict):
            # Dictionary
            role = msg.get('role', 'unknown')
            content = msg.get('content', '')
        else:
            # Fallback
            role = 'unknown'
            content = str(msg)
        history_text += f"{role.upper()}: {content}\n"
    
    # Add optimized schema context
    optimized_schemas = optimize_schema_context(schema_context)
    schema_text = ""
    for schema in optimized_schemas:
        schema_text += f"\nTable: {schema['table_name']}\n"
        schema_text += f"Description: {schema['schema_description']}\n"
        schema_text += "Columns:\n"
        for col in schema['columns']:
            schema_text += f"  - {col['name']}: {col['type']} ({col['description']})\n"
    
    # Combine all parts
    full_prompt = f"{optimized_prompt}\n\nCONVERSATION:\n{history_text}\n\nSCHEMA:\n{schema_text}"
    
    # Truncate if too long
    if len(full_prompt) > max_tokens:
        # Truncate conversation history first
        full_prompt = f"{optimized_prompt}\n\nCONVERSATION:\n{history_text[:max_tokens//2]}\n\nSCHEMA:\n{schema_text[:max_tokens//2]}"
    
    return full_prompt 