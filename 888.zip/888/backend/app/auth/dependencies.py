"""
Authentication dependencies for FastAPI routes.
"""

from fastapi import Depends, HTTPException, status, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional
import jwt
from backend.app.config import get_settings, get_cookie_settings
from backend.app.services.mongodb_service import get_mongodb_service
from backend.app.models.user import User

security = HTTPBearer(auto_error=False)
settings = get_settings()

async def get_current_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    mongo_service = Depends(get_mongodb_service)
) -> User:
    """Get current authenticated user from JWT token"""
    try:
        # Get token from Authorization header or fallback to cookie
        token: Optional[str] = None
        if credentials and credentials.credentials:
            token = credentials.credentials
        if not token:
            cookie_name = get_cookie_settings("access")["key"]
            token = request.cookies.get(cookie_name)
        if not token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Not authenticated",
                headers={"WWW-Authenticate": "Bearer"},
            )
        # Decode JWT token
        payload = jwt.decode(
            token,
            settings.jwt.secret_key,
            algorithms=[settings.jwt.algorithm]
        )
        
        user_id: str = payload.get("user_id")
        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
            
        # Get user from database
        user = await mongo_service.get_user_by_id(user_id)
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found",
                headers={"WWW-Authenticate": "Bearer"},
            )
            
        return user
        
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

async def get_current_active_user(
    current_user: User = Depends(get_current_user)
) -> User:
    """Get current active user"""
    if current_user.status != "active":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user"
        )
    return current_user

async def require_admin(
    current_user: User = Depends(get_current_active_user)
) -> User:
    """Require admin role for access"""
    if current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions. Admin role required."
        )
    return current_user

async def get_optional_user(
    request: Request,
    mongo_service = Depends(get_mongodb_service)
) -> Optional[User]:
    """Get user from token if present, otherwise return None"""
    try:
        # Try to get token from Authorization header; fall back to cookie
        token: Optional[str] = None
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header.split(" ")[1]
        if not token:
            cookie_name = get_cookie_settings("access")["key"]
            token = request.cookies.get(cookie_name)
        if not token:
            return None
        
        # Decode JWT token
        payload = jwt.decode(
            token,
            settings.jwt.secret_key,
            algorithms=[settings.jwt.algorithm]
        )
        
        user_id: str = payload.get("user_id")
        if user_id is None:
            return None
            
        # Get user from database
        user = await mongo_service.get_user_by_id(user_id)
        return user
        
    except (jwt.PyJWTError, AttributeError, IndexError):
        return None
