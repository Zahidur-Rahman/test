"""
Admin router for the Multi-Business Conversational Chatbot.
Contains administrative endpoints for managing businesses, users, and system operations.
"""

from fastapi import APIRouter, HTTPException, Depends, status
import logging
from typing import Dict, Any, List, Optional
from backend.app.services.mongodb_service import MongoDBService, get_mongodb_service
from backend.app.services.db_introspection import DatabaseIntrospectionService
from backend.app.models.user import User, UserCreate, UserUpdate
from backend.app.models.business import BusinessConfig, BusinessConfigCreate, BusinessConfigUpdate
from backend.app.models.schema import TableSchema, TableSchemaCreate, TableSchemaUpdate
from backend.app.utils import hash_password
from backend.app.auth.dependencies import require_admin, get_current_user

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/admin",
    tags=["admin"]
)

# =============================================================================
# BUSINESS MANAGEMENT ENDPOINTS
# =============================================================================

@router.get("/businesses")
async def list_businesses(
    include_inactive: Optional[bool] = False,
    mongo_service: MongoDBService = Depends(get_mongodb_service)
):
    """List all businesses"""
    try:
        logger.info("Fetching all businesses from MongoDB")
        # Respect include_inactive filtering inside the service call
        businesses = await mongo_service.get_all_business_configs(include_inactive=bool(include_inactive))
        logger.info(f"Found {len(businesses)} businesses in MongoDB")
        
        
        business_list = []
        for b in businesses:
            business_data = {
                "business_id": b.business_id,
                "name": getattr(b, 'name', None),
                "description": getattr(b, 'description', None),
                "status": getattr(b, 'status', 'active'),
                "created_at": getattr(b, 'created_at', None),
                "updated_at": getattr(b, 'updated_at', None),
            }
            business_list.append(business_data)
            logger.info(f"Business: {business_data}")
        
        return {
            "businesses": business_list,
            "count": len(businesses)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing businesses: {str(e)}")

@router.post("/businesses")
async def create_business(
    business_config: BusinessConfigCreate,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Create a new business configuration"""
    try:
        # Check if business already exists
        existing_config = await mongo_service.get_business_config(business_config.business_id)
        if existing_config:
            raise HTTPException(
                status_code=400, 
                detail=f"Business '{business_config.business_id}' already exists"
            )
        
        # Create new business config
        config = BusinessConfig(
            business_id=business_config.business_id,
            name=business_config.name,
            description=business_config.description,
            db_config=business_config.db_config,
            status=business_config.status
        )
        success = await mongo_service.create_business_config(config)
        
        if success:
            return {
                "message": f"Business '{business_config.business_id}' created successfully",
                "business_id": business_config.business_id
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to create business")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating business: {str(e)}")

@router.put("/businesses/{business_id}")
async def update_business(
    business_id: str,
    business_update: BusinessConfigUpdate,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Update an existing business configuration"""
    try:
        # Check if business exists
        existing_config = await mongo_service.get_business_config(business_id)
        if not existing_config:
            raise HTTPException(
                status_code=404, 
                detail=f"Business '{business_id}' not found"
            )
        
        # Update business config
        success = await mongo_service.update_business_config(business_id, business_update)
        
        if success:
            return {
                "message": f"Business '{business_id}' updated successfully",
                "business_id": business_id
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to update business")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating business: {str(e)}")

@router.delete("/businesses/{business_id}")
async def delete_business(
    business_id: str,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Delete a business configuration"""
    try:
        # Check if business exists
        existing_config = await mongo_service.get_business_config(business_id)
        if not existing_config:
            raise HTTPException(
                status_code=404, 
                detail=f"Business '{business_id}' not found"
            )
        
        # Delete business config
        success = await mongo_service.delete_business_config(business_id)
        
        if success:
            return {
                "message": f"Business '{business_id}' deleted successfully",
                "business_id": business_id
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to delete business")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting business: {str(e)}")

# =============================================================================
# USER MANAGEMENT ENDPOINTS
# =============================================================================

@router.get("/users")
async def list_users(
    business_id: Optional[str] = None,
    page: Optional[int] = 1,
    page_size: Optional[int] = 50,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """List all users, optionally filtered by business with pagination"""
    try:
        # Get all users from MongoDB directly since get_all_users might not exist
        query = {}
        if business_id:
            query["business_id"] = business_id
            
        cursor = mongo_service._collections['users'].find(query)
        users_list = await cursor.to_list(length=None)
        
        # Apply pagination
        start_idx = (page - 1) * page_size
        end_idx = start_idx + page_size
        paginated_users = users_list[start_idx:end_idx]
        
        return {
            "users": [
                {
                    "user_id": user.get("user_id"),
                    "username": user.get("username"),
                    "email": user.get("email", ""),
                    "business_id": user.get("business_id"),
                    "role": user.get("role", "user"),
                    "is_active": user.get("is_active", True),
                    "created_at": user.get("created_at")
                }
                for user in paginated_users
            ],
            "total": len(users_list),
            "count": len(paginated_users),
            "page": page,
            "page_size": page_size
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing users: {str(e)}")

@router.post("/users")
async def create_user(
    user_data: UserCreate,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Create a new user"""
    try:
        logger.debug("[create_user] Start - username=%s, email=%s, business_id=%s, role=%s", user_data.username, user_data.email, user_data.business_id, user_data.role)
        # Basic input validation beyond Pydantic (empty strings, etc.)
        if not user_data.password or not str(user_data.password).strip():
            raise HTTPException(status_code=400, detail="Password is required")
        if not user_data.business_id or not str(user_data.business_id).strip():
            raise HTTPException(status_code=400, detail="business_id is required")
        # Ensure business exists
        existing_business = await mongo_service.get_business_config(user_data.business_id)
        if not existing_business:
            raise HTTPException(status_code=400, detail=f"Business '{user_data.business_id}' does not exist")
        # Check if user already exists
        existing_user = await mongo_service.get_user_by_username(user_data.username)
        if existing_user:
            raise HTTPException(
                status_code=400, 
                detail=f"User '{user_data.username}' already exists"
            )
        # Check if email already exists
        existing_email_user = await mongo_service.get_user_by_email(user_data.email)
        if existing_email_user:
            raise HTTPException(
                status_code=400,
                detail=f"Email '{user_data.email}' is already in use"
            )
        
        # Hash password and create user
        logger.debug("[create_user] Hashing password")
        hashed_password = hash_password(user_data.password)
        
        logger.debug("[create_user] Inserting user into MongoDB")
        user = await mongo_service.create_user(user_data, hashed_password)
        
        if user:
            logger.debug("[create_user] Success - user_id=%s", user.user_id)
            return {
                "message": f"User '{user_data.username}' created successfully",
                "user_id": user.user_id,
                "username": user.username
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to create user")
            
    except ValueError as e:
        # Surface known validation/duplicate errors as 400
        logger.warning("[create_user] ValueError: %s", str(e))
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.exception("[create_user] Unexpected error")
        raise HTTPException(status_code=500, detail=f"Error creating user: {str(e)}")

@router.put("/users/{user_id}")
async def update_user(
    user_id: str,
    user_update: UserUpdate,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Update an existing user"""
    try:
        # Check if user exists
        existing_user = await mongo_service.get_user_by_id(user_id)
        if not existing_user:
            raise HTTPException(
                status_code=404, 
                detail=f"User '{user_id}' not found"
            )
        
        # Update user
        success = await mongo_service.update_user(user_id, user_update)
        
        if success:
            return {
                "message": f"User '{user_id}' updated successfully",
                "user_id": user_id
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to update user")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating user: {str(e)}")

@router.delete("/users/{user_id}")
async def delete_user(
    user_id: str,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Delete a user"""
    try:
        # Check if user exists
        existing_user = await mongo_service.get_user_by_id(user_id)
        if not existing_user:
            raise HTTPException(
                status_code=404, 
                detail=f"User '{user_id}' not found"
            )
        
        # Prevent self-deletion
        if user_id == current_user.user_id:
            raise HTTPException(
                status_code=400, 
                detail="Cannot delete your own account"
            )
        
        # Delete user
        success = await mongo_service.delete_user(user_id)
        
        if success:
            return {
                "message": f"User '{user_id}' deleted successfully",
                "user_id": user_id
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to delete user")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting user: {str(e)}")

# =============================================================================
# SYSTEM MANAGEMENT ENDPOINTS
# =============================================================================

@router.get("/system/stats")
async def get_system_stats(
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Get system statistics"""
    try:
        # Get counts of various entities
        businesses = await mongo_service.get_all_business_configs()
        users = await mongo_service.get_all_users()
        
        return {
            "businesses": {
                "total": len(businesses),
                "business_ids": [b.business_id for b in businesses]
            },
            "users": {
                "total": len(users),
                "by_role": {
                    "admin": len([u for u in users if u.role == "admin"]),
                    "user": len([u for u in users if u.role == "user"]),
                    "business_admin": len([u for u in users if u.role == "business_admin"])
                },
                "active": len([u for u in users if u.is_active])
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting system stats: {str(e)}")

@router.post("/system/reindex-schemas")
async def reindex_schemas(
    business_id: Optional[str] = None,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Reindex schemas for all businesses or a specific business"""
    try:
        from backend.app.services.vector_search import FaissVectorSearchService
        vector_search_service = FaissVectorSearchService()
        
        if business_id:
            # Reindex specific business
            await vector_search_service.index_business_schemas(business_id)
            return {
                "message": f"Schemas reindexed for business '{business_id}'",
                "business_id": business_id
            }
        else:
            # Reindex all businesses
            businesses = await mongo_service.get_all_business_configs()
            business_ids = [b.business_id for b in businesses]
            
            for bid in business_ids:
                await vector_search_service.index_business_schemas(bid)
            
            return {
                "message": f"Schemas reindexed for all businesses",
                "businesses_processed": business_ids,
                "count": len(business_ids)
            }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reindexing schemas: {str(e)}")

# =============================================================================
# SCHEMA MANAGEMENT ENDPOINTS
# =============================================================================

@router.get("/businesses/{business_id}/schemas")
async def list_business_schemas(
    business_id: str,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """List all schemas for a specific business"""
    try:
        schemas = await mongo_service.get_business_schemas(business_id)
        return {
            "business_id": business_id,
            "schemas": [
                {
                    "table_name": schema.table_name,
                    "schema_description": schema.schema_description,
                    "columns": [
                        {
                            "name": col.name,
                            "type": col.type,
                            "description": col.description,
                            "is_nullable": getattr(col, 'is_nullable', True),
                            "is_primary_key": getattr(col, 'is_primary_key', False)
                        }
                        for col in schema.columns
                    ],
                    "created_at": getattr(schema, 'created_at', None),
                    "updated_at": getattr(schema, 'updated_at', None)
                }
                for schema in schemas
            ],
            "count": len(schemas)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing schemas: {str(e)}")

@router.post("/businesses/{business_id}/schemas")
async def create_business_schema(
    business_id: str,
    schema_data: Dict[str, Any],
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Create a new business schema for vector search"""
    try:
        from backend.app.models.business import BusinessSchema, ColumnInfo, TableRelationship
        from datetime import datetime
        
        # Validate required fields
        if not schema_data.get("table_name"):
            raise HTTPException(status_code=400, detail="table_name is required")
        if not schema_data.get("columns"):
            raise HTTPException(status_code=400, detail="columns are required")
        
        # Create column info objects
        columns = []
        for i, col_data in enumerate(schema_data["columns"]):
            if not col_data.get("name") or not col_data.get("type"):
                raise HTTPException(status_code=400, detail="Column name and type are required")
            
            column = ColumnInfo(
                name=col_data["name"],
                type=col_data["type"],
                max_length=col_data.get("max_length"),
                nullable=col_data.get("nullable", True),
                default=col_data.get("default"),
                position=col_data.get("position", i + 1),  # Auto-assign position if not provided
                business_meaning=col_data.get("business_meaning"),
                description=col_data.get("description"),
                constraints=col_data.get("constraints", [])
            )
            columns.append(column)
        
        # Create relationship objects
        relationships = []
        for rel_data in schema_data.get("relationships", []):
            relationship = TableRelationship(
                relationship_type=rel_data["relationship_type"],
                referenced_table=rel_data["referenced_table"],
                referenced_column=rel_data["referenced_column"],
                description=rel_data.get("description")
            )
            relationships.append(relationship)
        
        # Generate embedding text if not provided
        embedding_text = schema_data.get("embedding_text")
        if not embedding_text:
            # Generate from schema description and column meanings
            parts = [schema_data.get("schema_description", "")]
            for col in columns:
                if col.business_meaning:
                    parts.append(f"{col.name}: {col.business_meaning}")
                elif col.description:
                    parts.append(f"{col.name}: {col.description}")
            embedding_text = " ".join(filter(None, parts))
        
        # Create business schema
        business_schema = BusinessSchema(
            business_id=business_id,
            table_name=schema_data["table_name"],
            schema_description=schema_data.get("schema_description", ""),
            columns=columns,
            relationships=relationships,
            embedding_text=embedding_text,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        # Save to MongoDB
        success = await mongo_service.create_business_schema(business_schema)
        
        if success:
            # Reindex schemas for this business
            from backend.app.services.vector_search import FaissVectorSearchService
            vector_search_service = FaissVectorSearchService()
            await vector_search_service.index_business_schemas(business_id)
            
            return {
                "message": f"Schema '{schema_data['table_name']}' created successfully",
                "business_id": business_id,
                "table_name": schema_data["table_name"]
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to create schema")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating schema: {str(e)}")

@router.put("/businesses/{business_id}/schemas/{table_name}")
async def update_business_schema(
    business_id: str,
    table_name: str,
    schema_data: Dict[str, Any],
    mongo_service: MongoDBService = Depends(get_mongodb_service)
):
    """Update an existing table schema"""
    try:
        from backend.app.models.business import BusinessSchema, ColumnInfo, TableRelationship
        from datetime import datetime
        
        logger.info(f"Updating schema for business {business_id}, table {table_name}")
        logger.info(f"Schema data received: {schema_data}")
        
        # Check if schema exists
        existing_schemas = await mongo_service.get_business_schemas(business_id)
        existing_schema = None
        for schema in existing_schemas:
            if schema.table_name == table_name:
                existing_schema = schema
                break
        
        if not existing_schema:
            raise HTTPException(status_code=404, detail=f"Schema '{table_name}' not found")
        
        # Process columns using ColumnInfo model
        column_info_list = []
        if "columns" in schema_data and schema_data["columns"]:
            for i, col_data in enumerate(schema_data["columns"]):
                if not col_data.get("name") or not col_data.get("type"):
                    raise HTTPException(status_code=400, detail="Column name and type are required")
                
                # Create ColumnInfo object
                column_info = ColumnInfo(
                    name=col_data["name"],
                    type=col_data["type"],
                    max_length=col_data.get("max_length"),
                    nullable=col_data.get("nullable", True),
                    default=col_data.get("default"),
                    position=col_data.get("position", i + 1),
                    business_meaning=col_data.get("business_meaning"),
                    description=col_data.get("description"),
                    constraints=col_data.get("constraints", [])
                )
                column_info_list.append(column_info)
        else:
            column_info_list = existing_schema.columns
        
        # Process relationships using TableRelationship model
        relationship_list = []
        if "relationships" in schema_data and schema_data["relationships"]:
            for rel_data in schema_data["relationships"]:
                relationship = TableRelationship(
                    relationship_type=rel_data.get("relationship_type", ""),
                    referenced_table=rel_data.get("referenced_table", ""),
                    referenced_column=rel_data.get("referenced_column", ""),
                    description=rel_data.get("description", "")
                )
                relationship_list.append(relationship)
        else:
            relationship_list = existing_schema.relationships or []
        
        # Create updated BusinessSchema
        updated_schema = BusinessSchema(
            id=existing_schema.id,
            business_id=business_id,
            table_name=table_name,
            schema_description=schema_data.get("schema_description", existing_schema.schema_description),
            columns=column_info_list,
            relationships=relationship_list,
            embedding_text=existing_schema.embedding_text,
            vector_id=existing_schema.vector_id,
            indexed_at=existing_schema.indexed_at,
            created_at=existing_schema.created_at,
            updated_at=datetime.utcnow()
        )
        
        # Update in MongoDB
        # IMPORTANT: pass a plain dict to the MongoDB layer, not a Pydantic model
        success = await mongo_service.update_business_schema(
            business_id,
            table_name,
            updated_schema.model_dump(by_alias=True)
        )
        
        if success:
            # Reindex schemas for this business
            try:
                from backend.app.services.vector_search import FaissVectorSearchService
                vector_search_service = FaissVectorSearchService()
                await vector_search_service.index_business_schemas(business_id)
            except Exception as e:
                logger.warning(f"Failed to reindex schemas: {e}")
            
            return {
                "message": f"Schema '{table_name}' updated successfully",
                "business_id": business_id,
                "table_name": table_name,
                "columns_count": len(column_info_list),
                "relationships_count": len(relationship_list)
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to update schema")
            
    except Exception as e:
        logger.error(f"Error updating business schema: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error updating schema: {str(e)}")

@router.delete("/businesses/{business_id}/schemas/{table_name}")
async def delete_business_schema(
    business_id: str,
    table_name: str,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Delete a table schema"""
    try:
        # Check if schema exists
        existing_schemas = await mongo_service.get_business_schemas(business_id)
        schema_exists = any(schema.table_name == table_name for schema in existing_schemas)
        
        if not schema_exists:
            raise HTTPException(status_code=404, detail=f"Schema '{table_name}' not found")
        
        # Delete schema
        success = await mongo_service.delete_business_schema(business_id, table_name)
        
        if success:
            # Reindex schemas for this business
            from backend.app.services.vector_search import FaissVectorSearchService
            vector_search_service = FaissVectorSearchService()
            await vector_search_service.index_business_schemas(business_id)
            
            return {
                "message": f"Schema '{table_name}' deleted successfully",
                "business_id": business_id,
                "table_name": table_name
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to delete schema")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting schema: {str(e)}")

# =============================================================================
# DATABASE INTROSPECTION ENDPOINTS
# =============================================================================

@router.get("/businesses/{business_id}/tables")
async def get_business_tables(
    business_id: str,
    mongo_service: MongoDBService = Depends(get_mongodb_service)
):
    """Get all tables from business database"""
    try:
        logger.info(f"=== TABLES REQUEST FOR BUSINESS {business_id} ===")
        
        # First check if MongoDB connection works
        try:
            await mongo_service.connect()
            logger.info("MongoDB connection successful")
        except Exception as mongo_error:
            logger.error(f"MongoDB connection failed: {mongo_error}")
            raise HTTPException(status_code=500, detail=f"Database service unavailable: {str(mongo_error)}")
        
        # Get business config
        logger.info(f"Attempting to get business config for ID: {business_id}")
        business_config = await mongo_service.get_business_config(business_id)
        logger.info(f"Business config result: {business_config}")
        
        if not business_config:
            logger.error(f"Business config not found for ID: {business_id}")
            # Let's also check what businesses exist
            all_businesses = await mongo_service.get_all_business_configs()
            available_ids = [b.business_id for b in all_businesses]
            logger.info(f"Available businesses: {available_ids}")
            
            
            raise HTTPException(
                status_code=404, 
                detail=f"Business '{business_id}' not found. Available businesses: {available_ids}"
            )
        
        logger.info(f"Fetching tables for business: {business_id}")
        logger.info(f"DB Config: host={business_config.db_config.host}, database={business_config.db_config.database}")
        
        # Test connection first
        try:
            connection_test = await DatabaseIntrospectionService.test_connection(business_config.db_config)
            logger.info(f"Database connection test result: {connection_test}")
            
            if not connection_test:
                raise HTTPException(status_code=500, detail=f"Cannot connect to database for business '{business_id}'. Check database configuration.")
        except Exception as conn_error:
            logger.error(f"Connection test failed: {conn_error}")
            raise HTTPException(status_code=500, detail=f"Database connection error: {str(conn_error)}")
        
        # Get tables
        try:
            tables = await DatabaseIntrospectionService.get_tables(business_config.db_config)
            logger.info(f"Tables fetched successfully: {tables}")
        except Exception as table_error:
            logger.error(f"Failed to fetch tables: {table_error}")
            raise HTTPException(status_code=500, detail=f"Error fetching tables: {str(table_error)}")
        
        # Extract just table names for the frontend dropdown
        table_names = [table["table_name"] if isinstance(table, dict) else str(table) for table in tables]
        
        logger.info(f"Found {len(table_names)} tables for business {business_id}: {table_names}")
        return {"tables": table_names, "business_id": business_id, "count": len(table_names)}
    except ValueError as e:
        logger.error(f"Validation error fetching tables for business {business_id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error fetching tables for business {business_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error fetching tables: {str(e)}")

@router.get("/businesses/{business_id}/tables/{table_name}/columns")
async def get_table_columns(
    business_id: str,
    table_name: str,
    mongo_service: MongoDBService = Depends(get_mongodb_service)
):
    """Get all columns for a specific table"""
    try:
        business_config = await mongo_service.get_business_config(business_id)
        if not business_config:
            raise HTTPException(status_code=404, detail=f"Business '{business_id}' not found")
        
        columns = await DatabaseIntrospectionService.get_columns(business_config.db_config, table_name)
        
        # Convert columns to format expected by frontend
        formatted_columns = []
        for col in columns:
            col_dict = col.model_dump()
            # Map database column properties to frontend format
            formatted_col = {
                "name": col_dict.get("name"),
                "type": col_dict.get("type"),
                "max_length": col_dict.get("max_length"),
                "nullable": col_dict.get("is_nullable", True),
                "default": col_dict.get("default_value"),
                "is_primary_key": col_dict.get("is_primary_key", False),
                "is_foreign_key": False,  # TODO: Add foreign key detection
                "is_unique": False,  # TODO: Add unique constraint detection
                "constraints": []
            }
            
            # Add constraints based on column properties
            if formatted_col["is_primary_key"]:
                formatted_col["constraints"].append("PRIMARY KEY")
            if not formatted_col["nullable"]:
                formatted_col["constraints"].append("NOT NULL")
                
            formatted_columns.append(formatted_col)
        
        logger.info(f"Returning {len(formatted_columns)} columns for table {table_name}")
        return {"columns": formatted_columns}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching columns: {str(e)}")

@router.get("/businesses/{business_id}/tables/{table_name}")
async def get_table_details(
    business_id: str,
    table_name: str,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Get table details with columns"""
    try:
        business_config = await mongo_service.get_business_config(business_id)
        if not business_config:
            raise HTTPException(status_code=404, detail=f"Business '{business_id}' not found")
        
        table_details = await DatabaseIntrospectionService.get_table_with_columns(
            business_config.db_config, table_name
        )
        return table_details
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error fetching table details for business {business_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error fetching table details: {str(e)}")

@router.post("/businesses/{business_id}/test-connection")
async def test_business_connection(
    business_id: str,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Test database connection for a business"""
    try:
        business_config = await mongo_service.get_business_config(business_id)
        if not business_config:
            raise HTTPException(status_code=404, detail=f"Business '{business_id}' not found")
        
        logger.info(f"Testing connection for business {business_id}: {business_config.db_config.host}:{business_config.db_config.port}/{business_config.db_config.database}")
        
        success = await DatabaseIntrospectionService.test_connection(business_config.db_config)
        
        response = {
            "success": success,
            "business_id": business_id,
            "message": "Connection successful" if success else "Connection failed",
            "database_info": {
                "host": business_config.db_config.host,
                "port": business_config.db_config.port,
                "database": business_config.db_config.database,
                "user": business_config.db_config.user
            } if success else None
        }
        
        logger.info(f"Connection test result for {business_id}: {success}")
        return response
        
    except Exception as e:
        logger.error(f"Error testing connection for business {business_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error testing connection: {str(e)}")

@router.get("/businesses/{business_id}/relationships")
async def get_business_relationships(
    business_id: str,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Get all table relationships for a business database"""
    try:
        business_config = await mongo_service.get_business_config(business_id)
        if not business_config:
            raise HTTPException(status_code=404, detail=f"Business '{business_id}' not found")
        
        relationships = await DatabaseIntrospectionService.get_table_relationships(business_config.db_config)
        return {"relationships": relationships, "business_id": business_id}
    except Exception as e:
        logger.error(f"Error fetching relationships for business {business_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error fetching relationships: {str(e)}")


@router.post("/businesses/{business_id}/schemas")
async def create_business_schema(
    business_id: str,
    schema_data: dict,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Create a new business schema with manual relationship entry"""
    try:
        from backend.app.models.business import BusinessSchema, ColumnInfo, TableRelationship, BusinessSchemaCreateUpdate
        from datetime import datetime
        
        # Extract data from request
        table_name = schema_data.get('table_name')
        schema_description = schema_data.get('schema_description')
        selected_columns = schema_data.get('columns', [])
        relationships = schema_data.get('relationships', [])
        
        if not table_name or not schema_description:
            raise HTTPException(status_code=400, detail="table_name and schema_description are required")
        
        # Create ColumnInfo objects
        column_info_list = []
        for i, col_data in enumerate(selected_columns):
            column_info = ColumnInfo(
                name=col_data['name'],
                type=col_data['type'],
                max_length=col_data.get('max_length'),
                nullable=col_data.get('nullable', True),
                default=col_data.get('default'),
                position=col_data.get('position', i),
                business_meaning=col_data.get('business_meaning'),
                description=col_data.get('description'),
                constraints=col_data.get('constraints', [])
            )
            column_info_list.append(column_info)
        
        # Create TableRelationship objects from manual entry
        relationship_list = []
        for rel_data in relationships:
            if rel_data.get('relationship_type') and rel_data.get('referenced_table') and rel_data.get('referenced_column'):
                relationship = TableRelationship(
                    relationship_type=rel_data['relationship_type'],
                    referenced_table=rel_data['referenced_table'],
                    referenced_column=rel_data['referenced_column'],
                    description=rel_data.get('description')
                )
                relationship_list.append(relationship)
        
        # Create BusinessSchemaCreateUpdate instance
        schema_create = BusinessSchemaCreateUpdate(
            business_id=business_id,
            table_name=table_name,
            schema_description=schema_description,
            columns=column_info_list,
            relationships=relationship_list
        )
        
        # Generate embedding text if not provided
        embedding_text = schema_create.generate_embedding_text()
        
        # Create BusinessSchema for MongoDB
        business_schema = BusinessSchema(
            business_id=business_id,
            table_name=table_name,
            schema_description=schema_description,
            columns=column_info_list,
            relationships=relationship_list,
            embedding_text=embedding_text,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        # Save to MongoDB
        result = await mongo_service.db.business_schemas.insert_one(business_schema.dict(by_alias=True))
        
        if result.inserted_id:
            # Index in vector search
            try:
                from backend.app.services.vector_search import FaissVectorSearchService
                vector_service = FaissVectorSearchService()
                await vector_service.index_business_schemas(business_id)
            except Exception as e:
                logger.warning(f"Failed to index schema in vector search: {e}")
            
            return {
                "message": f"Schema '{table_name}' created successfully",
                "business_id": business_id,
                "table_name": table_name,
                "schema_id": str(result.inserted_id),
                "columns_count": len(column_info_list),
                "relationships_count": len(relationship_list)
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to create schema")
            
    except Exception as e:
        logger.error(f"Error creating business schema: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error creating schema: {str(e)}")


@router.get("/businesses/{business_id}/tables/{table_name}/relationships")
async def get_table_relationships(
    business_id: str,
    table_name: str,
    mongo_service: MongoDBService = Depends(get_mongodb_service),
    current_user: User = Depends(require_admin)
):
    """Get relationships for a specific table"""
    try:
        business_config = await mongo_service.get_business_config(business_id)
        if not business_config:
            raise HTTPException(status_code=404, detail=f"Business '{business_id}' not found")
        
        relationships = await DatabaseIntrospectionService.get_table_relationships(business_config.db_config, table_name)
        return {"relationships": relationships}
    except Exception as e:
        logger.error(f"Error fetching relationships for table {table_name} in business {business_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error fetching relationships: {str(e)}")
