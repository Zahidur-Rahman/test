from langgraph.graph import StateGraph
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
from backend.app.utils.customer_query_classifier import CustomerQueryClassifier
import importlib
from backend.app.utils import customer_chat_helpers
importlib.reload(customer_chat_helpers)
from backend.app.utils.customer_chat_helpers import (
    get_next_customer_id, get_customer_schema_context, build_customer_sql_prompt,
    build_customer_system_prompt, clean_sql_from_llm, extract_customer_fields_from_message,
    format_customer_result
)
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.models.conversation import ChatMessage
import logging
import time
import json
import re
import string

logger = logging.getLogger(__name__)

# Initialize services
llm_service = MistralLLMService()
customer_classifier = CustomerQueryClassifier()
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

def ensure_chat_messages(messages):
    """Convert messages to ChatMessage objects if needed."""
    if not messages:
        return []
    return [msg if isinstance(msg, ChatMessage) else ChatMessage.model_validate(msg) for msg in messages]

# --- Node Functions ---

async def classify_customer_query(context):
    """Classify the customer query and get schema context."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    context.conversation_history = ensure_chat_messages(context.conversation_history or [])
    
    # Classify the customer query
    context.customer_action = await customer_classifier.classify_query(context.message)
    
    # Get customer schema context from vector DB
    context.schema_context = await get_customer_schema_context(context.business_id, context.message)
    
    logger.info(f"[CustomerGraph] Query classified as: {context.customer_action}")
    return context.model_dump()

async def route_customer_action(context):
    """Route to appropriate customer action handler."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    # Check for pause/resume logic first
    if getattr(context, 'pause_reason', None) in {'confirm_update', 'confirm_delete'}:
        context.next = "ResumeOrClassify"
        return context.model_dump()
    
    action = getattr(context, 'customer_action', 'GENERAL_CUSTOMER')
    
    if action == 'CREATE_CUSTOMER':
        context.next = "VectorSearch"
    elif action in ['SEARCH_CUSTOMER', 'LIST_CUSTOMERS']:
        context.next = "VectorSearch"
    elif action in ['UPDATE_CUSTOMER', 'DELETE_CUSTOMER']:
        context.next = "VectorSearch"
    else:
        context.next = "GeneralCustomerChat"
    
    return context.model_dump()

async def vector_search_node(context):
    """Get customer schema context for database operations."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    # Get enhanced schema context for customer operations
    if not context.schema_context:
        context.schema_context = await get_customer_schema_context(context.business_id, context.message)
    
    return context.model_dump()

async def generate_customer_sql_node(context):
    """Generate SQL for customer operations."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    context.conversation_history = ensure_chat_messages(context.conversation_history or [])
    
    # Build SQL prompt for customer operations
    context.sql_prompt = build_customer_sql_prompt(
        context, context.conversation_history, context.schema_context or []
    )
    
    # Generate SQL using LLM
    messages = [
        {"role": "system", "content": context.sql_prompt},
        {"role": "user", "content": context.message}
    ]
    
    sql_response = await llm_service.chat(messages)
    context.sql = clean_sql_from_llm(sql_response)
    
    logger.info(f"[CustomerSQL] Generated: {context.sql}")
    return context.model_dump()

async def customer_dependency_check_node(context):
    """Check for dependencies and handle pause/resume logic for customer operations."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    sql = context.sql or ""
    
    # Validate SQL for UPDATE/DELETE operations
    update_pattern = re.compile(r"^update\s+\w+\s+set\s+.+where\s+.+", re.IGNORECASE | re.DOTALL)
    delete_pattern = re.compile(r"^delete\s+from\s+\w+\s+where\s+.+", re.IGNORECASE | re.DOTALL)
    
    if ("update" in sql.lower() and not update_pattern.match(sql)) or ("delete" in sql.lower() and not delete_pattern.match(sql)):
        logger.warning("[CustomerDepCheck] Invalid UPDATE/DELETE SQL detected")
        context.response = "I need more specific information to update or delete a customer. Please provide the customer ID or more details."
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # Check for DELETE confirmation
    if "delete" in sql.lower() and not getattr(context, "confirm", False):
        logger.info("[CustomerDepCheck] Pausing for delete confirmation")
        context.response = "⚠️ You are about to permanently delete a customer record. This action cannot be undone. Please confirm by replying 'confirm delete'."
        context.pause_reason = "confirm_delete"
        context.pause_message = context.response
        context.next = "PauseNode"
        return context.model_dump()
    
    # Check for UPDATE confirmation
    if "update" in sql.lower() and not getattr(context, "confirm", False):
        logger.info("[CustomerDepCheck] Pausing for update confirmation")
        context.response = "📝 You are about to update customer information. Please confirm by replying 'confirm update'."
        context.pause_reason = "confirm_update"
        context.pause_message = context.response
        context.next = "PauseNode"
        return context.model_dump()
    
    # For INSERT operations, generate customer ID first
    if "insert" in sql.lower():
        context.next = "GenerateCustomerID"
    else:
        context.next = "ExecuteCustomerSQL"
    
    return context.model_dump()

async def generate_customer_id_node(context):
    """
    Enhanced customer ID generation node with better error handling.
    """
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    try:
        # Generate the next customer ID
        logger.info(f"[GenerateCustomerID] Starting for business_id: {context.business_id}")
        next_customer_id = await get_next_customer_id(context.business_id)
        logger.info(f"[GenerateCustomerID] Generated: {next_customer_id}")
        
        # Get the current SQL
        sql = context.sql or ""
        
        if "insert" in sql.lower() and "cacus" in sql.lower():
            # Parse the INSERT statement more robustly
            import re
            
            # Pattern to match INSERT INTO table (columns) VALUES (values)
            pattern = r"INSERT\s+INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)"
            match = re.search(pattern, sql, re.IGNORECASE | re.DOTALL)
            
            if match:
                table_name = match.group(1).strip()
                columns_str = match.group(2).strip()
                values_str = match.group(3).strip()
                
                # Split columns and values, handling potential whitespace
                columns = [col.strip() for col in columns_str.split(',')]
                values = [val.strip() for val in values_str.split(',')]
                
                logger.info(f"[GenerateCustomerID] Original columns: {columns}")
                logger.info(f"[GenerateCustomerID] Original values: {values}")
                
                # Find where to insert xcus (after zid)
                insert_position = 1  # Default after first column
                
                for i, col in enumerate(columns):
                    if 'zid' in col.lower():
                        insert_position = i + 1
                        break
                
                # Insert xcus column and value
                columns.insert(insert_position, 'xcus')
                values.insert(insert_position, f"'{next_customer_id}'")
                
                # Reconstruct the SQL
                new_columns = ', '.join(columns)
                new_values = ', '.join(values)
                context.sql = f"INSERT INTO {table_name} ({new_columns}) VALUES ({new_values})"
                
                logger.info(f"[GenerateCustomerID] Updated SQL: {context.sql}")
                
            else:
                logger.error(f"[GenerateCustomerID] Could not parse INSERT statement: {sql}")
                context.response = "Error: Could not generate customer ID due to SQL parsing issue."
                context.next = "CustomerResponse"
                return context.model_dump()
        
        context.next = "ExecuteCustomerSQL"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[GenerateCustomerID] Error: {e}")
        context.response = f"Error generating customer ID: {e}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def execute_customer_sql_node(context):
    """Execute customer SQL operations via MCP."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    sql = getattr(context, 'sql', None)
    business_id = getattr(context, 'business_id', None)
    
    logger.info(f"[CustomerSQL_EXECUTED] {sql}")
    start_time = time.time()
    
    try:
        mcp_result = await mcp_client.execute_query(sql, business_id)
        
        # Parse MCP result
        rows = []
        error_message = None
        
        if isinstance(mcp_result, dict):
            if mcp_result.get('error'):
                error_message = mcp_result['error']
            
            if 'content' in mcp_result and isinstance(mcp_result['content'], list):
                for item in mcp_result['content']:
                    if 'text' in item and 'error' in item['text'].lower():
                        error_message = item['text']
                        break
                
                try:
                    import json
                    parsed = json.loads(mcp_result['content'][0]['text'])
                    rows = parsed.get('results', [])
                except Exception as e:
                    logger.error(f"Error parsing customer MCP result: {e}")
                    rows = []
        
        elapsed = time.time() - start_time
        
        # Handle errors
        if error_message:
            logger.error(f"[CustomerSQL_ERROR] {error_message}")
            if 'foreign key constraint' in error_message.lower():
                # Extract customer ID from the error message for cascade deletion
                import re
                customer_id_match = re.search(r'CUS-\d{6}', error_message)
                if customer_id_match and 'delete' in sql.lower():
                    customer_id = customer_id_match.group()
                    logger.info(f"[CustomerSQL_CASCADE] Attempting cascade deletion for {customer_id}")
                    
                    # Try cascade deletion - delete dependent records first
                    cascade_sql = f"""
                    DELETE FROM cacuscon WHERE zid = {business_id} AND xcus = '{customer_id}';
                    DELETE FROM cacus WHERE zid = {business_id} AND xcus = '{customer_id}';
                    """
                    
                    try:
                        cascade_result = await mcp_client.execute_query(cascade_sql, business_id)
                        if isinstance(cascade_result, dict) and not cascade_result.get('error'):
                            context.response = "✅ Customer and all related records have been successfully deleted from the system."
                            # Clear pause fields
                            context.pause_reason = None
                            context.pause_message = None
                            context.confirm = None
                            context.resume_from_pause = None
                            return context.model_dump()
                    except Exception as cascade_error:
                        logger.error(f"[CustomerSQL_CASCADE_ERROR] {cascade_error}")
                
                context.response = "Unable to delete the customer because there are related records (such as contacts or orders). The system attempted to remove related records but encountered an issue. Please contact support for manual deletion."
            else:
                context.response = f"Sorry, I couldn't complete your request due to a database error: {error_message}"
            
            # Clear pause fields
            context.pause_reason = None
            context.pause_message = None
            context.confirm = None
            context.resume_from_pause = None
            return context.model_dump()
        
        # Handle successful operations
        is_select = sql.strip().lower().startswith("select")
        is_insert = sql.strip().lower().startswith("insert")
        is_update = sql.strip().lower().startswith("update")
        is_delete = sql.strip().lower().startswith("delete")
        
        if is_select:
            if not rows:
                context.response = "No customers found matching your criteria. Would you like to try a different search or add a new customer?"
            else:
                from backend.app.utils.customer_chat_helpers import format_customer_result
                context.response = format_customer_result(rows)
        
        elif is_insert:
            # Fetch the newly created customer to show details
            try:
                # Extract the generated customer ID from the INSERT SQL
                import re
                customer_id_match = re.search(r"'(CUS-\d{6})'", sql)
                if customer_id_match:
                    new_customer_id = customer_id_match.group(1)
                    
                    # Query to get the newly created customer details
                    fetch_sql = f"SELECT * FROM cacus WHERE zid = {business_id} AND xcus = '{new_customer_id}'"
                    fetch_result = await mcp_client.execute_query(fetch_sql, business_id)
                    
                    if isinstance(fetch_result, dict) and 'content' in fetch_result:
                        try:
                            import json
                            parsed = json.loads(fetch_result['content'][0]['text'])
                            customer_data = parsed.get('results', [])
                            
                            if customer_data:
                                from backend.app.utils.customer_chat_helpers import format_customer_result
                                customer_details = format_customer_result(customer_data)
                                context.response = f"✅ Customer has been successfully added to the system!\n\n{customer_details}"
                            else:
                                context.response = f"✅ Customer has been successfully added to the system! Customer ID: {new_customer_id}"
                        except Exception as format_error:
                            logger.error(f"[CustomerSQL_FORMAT] Error formatting new customer: {format_error}")
                            context.response = f"✅ Customer has been successfully added to the system! Customer ID: {new_customer_id}"
                else:
                    context.response = "✅ Customer has been successfully added to the system! The customer ID has been automatically generated."
            except Exception as fetch_error:
                logger.error(f"[CustomerSQL_FETCH] Error fetching new customer: {fetch_error}")
                context.response = "✅ Customer has been successfully added to the system! The customer ID has been automatically generated."
            
            # Clear pause fields
            context.pause_reason = None
            context.pause_message = None
            context.confirm = None
            context.resume_from_pause = None
        
        elif is_update:
            context.response = "✅ Customer information has been successfully updated!"
            # Clear pause fields
            context.pause_reason = None
            context.pause_message = None
            context.confirm = None
            context.resume_from_pause = None
        
        elif is_delete:
            context.response = "✅ Customer has been successfully deleted from the system."
            # Clear pause fields
            context.pause_reason = None
            context.pause_message = None
            context.confirm = None
            context.resume_from_pause = None
        
        else:
            context.response = "Operation completed successfully."
    
    except Exception as e:
        logger.error(f"[CustomerSQL_EXCEPTION] {e}")
        context.response = f"Sorry, there was an error executing your request: {e}"
    
    return context.model_dump()

async def pause_node(context):
    """Handle pause state for confirmations with dynamic messaging."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    # Generate dynamic confirmation messages based on operation context
    if getattr(context, "pause_reason", None) == "confirm_update":
        # Extract operation details from SQL for more specific messaging
        sql = getattr(context, 'sql', '')
        operation_details = ""
        if 'SET' in sql.upper():
            # Try to extract what's being updated
            import re
            set_match = re.search(r'SET\s+(.+?)\s+WHERE', sql, re.IGNORECASE)
            if set_match:
                operation_details = f" ({set_match.group(1).strip()})"
        
        context.response = f"📝 You are about to update customer information{operation_details}. Do you want to proceed? Reply 'yes' to confirm or 'no' to cancel."
        context.pause_message = context.response
        
    elif getattr(context, "pause_reason", None) == "confirm_delete":
        # Extract customer ID if available for more specific messaging
        sql = getattr(context, 'sql', '')
        customer_info = ""
        if 'xcus' in sql:
            import re
            cus_match = re.search(r"xcus\s*=\s*'(CUS-\d{6})'", sql, re.IGNORECASE)
            if cus_match:
                customer_info = f" (Customer ID: {cus_match.group(1)})"
        
        context.response = f"⚠️ You are about to permanently delete a customer record{customer_info}. This action cannot be undone. Reply 'yes' to confirm or 'no' to cancel."
        context.pause_message = context.response
        
    else:
        context.response = "Confirmation required for this action. Reply 'yes' to proceed or 'no' to cancel."
        context.pause_message = context.response
    
    return context.model_dump()

async def analyze_user_intent(message: str, conversation_history=None, operation_context=None) -> str:
    """Analyze user intent using LLM with full conversation context for confirmation/cancellation detection."""
    try:
        # Build conversation context for better understanding
        context_text = ""
        if conversation_history:
            recent_messages = conversation_history[-8:] if len(conversation_history) > 8 else conversation_history
            logger.info(f"[IntentAnalysis] Processing {len(recent_messages)} conversation messages")
            for msg in recent_messages:
                role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
                content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
                context_text += f"{role.upper()}: {content}\n"
                logger.info(f"[IntentAnalysis] Added message: {role}: {content[:50]}...")
        else:
            logger.info(f"[IntentAnalysis] No conversation history available")
        
        # Add operation context if available
        operation_info = ""
        if operation_context:
            operation_info = f"\nPending Operation: {operation_context}"
        
        intent_prompt = f"""You are analyzing user intent in a conversation where the system asked for confirmation of an operation.

CONVERSATION CONTEXT:
{context_text}
CURRENT USER MESSAGE: "{message}"{operation_info}

CRITICAL CONTEXT ANALYSIS:
- Look at the LAST assistant message in the conversation
- If the last assistant message contains words like "canceled", "cancelled", "start fresh", then the operation was already cancelled
- If user says "yes" AFTER a cancellation message, they are NOT confirming the old operation - they are just acknowledging or starting fresh

The user was asked to confirm an operation. Analyze their response and classify their intent:

- POSITIVE: User agrees to proceed with the CURRENT pending operation (not a cancelled one)
  Examples: "yes", "sure", "go ahead", "do it", "confirm", "proceed", "okay", "alright", "fine"
  BUT ONLY if there's no recent cancellation message from assistant
  
- NEGATIVE: User disagrees, wants to cancel, rejects the action  
  Examples: "no", "cancel", "stop", "abort", "don't", "nevermind", "forget it", "skip", "nope", "forget", "i dont want", "dont want", "cancle it"
  
- UNCLEAR: Intent is ambiguous, unrelated, or user is responding to a cancellation message
  Examples: unclear responses, questions, unrelated topics, "yes" after cancellation

SPECIAL RULE: If the last assistant message mentioned cancellation/cancelled and user says "yes", classify as UNCLEAR (they're not confirming an operation)

Respond with ONLY one word: POSITIVE, NEGATIVE, or UNCLEAR"""

        response = await llm_service.chat([
            {"role": "system", "content": "You are an expert intent classifier that understands natural language nuances and conversation context. Always respond with exactly one word."},
            {"role": "user", "content": intent_prompt}
        ])
        
        intent = response.strip().upper()
        logger.info(f"[IntentAnalysis] Raw LLM response: '{response}'")
        logger.info(f"[IntentAnalysis] Processed intent: '{intent}'")
        logger.info(f"[IntentAnalysis] Message analyzed: '{message}'")
        logger.info(f"[IntentAnalysis] Operation context: '{operation_context}'")
        
        if intent in ["POSITIVE", "NEGATIVE", "UNCLEAR"]:
            return intent
        
        # If LLM returns unexpected format, try to extract intent
        if "positive" in response.lower():
            logger.info(f"[IntentAnalysis] Extracted POSITIVE from: '{response}'")
            return "POSITIVE"
        elif "negative" in response.lower():
            logger.info(f"[IntentAnalysis] Extracted NEGATIVE from: '{response}'")
            return "NEGATIVE"
        else:
            logger.info(f"[IntentAnalysis] Defaulting to UNCLEAR for: '{response}'")
            return "UNCLEAR"
        
    except Exception as e:
        logger.error(f"[IntentAnalysis] LLM Error: {e}")
        # Emergency fallback - return UNCLEAR to ask for clarification
        return "UNCLEAR"

async def analyze_confirmation_intent(message: str, conversation_history=None, operation_context=None) -> str:
    """Analyze if user message is a confirmation response or new query using LLM."""
    try:
        # Build conversation context
        context_text = ""
        if conversation_history:
            recent_messages = conversation_history[-4:] if len(conversation_history) > 4 else conversation_history
            for msg in recent_messages:
                role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
                content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
                context_text += f"{role.upper()}: {content}\n"
        
        confirmation_prompt = f"""You are analyzing user intent in a conversation where the system asked for confirmation.

CONVERSATION CONTEXT:
{context_text}
CURRENT USER MESSAGE: "{message}"
OPERATION CONTEXT: {operation_context}

Analyze the user's message and classify their intent:

- CONFIRMATION: User is responding to the confirmation request (positive, negative, or unclear response to the pending operation)
  Examples: "yes", "no", "sure", "go ahead", "cancel it", "don't do it", "I agree", "nope", "absolutely", "definitely not", "sounds good", "skip it"
  
- NEW_QUERY: User is asking something completely different, ignoring the confirmation request
  Examples: "show me customers", "last customer", "add new customer", "his details", "customer list", "what about orders", "tell me about products"

The key difference:
- CONFIRMATION = responding to the pending operation (even if unclear)
- NEW_QUERY = completely different topic/request

Respond with ONLY: CONFIRMATION or NEW_QUERY"""

        response = await llm_service.chat([
            {"role": "system", "content": "You are an expert intent classifier. Respond with exactly one word."},
            {"role": "user", "content": confirmation_prompt}
        ])
        
        intent = response.strip().upper()
        logger.info(f"[ConfirmationIntent] Message: '{message}' → Intent: '{intent}'")
        
        if intent in ["CONFIRMATION", "NEW_QUERY"]:
            return intent
        
        # Fallback parsing
        if "confirmation" in response.lower():
            return "CONFIRMATION"
        elif "new_query" in response.lower() or "new query" in response.lower():
            return "NEW_QUERY"
        else:
            # Default to CONFIRMATION to be safe (continue with existing flow)
            return "CONFIRMATION"
        
    except Exception as e:
        logger.error(f"[ConfirmationIntent] Error: {e}")
        # Safe fallback - assume confirmation to avoid breaking existing flow
        return "CONFIRMATION"

async def resume_or_classify_node(context):
    """Handle resume from pause or new classification with intelligent intent detection."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    user_message = getattr(context, 'message', '').strip()
    current_pause_reason = getattr(context, 'pause_reason', None)
    
    logger.debug(f"[CustomerResumeOrClassify] user_message: '{user_message}', pause_reason: '{current_pause_reason}'")
    
    # Only analyze intent if we have an active pause state
    if current_pause_reason:
        # Use LLM to detect if this is a confirmation response or new query
        conversation_history = getattr(context, 'conversation_history', [])
        operation_context = f"{current_pause_reason}: {getattr(context, 'sql', 'Unknown operation')}"
        
        # Quick LLM analysis to determine if this is confirmation-related
        confirmation_intent = await analyze_confirmation_intent(user_message, conversation_history, operation_context)
        
        # If it's clearly a new query (not confirmation-related), clear pause state
        if confirmation_intent == "NEW_QUERY":
            logger.info(f"[CustomerResumeOrClassify] New query detected while in pause state, clearing pause: '{user_message}'")
            # Clear all pause-related state
            context.pause_reason = None
            context.pause_message = None
            context.confirm = None
            context.resume_from_pause = None
            context.sql = None
            context.customer_action = None
            context.next = "ClassifyCustomerQuery"
            return context.model_dump()
        
        # Pass conversation context and operation details to LLM for better analysis
        conversation_history = getattr(context, 'conversation_history', [])
        operation_context = f"{current_pause_reason}: {getattr(context, 'sql', 'Unknown operation')}"
        
        # Check if this is a fresh "yes" after a completed cancellation
        # Look at the last assistant message to see if it was a cancellation response
        last_assistant_message = ""
        if conversation_history:
            for msg in reversed(conversation_history):
                role = msg.get('role', '') if isinstance(msg, dict) else getattr(msg, 'role', '')
                if role == 'assistant':
                    content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
                    last_assistant_message = content.lower()
                    break
        
        # If last assistant message was a cancellation and user says "yes", treat as new request
        cancellation_phrases = ["canceled", "cancelled", "start fresh", "no problem"]
        if (user_message.lower().strip() in ["yes", "ok", "okay"] and 
            any(phrase in last_assistant_message for phrase in cancellation_phrases)):
            logger.info(f"[CustomerResumeOrClassify] Detected 'yes' after cancellation - treating as new request")
            # Complete cleanup and start fresh
            context.pause_reason = None
            context.pause_message = None
            context.confirm = None
            context.resume_from_pause = None
            context.sql = None
            context.customer_action = None
            context.is_db_query = None
            context.sql_prompt = None
            context.system_prompt = None
            context.db_result = None
            context.next = "ClassifyCustomerQuery"
            return context.model_dump()
        
        user_intent = await analyze_user_intent(user_message, conversation_history, operation_context)
        logger.info(f"[CustomerResumeOrClassify] User intent analyzed as: {user_intent}")
        
        if user_intent == "NEGATIVE":
            logger.info(f"[CustomerResumeOrClassify] Operation canceled by user for {current_pause_reason}")
            logger.info(f"[CustomerResumeOrClassify] Clearing all state fields for complete cleanup")
            # Complete state cleanup on cancellation
            context.pause_reason = None
            context.pause_message = None
            context.confirm = None
            context.resume_from_pause = None
            context.sql = None  # Critical: Clear the pending SQL
            context.customer_action = None  # Clear customer action
            context.is_db_query = None  # Clear database query flag
            context.sql_prompt = None  # Clear SQL prompt
            context.system_prompt = None  # Clear system prompt
            context.db_result = None  # Clear database result
            context.response = "No problem! Let's start fresh. What would you like to do next?"
            context.next = "CustomerResponse"
            logger.info(f"[CustomerResumeOrClassify] State after cleanup - pause_reason: {context.pause_reason}, sql: {context.sql}")
            return context.model_dump()
        
        elif user_intent == "POSITIVE":
            logger.info(f"[CustomerResumeOrClassify] Confirmation received for {current_pause_reason}")
            context.resume_from_pause = True
            context.confirm = True
            context.next = "ExecuteCustomerSQL"
            return context.model_dump()
        
        elif user_intent == "UNCLEAR":
            # Ask for clarification instead of assuming
            action_type = "update" if "update" in current_pause_reason else "delete"
            context.response = f"I need a clear confirmation. Do you want to proceed with the {action_type}? Please reply 'yes' to confirm or 'no' to cancel."
            context.next = "CustomerResponse"
            return context.model_dump()
    
    # If resuming from pause, execute SQL
    if getattr(context, "resume_from_pause", False):
        context.next = "ExecuteCustomerSQL"
    else:
        # Complete cleanup and start fresh classification
        context.pause_reason = None
        context.pause_message = None
        context.confirm = None
        context.resume_from_pause = None
        context.sql = None
        context.customer_action = None
        context.is_db_query = None
        context.sql_prompt = None
        context.system_prompt = None
        context.db_result = None
        context.next = "ClassifyCustomerQuery"
    
    return context.model_dump()



async def general_customer_chat_node(context):
    """Handle general customer-related conversations."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    context.conversation_history = ensure_chat_messages(context.conversation_history or [])
    
    # Build system prompt using customer context
    system_prompt = build_customer_system_prompt(
        context, context.conversation_history, context.schema_context or []
    )
    
    messages = [
        {"role": "system", "content": system_prompt},
    ]
    
    # Add conversation history - use last 8 messages
    if context.conversation_history:
        recent_history = context.conversation_history[-8:]
        for msg in recent_history:
            messages.append(msg.model_dump())
    
    # Add current message
    messages.append({"role": "user", "content": context.message})
    
    # Generate response
    response = await llm_service.chat(messages)
    context.response = response.strip()
    
    return context.model_dump()

async def customer_response_node(context):
    """Final response node for customer interactions."""
    if isinstance(context, ChatGraphState):
        context = context.model_dump()
    
    output = {
        'message': context.get('message'),
        'business_id': context.get('business_id'),
        'user_id': context.get('user_id'),
        'conversation_history': context.get('conversation_history'),
        'schema_context': context.get('schema_context'),
        'customer_action': context.get('customer_action'),
        'sql_prompt': context.get('sql_prompt'),
        'sql': context.get('sql'),
        'response': context.get('response'),
        'next': context.get('next'),
        'pause_reason': context.get('pause_reason'),
        'pause_message': context.get('pause_message'),
        'confirm': context.get('confirm'),
        'resume_from_pause': context.get('resume_from_pause'),
    }
    
    logger.info(f"[CustomerGraph] Response: {output.get('response', '')[:100]}...")
    return output

# --- Build the Customer LangGraph Workflow ---
builder = StateGraph(ChatGraphState)

# Add nodes
builder.add_node("ClassifyCustomerQuery", classify_customer_query)
builder.add_node("RouteCustomerAction", route_customer_action)
builder.add_node("VectorSearch", vector_search_node)
builder.add_node("GenerateCustomerSQL", generate_customer_sql_node)
builder.add_node("CustomerDependencyCheck", customer_dependency_check_node)
builder.add_node("GenerateCustomerID", generate_customer_id_node)
builder.add_node("ExecuteCustomerSQL", execute_customer_sql_node)
builder.add_node("GeneralCustomerChat", general_customer_chat_node)
builder.add_node("PauseNode", pause_node)
builder.add_node("ResumeOrClassify", resume_or_classify_node)
builder.add_node("CustomerResponse", customer_response_node)

# Add edges
builder.add_edge("ClassifyCustomerQuery", "RouteCustomerAction")

# Conditional routing based on customer action
builder.add_conditional_edges(
    "RouteCustomerAction",
    lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
    {
        "VectorSearch": "VectorSearch",
        "GeneralCustomerChat": "GeneralCustomerChat",
        "ResumeOrClassify": "ResumeOrClassify"
    }
)

# Vector search leads to SQL generation
builder.add_edge("VectorSearch", "GenerateCustomerSQL")
builder.add_edge("GenerateCustomerSQL", "CustomerDependencyCheck")

# Dependency check routing
builder.add_conditional_edges(
    "CustomerDependencyCheck",
    lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
    {
        "GenerateCustomerID": "GenerateCustomerID",
        "ExecuteCustomerSQL": "ExecuteCustomerSQL",
        "PauseNode": "PauseNode",
        "CustomerResponse": "CustomerResponse"
    }
)

# Customer ID generation leads to SQL execution
builder.add_edge("GenerateCustomerID", "ExecuteCustomerSQL")

# Resume or classify routing
builder.add_conditional_edges(
    "ResumeOrClassify",
    lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
    {
        "ClassifyCustomerQuery": "ClassifyCustomerQuery",
        "ExecuteCustomerSQL": "ExecuteCustomerSQL"
    }
)

# All terminal nodes lead to response
builder.add_edge("ExecuteCustomerSQL", "CustomerResponse")
builder.add_edge("GeneralCustomerChat", "CustomerResponse")
builder.add_edge("PauseNode", "CustomerResponse")

# Set entry and exit points
builder.set_entry_point("ClassifyCustomerQuery")
builder.set_finish_point("CustomerResponse")


# Compile the graph (for backward compatibility)
customer_chat_graph = builder.compile()
