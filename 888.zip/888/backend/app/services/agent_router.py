from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.models.chat_graph_state import ChatGraphState
import logging
import re
import time
import hashlib
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class AgentRouter:
    def __init__(self, agent_registry=None):
        self.llm_service = MistralLLMService()
        self.agent_registry = agent_registry
        self.classification_history = []  # Track classification decisions for learning
        self.classification_cache = {}  # Cache for similar queries (performance optimization)
        self.cache_ttl = 300  # Cache TTL in seconds (5 minutes)
        
    async def classify_and_route(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Dynamically classify the query and route to appropriate agent.
        Returns the result from the selected agent.
        """
        try:
            # Convert state to ChatGraphState for consistency
            if isinstance(state, dict):
                context = ChatGraphState(**state)
            else:
                context = state
                
            # Hard override: if there is an active pause that requires confirmation,
            # always route to the customer agent to resume/execute
            if getattr(context, 'pause_reason', None) in {'confirm_update', 'confirm_delete'}:
                try:
                    agent = self.agent_registry.get_agent('customer')
                    result = await agent.ainvoke(state)
                    if isinstance(result, dict):
                        result['routed_agent'] = 'customer'
                        result['routing_confidence'] = 'forced_pause_resume'
                    return result
                except Exception as pause_error:
                    logger.error(f"[AgentRouter] Error handling pause state: {pause_error}")
                    # Clear pause state and proceed with normal routing
                    if hasattr(context, 'pause_reason'):
                        context.pause_reason = None
                        context.pause_message = None
                        context.confirm = None
                        context.resume_from_pause = None

            # Check cache first for performance optimization
            cache_key = self._generate_cache_key(context)
            cached_result = self._get_cached_classification(cache_key)
            
            if cached_result:
                agent_type = cached_result
                logger.info(f"[AGENT_CACHED] {agent_type}")
            else:
                # Perform dynamic classification
                agent_type = await self._classify_query_dynamically(context)
                logger.info(f"[AGENT_CLASSIFIED] {agent_type}")
                
                # Cache the result for similar future queries
                self._cache_classification(cache_key, agent_type)
            
            # Track the classification decision
            self._track_classification(context.message, agent_type)
            
            # Get the appropriate agent
            agent = self.agent_registry.get_agent(agent_type)
            if not agent:
                logger.error(f"[AgentRouter] Agent '{agent_type}' not found, falling back to general")
                agent = self.agent_registry.get_agent('general')
            
            # Execute with the selected agent
            result = await agent.ainvoke(state)
            
            # Add routing metadata to result
            if isinstance(result, dict):
                result['routed_agent'] = agent_type
                result['routing_confidence'] = 'high'
            
            return result
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in classification/routing: {e}")
            # Fallback to general agent
            fallback_agent = self.agent_registry.get_agent('general')
            result = await fallback_agent.ainvoke(state)
            
            # Ensure routed_agent is set for proper logging
            if isinstance(result, dict):
                result['routed_agent'] = 'general'
                result['routing_confidence'] = 'fallback_error'
            
            return result
    
    async def _classify_query_dynamically(self, context: ChatGraphState) -> str:
        """
        Optimized dynamic LLM-based agent classification with conversation context.
        Uses conversation history and intent analysis for accurate routing.
        """
        try:
            # Build optimized conversation context (last 6 messages)
            conversation_context = self._build_optimized_context(context)
            
            # Streamlined classification prompt for faster processing
            system_prompt = """You are an intelligent agent router. Analyze the query and conversation context to route to the correct agent.

AGENTS:
- customer: Customer data operations (add/create/update/delete/search/list customers/clients)
- general: All other queries (greetings, general business, orders, sales, inventory, products, reports, analytics)

Respond with ONLY the agent name: "customer" or "general"

CONTEXT RULES:
- Greetings (hi, hello, hey) → general
- Customer data operations → customer
- If previous messages discuss customers AND current query is about customers → customer
- If switching topics or general conversation → general
- "client" = "customer"
- When in doubt → general"""

            user_prompt = f"""CONVERSATION CONTEXT:
{conversation_context}

CURRENT QUERY: "{context.message}"

Route to:"""
            
            # Single optimized LLM call
            classification_response = await self.llm_service.chat([
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ])
            
            # Fast parsing with fallback
            raw = classification_response.strip().lower()
            cleaned = re.sub(r"[^a-z]", "", raw)
            
            if cleaned in ["customer", "general"]:
                agent_type = cleaned
            else:
                # Fallback: detect keywords in raw response
                if "customer" in raw:
                    agent_type = "customer"
                elif "general" in raw:
                    agent_type = "general"
                else:
                    logger.warning(f"[AgentRouter] Invalid classification '{classification_response}', defaulting to general")
                    return 'general'
                
            return agent_type
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in dynamic classification: {e}")
            # Fallback to rule-based classification
            return self._fallback_classification(context.message)
    
    def _build_optimized_context(self, context: ChatGraphState) -> str:
        """Build optimized conversation context for fast classification."""
        if not context.conversation_history:
            return "No context"
        
        # Get last 6 messages only (performance optimization)
        recent_messages = context.conversation_history[-6:]
        context_parts = []
        
        for msg in recent_messages:
            # Fast message processing
            if hasattr(msg, 'role') and hasattr(msg, 'content'):
                role, content = msg.role, msg.content
            elif isinstance(msg, dict):
                role = msg.get('role', 'user')
                content = msg.get('content', '')
            else:
                continue  # Skip malformed messages
            
            # Truncate long messages for speed
            if len(content) > 100:
                content = content[:100] + "..."
            
            context_parts.append(f"{role}: {content}")
        
        return "\n".join(context_parts) if context_parts else "No context"
    
    def _build_conversation_context(self, context: ChatGraphState) -> str:
        """Legacy method - redirects to optimized version."""
        return self._build_optimized_context(context)
    
    def _generate_cache_key(self, context: ChatGraphState) -> str:
        """Generate a cache key based on message and recent context."""
        # Use message + last 2 conversation turns for cache key
        cache_input = context.message.lower().strip()
        
        if context.conversation_history:
            recent = context.conversation_history[-2:]
            for msg in recent:
                if hasattr(msg, 'content'):
                    cache_input += msg.content[:50]  # First 50 chars only
                elif isinstance(msg, dict):
                    cache_input += msg.get('content', '')[:50]
        
        return hashlib.md5(cache_input.encode()).hexdigest()
    
    def _get_cached_classification(self, cache_key: str) -> str:
        """Get cached classification if valid and not expired."""
        if cache_key in self.classification_cache:
            cached_data = self.classification_cache[cache_key]
            if time.time() - cached_data['timestamp'] < self.cache_ttl:
                return cached_data['agent_type']
            else:
                # Remove expired cache entry
                del self.classification_cache[cache_key]
        return None
    
    def _cache_classification(self, cache_key: str, agent_type: str):
        """Cache the classification result."""
        self.classification_cache[cache_key] = {
            'agent_type': agent_type,
            'timestamp': time.time()
        }
        
        # Limit cache size to prevent memory bloat
        if len(self.classification_cache) > 1000:
            # Remove oldest 200 entries
            sorted_items = sorted(self.classification_cache.items(), 
                                key=lambda x: x[1]['timestamp'])
            for key, _ in sorted_items[:200]:
                del self.classification_cache[key]
    
    def _fallback_classification(self, message: str) -> str:
        """
        Optimized fallback classification using fast pattern matching.
        This is used only when LLM classification fails.
        """
        message_lower = message.lower().strip()
        
        # Greetings and general conversation - always general
        greeting_patterns = ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'how are you', 'thanks', 'thank you']
        if any(pattern in message_lower for pattern in greeting_patterns):
            return 'general'
        
        # Fast customer pattern detection
        customer_keywords = [
            'customer', 'client', 'add customer', 'create customer', 'new customer',
            'find customer', 'search customer', 'update customer', 'delete customer',
            'list customer', 'show customer', 'customer data', 'customer info'
        ]
        
        # Quick keyword check for performance
        if any(keyword in message_lower for keyword in customer_keywords):
            return 'customer'
        
        # Default to general for everything else
        return 'general'

    def _track_classification(self, query: str, agent_type: str, confidence: str = 'high'):
        """
        Track classification decisions for potential learning and improvement.
        """
        classification_record = {
            'query': query,
            'agent_type': agent_type,
            'confidence': confidence,
            'timestamp': time.time()
        }
        self.classification_history.append(classification_record)
        
        # Keep only last 1000 classifications to prevent memory bloat
        if len(self.classification_history) > 1000:
            self.classification_history = self.classification_history[-1000:]
    
    def get_classification_stats(self):
        """
        Get statistics about classification decisions for monitoring and improvement.
        """
        if not self.classification_history:
            return {'total': 0, 'customer': 0, 'general': 0}
        
        total = len(self.classification_history)
        customer_count = sum(1 for record in self.classification_history if record['agent_type'] == 'customer')
        general_count = sum(1 for record in self.classification_history if record['agent_type'] == 'general')
        
        return {
            'total': total,
            'customer': customer_count,
            'general': general_count,
            'customer_percentage': (customer_count / total) * 100 if total > 0 else 0,
            'general_percentage': (general_count / total) * 100 if total > 0 else 0
        }

 