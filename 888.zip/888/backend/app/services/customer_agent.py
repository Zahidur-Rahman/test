from backend.app.services.base_agent import BaseAgent
from backend.app.services.customer_chat_graph import customer_chat_graph

class CustomerAgent(BaseAgent):
    """
    Customer Agent that uses LangGraph workflow for customer-related queries and operations.
    """
    
    async def ainvoke(self, state):
        """
        Process customer-related queries using LangGraph workflow.
        """
        if not isinstance(state, dict):
            raise ValueError(f"Expected state to be a dictionary, got {type(state)}")
        
        return await customer_chat_graph.ainvoke(state)
