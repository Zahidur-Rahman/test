from langgraph.graph import StateGraph
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.models.conversation import ChatMessage
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.config import get_settings
import logging
import asyncio

logger = logging.getLogger(__name__)
settings = get_settings()

# Instantiate LLM service for general conversation
llm_service = MistralLLMService()

def ensure_chat_messages(messages):
    return [msg if isinstance(msg, ChatMessage) else ChatMessage.model_validate(msg) for msg in messages]

# --- Node Functions for General Conversation ---

async def general_chat_node(context):
    """
    Handle general conversational queries without database operations.
    This is for personal questions, greetings, help requests, etc.
    """
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    context.conversation_history = ensure_chat_messages(context.conversation_history or [])
    
    # Remove any trailing 'user' messages before building LLM input
    while context.conversation_history and (
        getattr(context.conversation_history[-1], 'role', None) == 'user' or
        (isinstance(context.conversation_history[-1], dict) and context.conversation_history[-1].get('role') == 'user')
    ):
        context.conversation_history.pop()
    
    # Build system prompt for general conversation
    system_prompt = build_general_system_prompt(context)
    
    messages = [
        {"role": "system", "content": system_prompt},
    ] + [msg.model_dump() for msg in context.conversation_history]
    
    # Always add the new user message as the last message
    messages.append({"role": "user", "content": context.message})
    
    # Ensure no consecutive messages with same role
    if len(messages) > 2 and messages[-1]["role"] == "user" and messages[-2]["role"] == "user":
        messages.pop(-2)
    
    # Validate message structure
    for i in range(1, len(messages)):
        if messages[i]['role'] == messages[i-1]['role']:
            raise ValueError(f"Two consecutive roles: {messages[i-1]['role']} and {messages[i]['role']} at positions {i-1}, {i}")
    
    # Truncate to last valid system/user/assistant turn if too long
    if len(messages) > 3:
        messages = [messages[0]] + messages[-2:]
    
    logger.info(f"[GENERAL_LLM] Generating conversational response...")
    try:
        llm_timeout = getattr(settings, 'llm_timeout_seconds', 25)
        response = await asyncio.wait_for(llm_service.chat(messages), timeout=llm_timeout)
        context.response = response
        logger.info(f"[GENERAL_LLM] Response generated successfully")
    except asyncio.TimeoutError:
        logger.error(f"[GENERAL_LLM] Timeout after {getattr(settings, 'llm_timeout_seconds', 25)}s")
        context.response = "I'm sorry, but I'm taking longer than expected to respond. Please try again or rephrase your question."
    except Exception as e:
        logger.error(f"[GENERAL_LLM] Error: {e}")
        context.response = "I encountered an error while processing your request. Please try again."
    
    return context.model_dump()

async def general_response_node(context):
    """
    Final response node for general conversation.
    """
    if isinstance(context, ChatGraphState):
        context = context.model_dump()
    
    output = {
        'message': context.get('message'),
        'business_id': context.get('business_id'),
        'user_id': context.get('user_id'),
        'conversation_history': context.get('conversation_history'),
        'response': context.get('response'),
        'is_db_query': False,  # Always false for general chat
        'routed_agent': 'general',
        'next': None,
        # Clear any database-related fields
        'schema_context': None,
        'sql_prompt': None,
        'sql': None,
        'db_result': None,
        'pause_reason': None,
        'pause_message': None,
        'confirm': None,
        'resume_from_pause': None,
    }
    
    logger.info(f"[GENERAL_CHAT] Response: {output.get('response', '')[:100]}...")
    return output

def build_general_system_prompt(context: ChatGraphState) -> str:
    """
    Build system prompt for general conversational AI.
    """
    business_id = getattr(context, 'business_id', 'Unknown')
    
    system_prompt = f"""You are a helpful, friendly AI assistant for business ID {business_id}. 

You are designed to handle general conversation, answer questions, provide help, and engage in friendly chat.

CAPABILITIES:
- Answer general questions about business operations
- Provide helpful explanations and advice
- Engage in friendly conversation
- Help users understand how to use the system
- Respond to greetings and personal questions

PERSONALITY:
- Be friendly, helpful, and professional
- Use a conversational tone
- Be concise but informative
- Show empathy and understanding

IMPORTANT GUIDELINES:
- You do NOT have access to specific business data or customer records
- For specific data queries (like "show me customers" or "find John Smith"), politely explain that you can help with general questions but they should use specific data commands for database queries
- Focus on being helpful with explanations, guidance, and general conversation
- If asked about your capabilities, explain that you handle general conversation while there are specialized tools for data operations

EXAMPLES OF WHAT YOU HANDLE:
- "Hello, how are you?" → Friendly greeting response
- "Do you know me?" → Explain your role and limitations
- "What can you help me with?" → Describe your capabilities
- "How does this system work?" → Provide helpful explanation
- "Thanks for your help" → Acknowledge gratefully

Remember: You are the conversational AI, not the database query system. Be helpful, friendly, and clear about your role."""

    return system_prompt

# --- Build the General Chat Graph ---
builder = StateGraph(ChatGraphState)
builder.add_node("GeneralChat", general_chat_node)
builder.add_node("GeneralResponse", general_response_node)

# Simple flow: Chat -> Response
builder.add_edge("GeneralChat", "GeneralResponse")

builder.set_entry_point("GeneralChat")
builder.set_finish_point("GeneralResponse")

general_chat_graph = builder.compile()
