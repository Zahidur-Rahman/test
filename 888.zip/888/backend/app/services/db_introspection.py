"""
Database introspection service for PostgreSQL databases.
"""

import asyncio
import logging
from sqlalchemy import create_engine, text
from typing import List, Dict, Any, Optional
from backend.app.models.business import DatabaseConfig
from backend.app.models.schema import ColumnSchema

logger = logging.getLogger(__name__)

class DatabaseIntrospectionService:
    """Service for introspecting PostgreSQL databases"""
    
    @staticmethod
    def get_connection_string(db_config: DatabaseConfig) -> str:
        """Build PostgreSQL connection string from config"""
        # URL encode password to handle special characters
        import urllib.parse
        password = urllib.parse.quote_plus(db_config.password)
        
        # Use psycopg2 for compatibility
        return f"postgresql+psycopg2://{db_config.user}:{password}@{db_config.host}:{db_config.port}/{db_config.database}"
    
    @staticmethod
    async def test_connection(db_config: DatabaseConfig) -> bool:
        """Test database connection"""
        engine = None
        try:
            conn_str = DatabaseIntrospectionService.get_connection_string(db_config)
            logger.debug(
                "Testing connection with: host=%s, database=%s, user=%s, port=%s",
                db_config.host,
                db_config.database,
                db_config.user,
                db_config.port,
            )
            
            # Use synchronous engine with psycopg2
            engine = create_engine(
                conn_str, 
                pool_pre_ping=True,
                pool_timeout=10,
                pool_recycle=3600
            )
            
            # Run in thread pool to make it async-compatible
            def sync_test():
                with engine.begin() as conn:
                    result = conn.execute(text("SELECT 1 as test_connection"))
                    row = result.fetchone()
                    logger.debug("Connection test successful: %s", row)
                    return True
            
            # Execute in thread pool
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, sync_test)
            return result
            
        except Exception as e:
            logger.warning(
                "Connection test failed for %s:%s/%s: %s",
                db_config.host,
                db_config.port,
                db_config.database,
                e,
            )
            logger.debug(
                "Connection string (without password): postgresql+psycopg2://%s:***@%s:%s/%s",
                db_config.user,
                db_config.host,
                db_config.port,
                db_config.database,
            )
            return False
        finally:
            if engine:
                engine.dispose()
    
    @staticmethod
    async def get_tables(db_config: DatabaseConfig) -> List[Dict[str, Any]]:
        """Get all tables from the database"""
        engine = None
        try:
            conn_str = DatabaseIntrospectionService.get_connection_string(db_config)
            logger.info("Fetching tables from: %s:%s/%s", db_config.host, db_config.port, db_config.database)
            
            # Use synchronous engine with psycopg2
            engine = create_engine(
                conn_str, 
                pool_pre_ping=True,
                pool_timeout=10,
                pool_recycle=3600
            )
            
            query = text("""
            SELECT 
                table_name,
                table_type,
                COALESCE(obj_description(c.oid), '') as table_comment
            FROM information_schema.tables t
            LEFT JOIN pg_class c ON c.relname = t.table_name
            WHERE table_schema = 'public'
            AND table_type = 'BASE TABLE'
            ORDER BY table_name;
            """)
            
            # Run in thread pool to make it async-compatible
            def sync_get_tables():
                with engine.begin() as conn:
                    result = conn.execute(query)
                    rows = result.fetchall()
                
                tables = [
                    {
                        "table_name": row.table_name,
                        "table_type": row.table_type,
                        "description": row.table_comment or ""
                    }
                    for row in rows
                ]
                # Avoid logging full table list to prevent spam; keep count only at info level
                logger.info("Found %d tables", len(tables))
                logger.debug("Tables: %s", [t['table_name'] for t in tables])
                return tables
            
            # Execute in thread pool
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, sync_get_tables)
            return result
            
        except Exception as e:
            logger.error(
                "Failed to fetch tables from %s:%s/%s: %s",
                db_config.host,
                db_config.port,
                db_config.database,
                str(e),
            )
            raise ValueError(f"Failed to fetch tables: {str(e)}")
        finally:
            if engine:
                engine.dispose()
    
    @staticmethod
    async def get_columns(db_config: DatabaseConfig, table_name: str) -> List[ColumnSchema]:
        """Get all columns for a specific table"""
        engine = None
        try:
            conn_str = DatabaseIntrospectionService.get_connection_string(db_config)
            engine = create_engine(conn_str, pool_pre_ping=True)
            
            query = text("""
            SELECT 
                c.column_name,
                c.data_type,
                c.is_nullable,
                c.column_default,
                c.character_maximum_length,
                COALESCE(col_description(pgc.oid, c.ordinal_position), '') as column_comment,
                CASE WHEN pk.column_name IS NOT NULL THEN true ELSE false END as is_primary_key
            FROM information_schema.columns c
            LEFT JOIN pg_class pgc ON pgc.relname = c.table_name
            LEFT JOIN (
                SELECT ku.column_name
                FROM information_schema.table_constraints tc
                JOIN information_schema.key_column_usage ku
                ON tc.constraint_name = ku.constraint_name
                WHERE tc.constraint_type = 'PRIMARY KEY'
                AND tc.table_name = :table_name
            ) pk ON pk.column_name = c.column_name
            WHERE c.table_name = :table_name
            AND c.table_schema = 'public'
            ORDER BY c.ordinal_position;
            """)
            
            # Run in thread pool to make it async-compatible
            def sync_get_columns():
                with engine.begin() as conn:
                    result = conn.execute(query, {"table_name": table_name})
                    rows = result.fetchall()
                
                columns = []
                for row in rows:
                    columns.append(ColumnSchema(
                        name=row.column_name,
                        type=row.data_type,
                        description=row.column_comment or "",
                        is_nullable=row.is_nullable == "YES",
                        is_primary_key=row.is_primary_key,
                        max_length=row.character_maximum_length,
                        default_value=row.column_default
                    ))
                
                return columns
            
            # Execute in thread pool
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, sync_get_columns)
            return result
            
        except Exception as e:
            raise ValueError(f"Failed to fetch columns for table {table_name}: {str(e)}")
        finally:
            if engine:
                engine.dispose()
    
    @staticmethod
    async def get_table_relationships(db_config: DatabaseConfig, table_name: str = None) -> List[Dict[str, Any]]:
        """Get all foreign key relationships in the database"""
        engine = None
        try:
            conn_str = DatabaseIntrospectionService.get_connection_string(db_config)
            engine = create_engine(conn_str, pool_pre_ping=True)
            
            query = text("""
            SELECT 
                tc.table_name as source_table,
                kcu.column_name as source_column,
                ccu.table_name as target_table,
                ccu.column_name as target_column,
                tc.constraint_name,
                rc.update_rule,
                rc.delete_rule
            FROM information_schema.table_constraints tc
            JOIN information_schema.key_column_usage kcu 
                ON tc.constraint_name = kcu.constraint_name
                AND tc.table_schema = kcu.table_schema
            JOIN information_schema.constraint_column_usage ccu 
                ON ccu.constraint_name = tc.constraint_name
                AND ccu.table_schema = tc.table_schema
            JOIN information_schema.referential_constraints rc
                ON tc.constraint_name = rc.constraint_name
                AND tc.table_schema = rc.constraint_schema
            WHERE tc.constraint_type = 'FOREIGN KEY'
            AND tc.table_schema = 'public'
            ORDER BY tc.table_name, kcu.column_name;
            """)
            
            # Add table filter if specified
            if table_name:
                query = text(str(query).replace("ORDER BY", f"AND (tc.table_name = '{table_name}' OR ccu.table_name = '{table_name}') ORDER BY"))
            
            # Run in thread pool to make it async-compatible
            def sync_get_relationships():
                with engine.begin() as conn:
                    result = conn.execute(query)
                    rows = result.fetchall()
                
                relationships = [
                    {
                        "source_table": row.source_table,
                        "source_column": row.source_column,
                        "target_table": row.target_table,
                        "target_column": row.target_column,
                        "constraint_name": row.constraint_name,
                        "update_rule": row.update_rule,
                        "delete_rule": row.delete_rule,
                        "relationship_type": "foreign_key"
                    }
                    for row in rows
                ]
                logger.debug(
                    "Found %d relationships for table %s",
                    len(relationships),
                    table_name or 'all tables',
                )
                return relationships
            
            # Execute in thread pool
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, sync_get_relationships)
            return result
            
        except Exception as e:
            logger.error("Failed to fetch relationships: %s", str(e))
            raise ValueError(f"Failed to fetch relationships: {str(e)}")
        finally:
            if engine:
                engine.dispose()
    
    @staticmethod
    async def get_table_with_columns(db_config: DatabaseConfig, table_name: str) -> Dict[str, Any]:
        """Get table info with all its columns"""
        try:
            tables = await DatabaseIntrospectionService.get_tables(db_config)
            table_info = next((t for t in tables if t["table_name"] == table_name), None)
            
            if not table_info:
                raise ValueError(f"Table {table_name} not found")
            
            columns = await DatabaseIntrospectionService.get_columns(db_config, table_name)
            
            return {
                "table_name": table_name,
                "description": table_info["description"],
                "columns": [col.model_dump() for col in columns]
            }
        except Exception as e:
            raise ValueError(f"Failed to get table details: {str(e)}")
